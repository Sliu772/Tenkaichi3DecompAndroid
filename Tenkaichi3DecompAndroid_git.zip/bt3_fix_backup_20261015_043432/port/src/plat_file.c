/*
 * The game's file access on PC.
 *
 * The game reads everything through CRI's ADXF library: three AFS archives ("partitions" 0..2), files addressed by
 * (partition, index), read in 2048-byte sectors, asynchronously. Here an archive is a FOLDER of loose files made by
 * port/tools/extract_disc.py (<root>/pzs3us1/00042.bin is partition 1, index 42) and a read finishes at once.
 * <root> is the environment variable BT3_DATA, or "gamedata". A file in <root>/mods/<same relative path> is used
 * instead of the original: that is the whole modding mechanism for now.
 */
#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "port_host.h"
#include "plat_stages.h"
#include "plat_songs.h"

#define SECTOR 2048
enum { STAT_STOP = 1, STAT_READING = 2, STAT_READEND = 3, STAT_ERROR = 4 };

/* What the game holds for an open file. Only what can be saved and restored with the game's state: which file, its
   size, the read position, the status. The host's own file objects are in plat_fcache.c. */
typedef struct PortFile {
    char rel[128];
    int32_t sizeSct;
    int32_t posSct;
    int32_t stat;
} PortFile;

extern long Port_FileSize(const char *rel); /* plat_fcache.c */
extern size_t Port_FileReadAt(const char *rel, long offset, void *buf, size_t bytes);

static char sPartDir[8][64];
char gPortMoviePath[512]; /* host path of the movie file opened last */
int Port_FilePath(int ptid, int flid, const char *fname, char *out, int size);
extern void *Port_LowAlloc(size_t size); /* plat_mem.c */
extern void Port_LowFree(void *addr);

static const char *root(void) {
    const char *r = getenv("BT3_DATA");
    return r != NULL ? r : "gamedata";
}
const char *Port_FileRoot(void) { return root(); }

/* BT3_FILE_ALIAS="rel=target;rel=target": a file the game asks for (its path under the data root) served from
   somewhere else. A missing archive entry (a new id) gets a host file this way. The manifest of added stages
   (port/plat_stages.c) is checked first. */
static const char *alias_target(const char *rel) {
    static char buf[512];
    const char *list = getenv("BT3_FILE_ALIAS");
    const char *p, *eq, *end;
    size_t rl = strlen(rel);

    if (PortStages_Alias(rel, buf, sizeof(buf))) {
        return buf;
    }
    if (PortSongs_Alias(rel, buf, sizeof(buf))) {
        return buf;
    }
    if (list == NULL) {
        return NULL;
    }
    for (p = list; *p != '\0'; p = end + 1) {
        eq = strchr(p, '=');
        end = strchr(p, ';');
        if (eq == NULL || (end != NULL && eq > end)) {
            if (end == NULL) break;
            continue;
        }
        if ((size_t)(eq - p) == rl && strncmp(p, rel, rl) == 0) {
            size_t n = end != NULL ? (size_t)(end - (eq + 1)) : strlen(eq + 1);
            if (n >= sizeof(buf)) n = sizeof(buf) - 1;
            memcpy(buf, eq + 1, n);
            buf[n] = '\0';
            return buf;
        }
        if (end == NULL) break;
    }
    return NULL;
}

/* The handle (ADXF) is a typedef'd pointer of the game: it crosses the call as a 4-byte address (an offset from the header
   on iOS), not as a host pointer like the `void *` / `char *` parameters, which the call converts itself. So the handle goes
   back to the game as Port_P2A and comes in through Port_A2P (the same thing as a plain pointer where PORT_BASE is 0). */
static PortFile *pf(void *h) {
    return (PortFile *)Port_A2P((uint32_t)(uintptr_t)h);
}

static void *handle_out(PortFile *f) {
    return (void *)(uintptr_t)Port_P2A(f);
}

static int sDiagN; /* diagnostic: how many opens/reads were logged */

static PortFile *open_rel(const char *rel) {
    PortFile *f;
    long size = Port_FileSize(rel); /* (says so itself when the file is missing) */

    if (size < 0) {
        return NULL;
    }
    if (sDiagN < 400) {
        sDiagN++;
        fprintf(stderr, "bt3 open: %s size %ld\n", rel, size);
    }
    f = Port_LowAlloc(sizeof(PortFile)); /* the game keeps the handle in a 4-byte pointer */
    snprintf(f->rel, sizeof(f->rel), "%s", rel);
    f->sizeSct = (int32_t)((size + SECTOR - 1) / SECTOR);
    f->stat = STAT_STOP;
    return f;
}

/* The host path of a game file, for code that reads files itself (the sound streams): file `flid` of partition
   `ptid`, or with `fname` a loose file of the disc's data directory. A file under mods/ wins. 0 = not found. */
int Port_FilePath(int ptid, int flid, const char *fname, char *out, int size) {
    char rel[256];
    FILE *fp;
    int n;

    if (fname != NULL) {
        n = snprintf(rel, sizeof(rel), "disc/DATA/");
        for (; *fname != '\0' && *fname != ';' && n < 255; fname++) {
            rel[n++] = *fname == '\\' ? '/' : (char)toupper((unsigned char)*fname);
        }
        rel[n] = '\0';
    } else {
        snprintf(rel, sizeof(rel), "%s/%05d.bin", sPartDir[ptid & 7], flid);
    }
    {
        /* The streamed audio (a song added from outside the disc) reads through this path, so the manifest's
           aliases must apply here too, not only in open_rel. */
        const char *a = alias_target(rel);
        if (a != NULL) {
            fp = fopen(a, "rb"); /* as it is (the songs folder next to the game) */
            if (fp != NULL) {
                fclose(fp);
                snprintf(out, (size_t)size, "%s", a);
                return 1;
            }
            snprintf(rel, sizeof(rel), "%s", a);
        }
    }
    snprintf(out, (size_t)size, "%s/mods/%s", root(), rel);
    fp = fopen(out, "rb");
    if (fp == NULL) {
        snprintf(out, (size_t)size, "%s/%s", root(), rel);
        fp = fopen(out, "rb");
    }
    if (fp == NULL) {
        /* inside the archive (plat_fcache.c): "<archive>#<offset>+<size>", which Port_OpenSpan opens */
        extern int Port_AfsSpan(const char *rel, char *path, unsigned n, long *base, long *size);
        char afs[400];
        long base, span;
        if (fname == NULL && Port_AfsSpan(rel, afs, (unsigned)sizeof(afs), &base, &span)) {
            snprintf(out, (size_t)size, "%s#%ld+%ld", afs, base, span);
            return 1;
        }
        return 0;
    }
    fclose(fp);
    return 1;
}

/* Opens a path from Port_FilePath at the start of the file: a plain path, or "<archive>#<offset>+<size>".
   *size gets the file's size. */
FILE *Port_OpenSpan(const char *path, long *size) {
    char host[512];
    const char *hash = strrchr(path, '#');
    long base = 0, span = -1;
    FILE *fp;

    if (hash != NULL && sscanf(hash + 1, "%ld+%ld", &base, &span) == 2 && (size_t)(hash - path) < sizeof(host)) {
        memcpy(host, path, (size_t)(hash - path));
        host[hash - path] = '\0';
    } else {
        snprintf(host, sizeof(host), "%s", path);
        base = 0;
        span = -1;
    }
    fp = fopen(host, "rb");
    if (fp == NULL) {
        return NULL;
    }
    if (span < 0) {
        fseek(fp, 0, SEEK_END);
        span = ftell(fp);
    }
    fseek(fp, base, SEEK_SET);
    if (size != NULL) {
        *size = span;
    }
    return fp;
}

/* "pzs3us1.afs" (any case, any directory, optional ";1") -> folder "pzs3us1". */
int ADXF_LoadPartitionNw(int ptid, char *fname, void *dir, void *ptinfo) {
    const char *base = fname;
    const char *p;
    int n = 0;

    (void)dir;
    (void)ptinfo;
    for (p = fname; *p != '\0'; p++) {
        if (*p == '/' || *p == '\\') {
            base = p + 1;
        }
    }
    for (p = base; *p != '\0' && *p != '.' && n < 63; p++) {
        sPartDir[ptid & 7][n++] = (char)tolower((unsigned char)*p);
    }
    sPartDir[ptid & 7][n] = '\0';
    return 0;
}

int ADXF_GetPtStat(int ptid) {
    return sPartDir[ptid & 7][0] != '\0' ? STAT_READEND : STAT_STOP;
}

void *ADXF_OpenAfs(int ptid, int flid) {
    char rel[128];

    snprintf(rel, sizeof(rel), "%s/%05d.bin", sPartDir[ptid & 7], flid);
    return handle_out(open_rel(rel));
}

/* A file outside the archives, named relative to the disc's data directory. */
void *ADXF_Open(char *fname, void *atr) {
    char rel[256];
    int n;

    (void)atr;
    n = snprintf(rel, sizeof(rel), "disc/DATA/");
    for (; *fname != '\0' && *fname != ';' && n < 255; fname++) {
        rel[n++] = *fname == '\\' ? '/' : (char)toupper((unsigned char)*fname);
    }
    rel[n] = '\0';
    if (n > 4 && strcmp(&rel[n - 4], ".PSS") == 0) { /* a movie: its decoder (plat_movie.c) needs the path */
        Port_FilePath(0, 0, &rel[10], gPortMoviePath, sizeof(gPortMoviePath));
    }
    return handle_out(open_rel(rel));
}

void ADXF_Close(void *h) {
    PortFile *f = pf(h);

    if (f != NULL) {
        Port_LowFree(f); /* (the host's file stays open for a while: plat_fcache.c) */
    }
}

int ADXF_GetFsizeSct(void *h) {
    return pf(h)->sizeSct;
}

/* Reads nsct sectors at the current position; the part of the last sector behind the end of the file is zero. */
int ADXF_ReadNw(void *h, int nsct, void *buf) {
    PortFile *f = pf(h);
    size_t got;

    if (nsct > f->sizeSct - f->posSct) {
        nsct = f->sizeSct - f->posSct;
    }
    got = Port_FileReadAt(f->rel, (long)f->posSct * SECTOR, buf, (size_t)nsct * SECTOR);
    if (sDiagN < 400 && nsct > 0) {
        const uint8_t *b = (const uint8_t *)buf;
        sDiagN++;
        fprintf(stderr, "bt3 read: %s pos %d nsct %d got %lu buf %08x head %02x%02x%02x%02x %02x%02x%02x%02x %02x%02x%02x%02x\n", f->rel, (int)f->posSct, nsct,
                (unsigned long)got, (unsigned)Port_P2A(buf), b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11]);
    }
    memset((uint8_t *)buf + got, 0, (size_t)nsct * SECTOR - got);
    f->posSct += nsct;
    f->stat = STAT_READEND;
    return nsct;
}

int ADXF_Stop(void *h) {
    pf(h)->stat = STAT_STOP;
    return 0;
}

int ADXF_GetStat(void *h) {
    return pf(h)->stat;
}

int ADXF_Tell(void *h) {
    return pf(h)->posSct;
}

/* CRI set-up and servicing: nothing to do without a drive or a second thread. */
void ADXPS2_ExecVint(int mode) { (void)mode; }
void ADXPS2_SetupDvdFs(void *param) { (void)param; }
void ADXPS2_LoadFcacheDvd(void *param) { (void)param; }
void ADXPS2_SetupThrd(void *param, int unk) { (void)param; (void)unk; }
void ADXM_ExecMain(void) {}
/* Waits for the next vertical blank. Headless: the blank happens now (no real-time pacing). */
extern void Port_VBlank(void);
void ADXM_WaitVsync(void) { Port_VBlank(); }
void ADXERR_EntryErrFunc(void (*func)(void *obj, char *msg), void *obj) { (void)func; (void)obj; }

/* The drive: a PS2 DVD is always present and idle (sceCdGetDiskTypeSafe 0x14 = PS2 DVD, sceCdStatus 10 = paused). */
int sceCdGetDiskTypeSafe(void) { return 0x14; }
int sceCdStatus(void) { return 10; }
/* Disc_Identify (src/sys/file.c) looks for each game's boot file on the disc; the disc here is always this game's (SLUS_216.78). */
int sceCdSearchFile(void *file, const char *name) {
    (void)file;
    return name != NULL && strstr(name, "216.78") != NULL;
}

/* bring-up (iOS): what a block of game memory holds, for the logo pictures that arrive empty (at most 120 lines) */
void Port_DiagBlock(const char *what, const void *p, uint32_t bytes) {
    static int sLines;
    const uint32_t *w = (const uint32_t *)p;
    uint32_t n = bytes / 4, k, nz = 0;
    int first = -1;

    if (sLines >= 400 || p == NULL) {
        return;
    }
    sLines++;
    for (k = 0; k < n; k++) {
        if (w[k] != 0) {
            nz++;
            if (first < 0) { first = (int)k; }
        }
    }
    fprintf(stderr, "bt3 diag: %s at %08x, %u bytes, %u of %u words not zero, first at %d; data:", what,
            (unsigned)(uintptr_t)p, (unsigned)bytes, (unsigned)nz, (unsigned)n, first);
    for (k = 0; k < 8 && k < n; k++) {
        fprintf(stderr, " %08x", (unsigned)w[k]);
    }
    fprintf(stderr, "\n");
}

void Port_DiagNote(const char *what, long a, long b) {
    static int sLines;

    if (sLines++ < 400) {
        fprintf(stderr, "bt3 diag: %s %ld %ld\n", what, a, b);
    }
}
