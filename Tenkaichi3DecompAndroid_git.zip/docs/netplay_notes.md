# Notes for deterministic netplay

The end goal is a PC port with new online play. This collects what the decompilation has shown
that bears on keeping two machines in sync. **Verified** means confirmed by C that compiles to
the original bytes; **inferred** means read from disassembly or deduced.

## The simulation step

- Fixed 30 Hz step: every loop ends a frame with a two-vblank wait, timers count
  `seconds * 30`, and the battle clock advances 100 ms per three ticks. (verified)
- One battle frame is `Battle_Loop`'s body (systems/battle.md). Input is sampled once per
  fighter in `BtlChars_SampleInput`; the simulation is the AI update, the fighter phases, the
  effect scene, the stage (including rigid-body debris), the cameras and the sequence; drawing
  follows. (verified order)
- Fighters are updated pass by pass, fighter 0 first in each pass; the hit-stop loop has an
  early exit that favours roster order. A port must keep the order. (verified)
- A fight starts from a clean state: `BtlChar_ResetAll` zeroes both fighters and rebuilds them
  from the setup, at init, on restart, and again on the first Ready/Fight frame. (verified)
- Pause does not stop the loop: it is a flag each subsystem checks. Both peers must agree on
  it. (verified)

## Input: what to synchronise

- Fights use a per-fighter record, not the menu input word. (verified, `btl_input.c`)
- **The game's own replay records exactly `{buttons, stickX, stickY}` per fighter per
  input-taking frame**, after key config and double-tap detection, before the ring and the
  gating. The command word is recomputed. This is the minimal input a peer needs.
  (verified, `btl_replay.c`)
- The 8-entry ring per fighter never delays (pushed and popped in the same call; its public
  wrappers have no callers). It is the natural place to add input delay. (verified)
- CPU input is injected through fields on the fighter; the same path could carry remote input.
  CPU fighters are recorded in replays as inputs. (verified)
- Key config is applied before recording, so peers with different layouts exchange the same
  button word. (verified)
- A track index is not a frame number: nothing is recorded on paused frames or when the
  fighter is not taking input. (verified)
- Gating after the record (neutral or masked input in non-fight states) depends on battle and
  fighter flags, which must therefore be in sync. (verified)
- Menus read `gPad` fields directly from about 110 functions. (counted from disassembly)

## The replay system as evidence

A replay is the 0x5A8-byte setup plus two 9000-frame input tracks and nothing else: no seed,
no frame counter, no result. (verified) It reproduces a fight because:

1. the fighters' own generator and the frame counter both reset with the fighters at fight
   start (verified);
2. the CPU's decisions are captured as input (verified);
3. everything else that is random was judged not to matter (inferred).

A replay is therefore a ready-made desync test for a port, with one known weakness: paths
driven by `rand()` are not reproduced, so a replayed double KO can resolve differently from
the original. (inferred from the verified code)

## Sources of randomness

| Generator | State | Seeded / reset | Used by |
|---|---|---|---|
| `BtlChar_Rand` | roster +0x18 | zeroed by `BtlChar_ResetAll` | clash C only (9 sites): stage path, point on it, exchanges before moving. Feeds fighter placement. Plus two float users |
| `BtlChar_FrameMod` | roster frame counter | zeroed by `BtlChar_ResetAll` | fighter picks, e.g. voice lines (39 sites) |
| `BtlScene_Rand` | scene +randState | zeroed by `BtlScene_Reset` (battle start, restart, and some mid-battle sites) | effect scene |
| libc `rand()` | C library | **boot only**, from a hardware timer | about 490 direct call sites, almost all effect tasks; camera shake; the battle sequence's voice choice and **double-KO tie-break**; `Rand_IntRange` (34 sites) |
| VU0 R register (`Rand_Float01`, `Rand_FloatRange`) | vector unit | **boot only**, from a constant | effect code (about 160 sites) |
| `Rand_*` (broken-refill MT19937) | 624 words + index | **boot only**, from `rand()` | the AI (49 sites), the menus (about 198 sites), a few others |
| second MT19937 at 0x252F68 | own state | per call | a menu codec only |

(Generators and reset points verified; "boot only" is from a grep of every caller; the
per-generator user lists are by address range, not traced call by call.)

Consequences:
- The first three reset themselves; both peers only need to reach the first Ready frame on
  the same frame.
- **Draw code consumes libc `rand()`**: the depth haze (`StgHaze_Step`, called from a draw
  pass) draws 2 values per mesh vertex per view, about 2000 per drawn frame, on stages with
  that feature; the count depends on split screen, the demo camera and pause. A port must give
  it its own generator. (verified)
- More draws from shared generators by non-simulation code (verified): stage ambience sound
  draws libc `rand()` on some stages; screen shock waves draw 20 values from the VU0 register
  per spawn; visual particle modules draw libc `rand()` in proportion to live particles; water
  trails only outside split screen. See systems/effects_stage.md.
- **libc `rand()` must be synchronised**: it reaches the result through the double-KO
  tie-break, and its call count depends on camera shake and effects.
- **The VU0 register and the Mersenne Twister must be synchronised** if anything that uses
  them can affect the simulation: effects (which can hit) and any CPU-controlled fighter.
- The twister is shared with the menus; nothing outside the simulation may draw from it
  during a fight, or the AI needs its own stream.
- The roster's "time stopped" word (+0x274) freezes the two fighter sources, the scene
  generator and input. Its writer is `BtlChange_Update` (see the load-completion row below).
- Generators that reach projectile paths (verified, eft_r / eft_det_a / eft_l_b): the fighter
  generator (ki blast launch jitter, 3 per shot; deflect and reflect direction, 2 each), the
  VU0 register (bomb throw direction, 3 per bomb), and the scene generator (volley spread,
  ring-shot placement). **The VU0 register is therefore simulation state**, and it is also
  drawn by purely visual particle modules at pool-dependent rates: a port must separate them.
- Effect modules draw from the fighter generator too: `BtlCharApi_GetDeflectDir` (two
  `BtlChar_RandF` per call, callers 0x1764E8 and 0x178630). So its sequence depends on effect
  update order. (verified)
- The fighter core itself (actions, movement, hits, collision, members, stats, flags) calls no
  generator other than `BtlChar_FrameMod` and, in clash C, `BtlChar_Rand`. (verified)

## Non-simulation state that reaches the simulation

Each of these is a way two peers could diverge with identical inputs.

| What | How it reaches the simulation | Status |
|---|---|---|
| **Load completion** | A transformation, fusion or member switch pushes a character-change request; **time is stopped (roster +0x274) on every frame that ends with a request active**, i.e. for as long as the model takes to load. Fighter generators, the frame counter, gauges and input are frozen meanwhile. The change itself is applied in `BtlChars_OnModelLoaded` when the load job ends; battle flags 0x800 / 0x1000 / 0x2000 also suspend updates while loads run | verified |
| **Load completion** | The self-destruct technique pushes a character-change request and waits on `BtlChange_IsLoadedFor` before firing; the partner object (second model for fusion / team techniques) exists only once its load job ends and handlers branch on it | verified |
| **Load completion** | The AI skips any frame on which an object load job is running | verified |
| **Controller removal** | `PadWatch` debounces pad presence; the battle pause check sets the pause flag when a required pad is missing (not in mode 7) | watcher verified; pause path read from disassembly |
| **Voice playback** | The battle sequence waits on `Voice_IsStopped` (with a 10 s timeout) in the intro and win talk; story scripts wait on voices too | verified |
| **Per-player camera option** | One of the per-side options from the save gates camera shake, and shake calls `rand()` five times per frame while active | gating verified; option source inferred |
| **Screen mode** | `Battle_IsSplitScreen()` changes the lock-on camera pose; the pose can reach fighter state through `cam->side` on certain cuts | pose dependence verified; consequence inferred, medium confidence |
| **Which side is human** | `BtlCam_GetDefaultView` depends on side control and feeds an "is this camera on screen" test used by the effect scene | verified code; consequence not traced |
| **Replay viewer** | Pad 0 picks the watched side during playback; it writes nothing in the simulation but feeds the same default-view test | verified |

A port has to make each of these identical on both peers, or remove the dependency (for
example by loading models ahead of time and resolving loads on a fixed frame).

## Fighter order (verified unless marked)

- The collision step tests and applies fighter 0 first; applying fighter 0's hit writes
  fighter 1's reaction and health before fighter 1's own hit is applied.
- The hit-stop loop's early exit favours roster order.
- `BtlChar_PlaceOnPath` places by player index.
- Movement, push-out and most cross-fighter reads are order-independent: they use per-pass
  position snapshots and last-frame flag and action values.
- (inferred) Effect hits resolve in the order of the effect scene's record list.

Both peers must agree on who is fighter 0.

## Story battles (verified)

Scripts wait on non-simulation state: the voice stream (`Talk`, `PlayVoice`, line triggers),
the music stream, and a raw pad-0 button wait. `Talk` also starts and stops lip movement (a
fighter object sub-state) from the stream's status. Online story battles would need fixed
durations in place of those waits. Versus modes run no scripts.

## Faces and voice language (verified, bobj_b)

Every battle object with a face draws libc `rand()` for blinks and talk patterns during
`BtlObj_UpdateAll` (unpaused frames). Which lip tracks play depends on a save-data flag
(inferred: voice language), so two peers with different settings consume `rand()` differently.
Faces need their own generator, or the setting must be synchronised.

## Simulation inside draw callbacks (verified)

`EftTechEvtTask_Draw`, a draw callback of the effect scene, steps the technique fire and end
timers and sets fighter flag 0xA7 (the flag that ends a technique's charge loop). It is guarded
to run once per frame, but a frame that does not call `BtlScene_Draw` does not advance it. A
headless or rollback build must run that step from the update. See systems/effects_stage.md.

## Camera

- Movement is relative to the fighter camera's `yaw` (fighter +0x4A0), not to the camera
  position. `yaw` depends only on opponent direction, fighter flags, the fighter's input record
  and facing. The movement code reads no other camera field. (verified on both sides:
  `btl_char_cam*.c` and `btl_char_move.c`)
- The camera's `side` value (+0x4A8) chooses between two camera cuts for some attacks
  (`BtlAct_PrepareAttack`). Cuts raise fighter flags and have their own durations, so `side`
  must be treated as simulation state. Whether an attack's two variants actually differ is in
  a data file and not checked. (verified code; consequence open)
- No pad is read by the fighter camera or by the battle camera module. The two pad-reading
  camera functions found earlier are dead debug code and a viewer screen. (verified code;
  reachability from the absence of callers)
- Camera cuts raise fighter flags, and the demo camera advances inside
  `BtlCam_UpdateOverride`, which the battle sequence waits on. Camera updates therefore cannot
  be skipped on re-simulated frames. (verified)

## Floating point

All game maths is single-precision. Three things need exact reproduction:

- `Mathf_WrapAngle` (behind `Mathf_Sin` / `Mathf_Cos`, about 180 call sites) pushes every
  angle below 2 pi up by 2 pi and brings it back, which quantises small angles. Skip it for
  in-range angles and results change. (verified code; quantisation inferred)
- `Mathf_SinFast` / `Mathf_CosFast` are a polynomial evaluated on the vector unit, and return
  different bits from the libm-based pair. (verified)
- The PS2's FPU and vector unit do not follow IEEE exactly. Two PCs running the same build
  agree with each other; matching PS2 results bit-for-bit (for replays recorded on a PS2, or
  cross-play) is a separate, harder problem.

## Display offset in positions (verified)

`BtlCharApi_GetPos`, used by the AI and by effects, returns the fighter position plus the
display offset (hover bob and camera-independent shake at pose +0x20). That offset is therefore
simulation input wherever those callers act on it.

## State to save for rollback (inferred from the verified structure)

The 0x280 roster, the two 0x1600 fighters and the two per-side arrays; the battle objects each
fighter drives (pose is copied both ways several times per frame); `gBattleWork`; the sequence
block; the effect scene and its tasks; the stage's rigid bodies; the AI block; the script
tasks in story battles; and the state of every generator in the table above.

## Open items

- Character-change loads: the fighter side waits only on `BtlChange_IsLoadedFor(player)` (see
  combat.md, "Character changes"). Making that true a fixed number of frames after the push
  (with the models preloaded) removes the dependency without touching the handlers. The same
  call gates the KO member switch (0xF6) and the self-destruct technique.
- Check in the attack and cut data whether left / right cut variants differ in flags or length.
  Readers of the camera `side` are now all known: `BtlAct_PrepareAttack` and actions 0x41, 0x45,
  0x46 and 0xBE; each only chooses between two cut ids.
- Decompile the pause check `func_0022F9F8` and confirm the controller-removal path.
- Decompile the fighter state machine, movement and hit detection (the bulk of the
  simulation), and the effect tasks that call `rand()`.
- The Wii build has online play; its game-side netcode has not been examined and would show
  what the developers themselves synchronised.

## HUD consumes libc rand() (found 2026-10-04)

The gauge part of the HUD (`HudGauge_UpdateHpTrail`, `HudGauge_UpdateAura`; src/battle/hud_b.c)
draws from libc `rand()` every unpaused frame: at least 30 draws per side for the aura sparks
plus 2 per shaking node. It runs from `Hud_Draw`. Since libc `rand()` also reaches simulation
code, the HUD is one more visual consumer that shifts a simulation stream; see
docs/systems/hud.md.

## Correction (2026-10-04): the "second MT19937 at 0x252F68"

It is not a generator: there are two instances (0x252F68 and 0x253ED8), each the key stream of
the character password codec (docs/systems/save_data.md). The state is seeded per call, read
and never twisted, and touches nothing shared. The only live draw in that range is
`ChrPass_Encode`, which takes two libc `rand()` values (menu only).

## The Wii build's online mode: first look (2026-10-06, from the text in its main.dol only)

Read from the readable strings of `sys/main.dol` of the USA Wii disc (no symbols; nothing disassembled yet).

- Networking is Nintendo's DWC library (Nintendo Wi-Fi Connection) on GameSpy's services: login, friend lists
  (GP), matchmaking ("ConnectToAnybody", "ConnectToFriends", server browsing), and GT2 for the connection between
  the two consoles, with "SendUnreliable" present: the consoles talk to each other directly; the servers only
  introduce them. Save file of the mode: `nocopy/DBZT3_WIFI`.
- Screens, from the names of the menu's objects (`mc_*` / `fl_*`): a Wi-Fi menu with a guide character; a friend
  list with add / delete, entry of a friend code on an on-screen keypad and a "my code" page; a friend match
  lobby; a matchmaking screen with both players' names, win counts and battle points and a "revenge" (rematch)
  marker; time counters on the selection screens; choice of map and music; a VS screen with a countdown; a
  ranking list; a results list with win percentages; and the "ability limit" / item cost fields of custom
  characters among the same objects.
- NOT known from this: what the two consoles exchange during a fight (inputs only or more), whether there is an
  input delay, and what happens on a mismatch or a lost connection. That needs the callers of the library's send
  and receive functions found in the PowerPC code.

## The PS2 main menu's hidden entry: "Dragon Net Battle" (2026-10-06)

- `MainMenu_Init` (src/menu/menu_a.c) lists items 0..10 and skips item 4 (`if (i == 4) continue;`); every other
  item has a mode (menu_overlay.md), item 4 has none. Listed with `BT3_MENU_ITEM4=1` (port only), it appears
  between Duel and Dragon World Tour as **"Dragon Net Battle"**, with its plate, label and icon from the PS2
  disc's own menu pictures (seen in a screenshot).
- The user's check in the running game: the guide speaks a line when it is highlighted; confirming it plays the
  confirm sound and nothing else happens (no hang).
- Plan: this is the entry point of online play. Work on it happens on the branch `netplay`.

## What is left of Dragon Net Battle on the PS2 disc, and the Wii's screens (2026-10-06)

Two read-only investigations (by subagents; the points marked "checked" I looked at myself).

**PS2 leftovers**
- `MainMenu_Input` (src/menu/menu_a.c) has `case 4: break;` (checked): no mode is chosen, the code falls through to
  the "fl_ok" plate animation and the confirm sound. No mode number is reserved for it; nothing network-related
  is in either program (no strings, no modules, no uncalled functions that fit).
- Main-menu pack `pzs3us1/00449.bin`: the four guides' lines for item 4 are message lines 32..35 ("You can compete
  with players from around the world. That's amazing." and three more), voice files 0x8719..0x871C; the label
  "Dragon Net Battle" is row 4 of two 512 x 256 sheets (off / on), the icon a spaceship, still and animated.
- `pzs3us1/00478.bin` (baseFile + 0x1E, which no loader in the source reads): a complete 44-line guide script of
  the online mode with Pan and Giru. Lines 0..5 are a "not available" scene ("Whoops, the spaceship's run out of
  energy... Return to the Main menu and have fun with a different mode, okay?"), lines 6..43 the online mode's
  own lines (Wi-Fi data, Friend Code, friend list, ranking, sending fighters and replays, searching).
- None of the Wii's online screens (movies, pictures) is on the PS2 disc.

**The Wii's online mode** (USA disc, `wzs3us1.afs` entry 461 "DragonNe...", three BPE-compressed sections; the
same pack / movie / text formats as the PS2 with the byte order swapped; pictures decoded: checked on two sheets)
- Top: Nintendo WFC Battle / Manage Friends / User Settings. Guides: Pan and Giru.
- Battle menu: Custom Battle (anyone, custom characters allowed) / Normal Battle (anyone, normal characters only)
  / Friend Battle / Ranking Battle / View Ranking / Battle Record. No other rule options exist (no time, rounds
  or handicap text).
- Matchmaking: "Search For Opponent" / "Search From Limited Opponents"; two player plates with name, Fighting
  Points, battles / wins / losses and Connection Errors; a countdown.
- Setup: the ordinary versus screens (character reel with DP totals, Normal / Custom 1-3, colour, Map Select, BGM
  Select, VS) with a two-digit countdown. Afterwards: win plate, points up or down, Rematch Request / End Battle.
- Friends: roster (battles / wins / losses per friend), enter a 12-digit Friend Code, show one's own. User
  Settings: a player name (on-screen keyboard), initialise the mode's data. Ranking: My Area / Top 10. Battle
  Record: per mode, wins, losses, consecutive wins, connection errors.
- Messages include "Searching for opponent...", "Opponent found!", "Waiting for opponent's input...", "Match
  interrupted.", "No activity for 60 seconds".
- The screen order and what the countdown does are inferred; main.dol was not analysed (how a fight is kept in
  sync is still unknown). The decoded sheets and the text are kept outside the repositories (game data).

## Stage 1: the state checksum (2026-10-06, branch netplay)

- `port/src/gs/state.c`: `BT3_HASH=<file>` writes one checksum per vertical blank (XXH3 over the game's global
  variables, its heap and the scratchpad); `BT3_HASH_AT=<n>` adds, at that blank, a checksum per 4 KB page and a
  dump of the regions. `port/tools/compare_hash.py` finds the first differing blank of two logs and, from two
  dumps, the differing bytes with the variable they are in. Which addresses are the game's own globals comes from
  the linker's map (`port/tools/make_state.py` -> `<program>.mem`, run at link time): about 440 KB in 5 ranges.
- Checksums are comparable between runs of the SAME program only: the state holds addresses of functions and
  variables, which differ between builds. Comparing a Linux and a Windows machine needs something else (a
  checksum of chosen values, or addresses normalised): open.
- **First findings, both fixed:**
  1. `Port_LowAlloc` on 64-bit Linux took its blocks from wherever mmap put them; the addresses end up in the
     game's memory (file handles, sound buffers: gSndRpcBuf, gFileReq, heap), so two runs differed from the third
     blank on. Now one region at a fixed address, blocks handed out in order and reused by size.
  2. That region (first at 0x30000000) and the game thread's stack (0x60000000) were at fixed addresses ABOVE the
     program, where the C library's heap starts at a random place within a gigabyte: the region was taken in
     about a third of the windowed runs, and the stack's address must have been taken now and then too (the
     program then stops at start with "cannot reserve": not seen reported, a few percent by the arithmetic).
     Both are below the program now (stack 0x02000000, region 0x13000000). This second fix belongs on the main
     line as well.
- **Result:** the same program, the same input, the same settings: 3 headless runs of the replay fight identical
  for 13,378 blanks; 10 windowed runs of session5 (menus and a split-screen fight, played from the pad recording,
  `BT3_MENU_ITEM4=0`) identical for 6,973 blanks and 5 for 12,956.
- **Differences still to look at** (same recording): sound on against `BT3_NOSOUND=1` differs from blank 1477;
  4:3 against 16:9 from blank 2112. Not yet compared: the frame limiter on against off, the render thread, the
  32-bit program, the Windows program.
- **A fight checksum** (the user's point: two players' machines legitimately differ in everything that belongs to
  the view, so what has to match is the fight): `BT3_HASH` lines carry, during a fight, a checksum of both
  fighters' health and position, the battle clock and the C library generator's state, and the values
  themselves; `compare_hash.py a b --fight` compares only those. session5's split-screen fight (about 9,500 blanks;
  nobody is hit in it, the fighters move a little, 4,700 clock ticks): identical between 4:3, 16:9 and 21:9 and
  between sound on and off, the generator's state included. To come: a fight with hits, one view against two
  views, a stage with the haze effect (which draws from the same generator, see above), ki and the fighters'
  action states in the checksum.
- **session6** (the user's recording with hits: health 40000 / 30000 -> 37420 / 16770 in 29 steps, split screen,
  played with `BT3_MENU_ITEM4=0 BT3_NOMOVIE=1`): the fight values are identical for about 16,000 blanks of fighting
  between 4:3, 16:9 and 21:9 and between sound on and off.
- **Open: the checksum of everything is not always the same between runs with the same settings.** Seen on
  session6: the runs fall into groups. Runs made up to about 22:49 agree with each other (one of them leaves the
  others at blank 13,518); runs made from about 22:55 agree with each other and differ from the first group from
  blank 4,658 on. The fight values are identical in all of them. Ruled out: the save file (unchanged, and a fresh
  copy per run changes nothing), a busy against an idle machine (same result), the controllers' state (constant
  in the port), a clock (nothing reads one). Not found: what changed between the groups. To do: keep a memory
  dump at blank 4,658 of every run so that the next time two groups appear they can be compared byte by byte.
  This matters for rollback (the whole memory is restored and re-run), not for the comparison between players.

## Stage 2: saving and restoring the state, first version (2026-10-06, branch netplay, 64-bit Linux only)

- `port/src/gs/state.c`: a snapshot is the checksum's regions, the port's own state memory (`Port_StateExtra`: the
  blocks of `Port_LowAlloc` and its allocator), the used part of the game thread's stack and the registers
  (`getcontext`); restoring copies it back from another stack and continues at the save point (`setcontext`).
  Which of the port's own files count as state is in `port/tools/make_state.py` (`PORT_STATE`: headless, the
  memory / file / memory card / system layers, the float and vector code); about 570 KB of variables now.
- `BT3_SYNCTEST=1`: every vertical blank the frame is run, rewound to the saved state and run again, and the two
  results compared, with the differing places printed. The mechanism works: frames are re-run from the saved
  state. (The first try stopped at once with "battle finished": the port's own counter of battles was not in
  the state and counted the re-run as a second battle. Hence PORT_STATE.)
- **What it shows on the replay fight, from the third blank: the port's file and sound layers cannot be rewound.**
  1. Files (`plat_file.c`): a handle given to the game holds the host's `FILE *`, and a read continues from the
     host file's own position. Re-running a frame opens the file again (another `FILE *`, the first one lost) or
     reads on from where the first run stopped (the heap then holds zeros where the first run had data), and a
     file closed in the first run is closed again: the test ends in an abort after five blanks.
  2. Sound (`gs/snd_adx.c`): the players handed to the game are slots of the sound code's own table, which is not
     part of the state: the re-run frame gets the next slot (`gAdxPlayerTbl` differs).
- Next: (a) a file handle that holds only what the game may see (which file, size, position) with the host's files
  kept beside it and every read positioned by the handle; (b) the sound code's bookkeeping that the game can see
  (which players exist, what they report) moved into the state, the audio itself left outside; then the memory
  card layer; then the test again until a whole fight passes.

## Stage 2, continued: the port's layers made rewindable; the test passes a whole session (2026-10-07)

Changes, each found by `BT3_SYNCTEST` and each leaving normal play as it was (the replay's result on all three
programs, and session6's fight values, are unchanged):
- **Files** (`plat_file.c`, new `plat_fcache.c`): a handle holds the file's relative path, size, position and
  status and nothing of the host; the host's `FILE`s are in a cache outside the state (32 files, least recently
  used closed), every read positioned from the handle.
- **Memory card** (`plat_mc.c`): the same split (open / mode / path / position are state; the host `FILE` beside
  it is reopened when it does not fit the state). The write path was not exercised by any test here (saving a
  game: to be tried by hand).
- **Stream players** (`gs/snd_adx.c`, new `plat_sndstate.c`): how many players exist is state. With
  `BT3_SYNCTEST` or `BT3_SOUND_TICKS=1` what a player reports (playing / played to the end) is counted in vertical
  blanks from the stream's length instead of taken from the sound device: the same on every machine. Normal play
  keeps the device's answer. On session6 without a sound device the two give the same fight values.
- **`PORT_HOST`** (`port_host.h`): a variable of a state file that is not state (host file objects, the
  process's arguments) goes into the section `.porthst`, which `make_state.py` leaves out.
- **`Port_LowAlloc` clears new blocks**: after a restore the memory above the restored end of its region still
  held the undone frames' blocks.
- **The thread library's data at the top of the game thread's stack is not part of a snapshot** (the control
  block, thread-local variables, the C library's per-thread memory cache): restoring them corrupted the C
  library's heap (crashes at random places).
- Test harness: a pad recording opened during the re-run frame is rewound to its start.

**Result (64-bit Linux):**
- the replay fight without a window: 8,400+ frames each run twice from a saved state, 0 differences, the fight's
  result unchanged;
- session6 with the window (menus, loading, the split-screen fight with hits): 25,200 frames each run twice, 0
  differences; and against a normal run of the same session (15,504 blanks in both) the checksum of everything
  is the same at every blank.

Not covered: the render thread and sound effects (`gs/snd_se.c`) as far as the game can see them (no difference
showed, but with `BT3_NOSOUND=1`); the movie player; saving to the memory card; Windows and the 32-bit program
(the save / restore itself is written for 64-bit Linux only); rewinding more than one frame.

## Rewinding several blanks at a time; the run-to-run difference explained (2026-10-07)

- `BT3_SYNCTEST_DEPTH=<n>` (up to 64): save, run n blanks noting each one's checksum, restore, run the n again and
  compare each: what online play does when an input arrives late. Replay fight without a window, 8 and 20 blanks
  at a time: 15,000+ blanks each run twice, 0 differences, the fight's result unchanged. session6 with the window,
  8 and 20 at a time: 14,400 and 15,000 blanks each run twice, 0 differences, and against a normal run of the
  same program the checksum of everything is the same at every blank (14,714 and 15,032 compared).
- **The "open" run-to-run difference above (groups of runs differing from blank 4,658, one from 13,518) is
  explained: it was the test, not the game.** session6's recording ends at about blank 4,656. From there on a
  playback read the REAL keyboard and controllers, so runs differed by whatever a controller reported at the
  time (the groups by time of day: a controller awake or asleep; the one run at 13,518: an input event). The
  multi-blank rewind showed it: the stretch across the recording's end did not repeat, because the first pass
  had closed the recording. Now the pads are idle for the rest of a run once a recording has ended (what the
  comment always said), and the file stays open so a restored state can read its last part again.

## Stage 3: frames that are only re-run are neither seen nor heard (2026-10-07)

- `gPortResim` (gs/state.c): while it is set, the frame's list is still walked (it carries the texture uploads and
  vertex programs later frames count on) but no draw is recorded, nothing is shown, the picture's frame counter
  stands still, sound effects do not start, and a stream that is asked to start the file it is already playing
  plays on.
- `BT3_SYNCTEST` now runs the pass that gets undone in this mode and the second pass normally
  (`BT3_SYNCTEST_LOUD=1`: both with output, as before). session6 with the window, rewinding 1 and 8 blanks:
  13,200 and 16,200 blanks each run twice, 0 differences; the checksum of everything equals a normal run's at
  every blank (13,722 and 15,182 compared); and the picture at three fixed blanks (2600, 3401, 4000) is
  byte-identical to the normal run's. (Screenshots taken by frame number do not line up between the two runs:
  the runs count frames differently around loading. By blank they do.)
- Normal play: the flag is never set; the replay's result and session5's picture are unchanged.
- Not measured yet: what a silent frame costs (the list is still walked); sound with a device during rewinds
  (all runs had `BT3_NOSOUND=1`).

## Measured: what a re-run blank costs (2026-10-07, Ryzen 7 9800X3D, session6's split-screen fight)

`BT3_GS_VERBOSE=1` with `BT3_SYNCTEST`: per vertical blank, re-run without output 1.5 to 1.7 ms, with output 3.1
to 3.2 ms; saving the state 0.75 ms, restoring it 0.6 ms (about 30 MB each way). A fight frame is two blanks. So
undoing and re-running 4 frames costs about 13 ms here, and by the factor measured earlier about 2.2 times that on
the i5 12th gen: most of one 33 ms frame. Walking the frame's list is what a silent blank still pays for; to be
cut (skip the vertex work, keep the uploads) when rollback is in.

## Stage 4, first step: two copies in lockstep (2026-10-07)

- `port/src/gs/net.c`: `BT3_NET_HOST=<port>` / `BT3_NET_JOIN=<address>:<port>`; UDP; each copy has one local
  player (host = pad 1, joiner = pad 2); at every vertical blank a copy sends its player's input for that blank
  (the last 16 in every packet) and waits for the other's; the game's pad reads are answered from the exchange on
  both sides. `BT3_NET_DELAY` (default 2 blanks). Nothing predicted, nothing rewound. Both copies run the same
  game from the first blank (they connect before it). Test hooks: `BT3_PAD_TABLE` (an ordinary run writes its
  input by blank and pad), `BT3_NET_SCRIPT` (a copy plays its player's column of that), `BT3_NET_LOSS`,
  `BT3_NET_LAG`.
- Two copies on one machine (64-bit Linux, windows open, each with its own copy of the save folder), each playing
  one player's column of session6's input:
  | delay | packets dropped | extra lag | fight values of the two copies | final health |
  |---|---|---|---|---|
  | 0 | 0 | 0 | identical for 13,071 blanks of fighting | 37420 / 16770 |
  | 2 | 0 | 0 | identical for 11,297 | 37420 / 16770 |
  | 2 | 20% | 0 | identical for 11,353 | 37420 / 16770 |
  | 3 | 30% | 4 ms | identical for 15,720 | 37420 / 16770 |
  With delay 0 the host's fight values also equal the ordinary offline run's (9,794 blanks compared). The final
  health is the original session's in every case.
- The checksum of EVERYTHING differs between the two copies from blank 147 (where the memory card is read): the
  two had different save folders, and the path of an open card file is part of the state. Expected, not chased.
- Not done: real keyboards / controllers as the input (only the script), two machines, the Windows program (it
  builds), what happens when a copy is closed (the other stops after 15 s), a check of the two copies against
  each other while they run, both players' saves and settings (the copies had the same save).

## One view per window (2026-10-07)

- Online, both machines run the two-player battle with its two cameras (the split-screen game, the one tested
  above) and each SHOWS only its own player's view, full screen. The game has the mechanism already:
  `BtlCam_UpdateOverride` gives one view the whole screen while its camera "has priority" (close-ups). Under PORT
  the local player's view takes that place when the game gives none priority (`Port_NetView`, gs/net.c); when the
  game does, both players see that view, as in the split-screen game.
- `BT3_VIEW=0|1` does the same without a connection. session6 shown three ways (split, player 1's view, player
  2's view; 16:9): the fight values, the generator's state included, are identical for all 13,170 blanks of
  fighting. So what a machine shows does not reach the fight (on this session).
- Two connected copies (delay 2): each window shows its own fighter from behind, full screen, at the same blank;
  fight values identical for 15,693 blanks; the original session's final health.
- Still the split-screen game underneath: the stage model is the split-screen one (a different, presumably
  lighter file), and the effects that are per view are computed for both.

## The session flow behind "Dragon Net Battle" (2026-10-07)

- Lobby: the window behind the menu entry (ui.cpp) has working Host / Join buttons (`Port_Lobby*` in gs/net.c: a
  greeting and its answer over UDP). When the two have found each other, each side starts the program again as
  the session (`relaunch`: `BT3_NET_SESSION=1`, its role, `BT3_SAVES=net_session` emptied first,
  `BT3_SOUND_TICKS=1`), and the two connect again and run in lockstep from the first blank.
- The session opens on the versus mode's CHARACTER SELECT (mode 39), not on the versus menu: that menu (mode 38)
  leaves only three values behind (who plays, battle type, DP limit, at +0x620 / +0x624 / +0x630 of the progress
  record), which `__wrap_Progress_Main` sets itself (1P vs 2P, single battle). Everything is unlocked with the
  game's `Save_UnlockAll` on the default save, so both sides have the same roster. The start-up before that
  (logos, memory card check) runs without picture, sound or real-time pacing (`Port_NetWarp`). The user's check:
  the two windows come up in the character select.
- Leaving: back from the character select is the versus menu (the host can change the battle type); back from
  there the game enters the main menu, where `MainMenu_Run` ends the session (`Port_NetLeave`: the program
  starts once more as it normally is, with the player's own save). A player who does not answer for 15 seconds
  ends it the same way.
- Two session copies on one machine, no input: the checksum of everything is identical on both for all 2,715
  blanks run (after the frame limiter's clock values were taken out of the state: PORT_HOST).
- Not tried: the lobby window itself (the buttons were not clicked in a test: the session was started with the
  variables it sets), a fight from this flow with real controllers, leaving, the Windows program.
- The user's test of the whole flow by hand (two windows on one machine, 2026-10-07): Host / Join in the lobby,
  both restart into the character select, a fight that stays in step, and on leaving to the main menu both
  copies start again as the normal game. Works as built.

## Saving and restoring the state on Windows (2026-10-07)

- `gs/state.c` on Windows: the registers with the compiler's minimal `__builtin_setjmp` / `__builtin_longjmp`, the
  copy back on another stack through `Port_CallOnStack` (Linux keeps `getcontext` / `setcontext`).
- `plat_mem.c`: Windows now uses the same region allocator for `Port_LowAlloc` as Linux (address space reserved
  at 0x13000000 or, if that is taken, the first free place from 0x30000000; pages committed a megabyte at a time
  as it grows) instead of its own pools and single reservations: blocks are no longer given back to the system,
  which a restore to an earlier state needs. The region is taken once at the program's start on both systems
  (a state restored to before it existed took it a second time, elsewhere), and where it is counts as host data.
  The game's stack end is recorded on Windows too (`sGameStackTop`).
- `make_state.py`: two game ranges are no longer joined over a gap that holds a variable of a file that is not
  state (plat_settings.c's lock lay in one: on Windows its address was restored with the game).
- **Windows program under Wine** (`BT3_SYNCTEST=1 BT3_SYNCTEST_DEPTH=8`): the replay fight without a window,
  44,400 blanks each run twice, 0 differences, the fight's result unchanged; session6 with the window (started
  from the folder that has the save: from another one the recording never reaches its fight, which a first run of
  this did), 27,600 blanks each run twice through the menus and the whole fight, 0 differences, final health
  37420 / 16770 as everywhere. Rewinding 1 at a time, the replay fight: 0 differences.
- Linux unchanged: session6 rewinding 8, 0 differences; the replay's result on all three programs; normal play's
  fight values as before.
- Not tried: a real Windows (only Wine); two Windows copies connected; Linux against Windows.

## A session without starting the program again (2026-10-07)

How it works (`gs/state.c`, "Exchanging the game's state"; 64-bit programs, the 32-bit one still restarts):

- A snapshot is taken at the first vertical blank of every run (`sBoot`): the same state on every machine with
  the same program, which is what the restart was for.
- Host / Join found the other player: at the game's next blank its present state is kept (`sOwn`, plus the
  emulated GS's memory, registers and the vertex unit, `Gs_StateKeep`, which a snapshot does not hold), the
  connection is made, and the game is put back to `sBoot`, now as a session (save folder `net_session`, no
  movies, sound by ticks). From there the flow is the old one (silent start-up, opens on the character select).
- Leaving (`Port_NetLeave`, from `MainMenu_Run` or the 15-second time-out): `sOwn` is put back, the GS memory
  with it, the online window closes. The player is at the blank the session was asked for, with their own save.
- The sound is made to fit the state each time (`Port_AdxResync`): every stream stops, and what the state now in
  place says is playing starts again from its beginning. `PortAdxView` holds file, volume and pan for that.

Found on the way:

- Moving every GS page's upload generation on (so nothing decoded in between is reused) also moved the pages that
  were never uploaded to away from 0, which is how the drawing code tells frame buffers from texture memory: a
  full-screen pass then went into GS memory and the scene came back darker. Pages at 0 stay at 0.
- `ADXT_GetOutVol` answered from the host's player, not from the state: the game fades a stream by reading the
  volume and setting a little less, so a frame run again read another value (seen by the rewind test once the
  volume was part of the state). It answers from the state now.
- A session left during its silent start-up kept the picture switched off.

Checked (two copies on one machine, `BT3_SESSION_TEST=<role>:<address>:<port>:<blank>`,
`BT3_SESSION_LEAVE=<n>`, `BT3_SESSION_AGAIN=<n>`):

- Linux and the Windows program under Wine, no window: several sessions in one run. In every session the two
  copies' checksums are the same at each of 1,500 blanks; after every return the state is the same, blank for
  blank, as a run that never left.
- Linux with the window: a session asked for in the middle of a fight of session6, which reached and drew its
  character select for a while, then left: the picture 4,000 blanks after the return is the same file as that of
  a run that never left. (The frames right after the return were not compared.)
- Rewind test on session6 (Linux depth 1 and 8, Wine depth 8): 0 differences. Replay result on all three
  programs; normal play's fight values unchanged.
- By hand (the user, two copies on one machine, from the Dragon Net Battle window): the session starts in the
  same window and leaving it brings the player back where they were; "reverting back works perfectly".
- Not checked: the sound after a return in particular (the automated tests ran without a sound device); sound effects that were sounding when the state changed; a real Windows; two
  machines.

## Linux against Windows (2026-10-07)

- One Linux copy hosting, the Windows program under Wine joining, no window, both fed the input of session6 by
  blank (`BT3_PAD_TABLE` of an ordinary run, played with `BT3_NET_SCRIPT`), `BT3_SOUND_TICKS=1`.
- The fight values (both health values, both positions, the clock, the random number state) are the same on the
  two at every one of 76,978 blanks of fighting; both end on 37420 / 16770, as the ordinary run does.
- The whole-state checksum cannot be compared between the two programs: they are linked differently, so the
  addresses the game stores in its own memory differ. Only the fight values were compared.
- Wine, not a real Windows; one machine (same processor on both sides: nothing here says two different
  processors agree, though the game's arithmetic is the port's own soft-float code and not the processor's).

## The release archives from this branch (2026-10-07)

- The archives lacked `<program>.mem` (the list of the game's variables, `make_state.py`): the program said so and
  went on with states that held no game variables, so a session "started" without the game going back to its
  first blank and the two sides never met (15-second time-out). `package.py` now puts the file beside the program
  (`Tenkaichi3Decomp.mem`, `Tenkaichi3Decomp.exe.mem`) and refuses to package without it; a program that does not
  find it does sessions the old way (starting itself again).
- Both archives built in the container, each installed from the disc image with its own setup program
  (`--install`, the Windows one under Wine; the demo fight self-test passed on both), then the Linux release
  program hosting and the Windows release program joining, no window: three sessions in one run connected and
  ended, and after each return each program's state was the same, blank for blank, as its own run that never left.
- Known: the test hook's own "leave" after a session that had already ended by time-out restores twice and
  crashed the Windows program (seen once, with the broken archive). `Port_NetLeave` itself is only reached in a
  session.

## Real Windows (2026-10-07)

- The user, with the two archives of commit 401fb60: Linux here and Windows in their VM (other processor: Intel
  i5 12th gen against this Ryzen), from the Dragon Net Battle window: "connected, were in sync and reverted to
  main menu when disconnecting". By eye; no checksum log was taken.

## What a silently re-run frame costs (2026-10-07, measurements for rollback)

Session6's fight, this machine (Ryzen 7 9800X3D), `BT3_SYNCTEST=1 BT3_SYNCTEST_DEPTH=8 BT3_GS_VERBOSE=1`:
a frame with picture 3.1 ms, re-run without output 1.53 ms, saving the state 0.74 ms, restoring it 0.64 ms.

- **Skipping all draw-list work in a re-run frame** (experiment: `run_chain` returned at once when `gPortResim`):
  1.53 -> 1.15 ms. That is the upper bound of what the renderer side can give (a real version has to keep the
  texture uploads and the rectangles drawn into GS memory). Not kept.
- **The rest is the game's own arithmetic.** Profile with no renderer (`perf`, `BT3_GS=none`): `f_mul` of
  src/port/vu0_b.c 25%, `add_core` 20% + 4% + 4% (its copies), `Sf_AddBits` 5%, `__mulsf3` 4%, `op_vmaddabc` 4%,
  `RefVu0_LtBits` 2.5%, `fpu_add` 2%: the soft-float add and multiply are well over half of a frame. Much of the
  rest by name is preparation for drawing done by the game itself (clipping, culling, projecting, lighting).
  The callers of `f_mul` could not be listed (no unwind information in the program for `perf`).
- **A quick exact path was tried and is slower.** Idea: for ordinary operands the exact product (48 bits) and the
  exact sum of operands at most 28 exponents apart (53 bits) fit a double, and the top bits of that double are
  the truncated single. Bit for bit equal to the long way on 1.2 thousand million pairs with all three compilers,
  and the replay and the fight values were unchanged; but the game's and the port's files are compiled with
  `-msoft-float -mno-sse`, so the double operations became library calls: a re-run frame went from 1.7 to 4.1 ms
  at the same place. Reverted. To gain anything this has to live in a file compiled with the processor's
  floating point, and one call per operation would about cancel the gain: the worthwhile form is whole kernels
  there (a matrix applied to a vector: 16 multiplies and 12 adds at once, in SIMD).

## The add and the multiply done by the processor, exactly (2026-10-07)

`port/src/plat_fastvec.c`, the one port file besides plat_libm.c compiled with hardware floating point
(`undefined.py`); the soft-float files reach it through calls with integer arguments (`-DSF_FAST_CALLS`,
`softfloat_ps2_inl.h`).

- Why it is exact: the PS2's add and multiply are the exact result cut toward zero at 24 bits. A product of two
  24-bit mantissas (48 bits) and a sum of operands at most 28 exponents apart (at most 53 bits) fit a double, so
  the double operation rounds nothing and clearing its low 29 mantissa bits is the cut. Everything else goes to
  the old integer code: zero and what the PS2 takes for zero, exponent 255, results outside the ordinary range,
  rounding to nearest (the experiment switches). Sums of operands further apart are the larger operand, or the
  single just below it when the signs differ (in the matrix kernel; the single add leaves them to the old code).
- `Port_FastMul`, `Port_FastAdd`: every truncating multiply and add of the port (the vector library, the FPU
  helpers `__mulsf3` / `__addsf3`, the VU0 operations). `Port_FastMtxApply`: a matrix applied to a vector
  (`mtx_apply` of src/port/vu0_b.c, 16 multiplies and 12 adds; 31% of a frame's simulation before, by a profile
  with frame pointers: `Mtx_MulVec4` 26%, `Mtx_Mul` 10%), in SSE2 two components at a time; it gives up and the
  caller goes the long way if any step leaves the covered cases.
- Check: `port/tools/fastvec_check.c` (build line in its header) compares all three with the old code on random
  operands of four kinds (any bits, near 1.0, edges and zeros, few bits). 600 million matrices and 3.2 thousand
  million single adds and multiplies with clang, 40 to 100 million matrices each with gcc -m32 (x87), gcc -m32
  -msse2 and the Windows compiler under Wine: 0 differences.
- In the game: the replay's result on all three programs; session6's fight values the same as the build before
  (16,968 blanks), 32-bit against 64-bit (21,325 blanks), Linux against the Windows program connected (71,813
  blanks); rewind test 0 differences.
- Time (session6, same two places as before, this machine): a re-run frame 1.71 -> 1.20 ms and 1.52 -> 1.08 ms;
  a frame with picture 3.57 -> 3.05 and 3.10 -> 2.66 ms. The three functions are now 53% of a frame's simulation
  (`Port_FastAdd` 19%, `Port_FastMul` 18%, `Port_FastMtxApply` 17%).
- Traps met: `-fno-builtin` turns `memcpy` of 4 or 8 bytes into a library call (the first version was slower
  than the soft-float code: `__builtin_memcpy`); a first SSE2 version is 600 instructions and only a little
  faster than the plain one, the range checks after every step are most of it.
- Where the single adds and multiplies come from now (profile with frame pointers:
  `BT3_PORT_CFLAGS="-fno-omit-frame-pointer -fno-optimize-sibling-calls"` for undefined.py, then `perf record -g`):
  `mtx_apply` 16% (`Mtx_MulVec4` 14%, `Mtx_Mul` 12%), `op_vmaddabc` 10%, `ClipPoly_ClipPlane` 10%, `fpu_add` 8%,
  `BtlObjPose_CalcMatrices` 7%, `StgFrustum_TestPart` 6%, `op_vmaddbc` 6%, `ClipPlane_DistArray` 5%,
  `Quat_ToMtx` 4%: spread out. The next kernels worth having whole would be the four-component VU0 operations
  (`op_vmulabc`, `op_vmaddabc`, `op_vmaddbc` of src/port/vu0_a.c) and `Mtx_Mul` as one piece.

## The roll ring: a save per blank that stores only the pages written (2026-10-07)

`gs/state.c`, "The roll ring" (`roll_save`, `roll_back(k)`; nothing uses it yet but the rewind test with
`BT3_SYNCTEST_ROLL=1`; normal play never starts the tracking).

- Measured first: of the 7,550 pages (30 MB) a whole save copies, a blank of the fight changes 70 to 90.
- The heap and the port's block region are not copied. Linux: their pages are read-only, the first write to a
  page faults (`on_write_fault`: note the page, open it), and the pages are closed again at the next save.
  Windows: the regions are allocated with `MEM_WRITE_WATCH` and `GetWriteWatch` lists the pages (the heap is NOT
  at the PS2's address in the Windows program but in a `low_alloc` block at 0x30000000: that allocation needed the
  flag too, or the call fails with error 87 and nothing is tracked).
- A copy of both regions as of the newest save (the shadow) supplies each written page as it was; it goes to the
  save before's list. Going back k saves: pages written since the newest save from the shadow, then each save's
  list, newest first. Variables, stack and registers are copied whole per save (the old `state_save`, without the
  two regions). 64 saves are kept. A whole state loaded by other means (`state_load`: the session switch) empties
  the ring.
- `Port_StateTouch`: a `read()` into a read-only page does not fault, it fails. The three places that let the
  system write file data straight into game memory (plat_fcache.c, plat_mc.c, the pad recording) announce it.
- Results, session6 with the window, this machine: saving 0.74 -> 0.08 ms; going back 4 / 8 / 20 saves 0.29 /
  0.36 / 0.61 ms (a whole restore was 0.64); a re-run blank 1.27 ms (was 1.14: the faults, about 80 a blank).
  0 differences at depth 1, 4, 8 and 20 on Linux and at 1 and 8 on the Windows program under Wine; the old
  whole-copy test, the session switch test and normal play unchanged.
- Not checked: a real Windows (Wine's write tracking is its own implementation); memory use (the shadow is 28 MB
  plus the block region's used part, each save's list about 0.3 MB).

## Less list work in a re-run frame (2026-10-07)

- `GsVu1_Call` returns after its register bookkeeping when `gPortResim`: the vertex program is not run (its whole
  output is primitives). Programs, unpacked data and the VIF registers are still kept up by the list walk, which
  an online session's silent start-up needs (everything loaded once on the way to the character select).
- `vertex()` (gs_core.c) collects nothing when `gPortResim`, except sprites into TEXTURE memory (frame width 1:
  the palettes the game paints over, which later frames read). Uploads and register writes are untouched.
- A re-run blank 1.27 -> 1.13 ms (the experiment that skipped the whole list was 0.38 ms better than nothing
  skipped; this takes 0.14 of it, the rest is uploads and the walk itself).
- Picture: with a rewind every 8 blanks (`BT3_SYNCTEST_ROLL=1`) the screenshots at blanks 2700, 4500 and 6500 of
  session6 are the same files as a plain run's; the session's character select after its silent start-up is the
  same file as before.

Where rollback's cost stands (session6, this machine): save 0.08 ms, back 4 / 8 saves 0.29 / 0.36 ms, a re-run
blank 1.13 ms, a blank with picture 2.7 ms. A frame with a 4-blank rollback: about 0.3 + 4 x (1.13 + 0.08) + 2.7
= 7.8 ms; 8 blanks: 12.7 ms. At the start of the day: 0.64 + 4 x (1.53 + 0.74) + 3.1 = 12.8 and 21.9 ms.

## Rollback (2026-10-07)

`gs/net.c`, `roll_tick`; off unless `BT3_NET_ROLLBACK=<n>` (the most blanks the game runs ahead of the other
player's last known input; beyond that it waits, as lockstep does every blank). 64-bit programs (the roll ring).

- Every blank: the local input is entered for the blank `BT3_NET_DELAY` later and sent; the state is saved
  (`Port_RollSave`) before the blank reads its pads; the other player's pad reads their input for this blank if it
  has arrived, else their last known input, and what it was given is remembered (`sUsed`).
- When input arrives that differs from what a past blank was given, `Port_RollBack` goes to that blank's save and
  the blanks up to the present run again with `gPortResim` (no picture, no sound, no pacing wait), then the
  present goes on. All of gs/net.c's own variables are host data, so a rollback does not touch them.
- `BT3_NET_LATENCY=<ms>`: testing, everything sent waits that long in a queue (a line with that delay one way).
  The older `BT3_NET_LAG` sleeps in the blank and so slows the whole copy.
- Checks, both copies fed session6's input by blank (`BT3_NET_SCRIPT`), run in real time (`BT3_PACED=1`, no
  window), the checksum log read as "the last line written for each blank" (a blank run again is logged again):
  - rollback 4, 30 ms: 23 to 120 rollbacks per 600 blanks of 1 to 2 blanks each; rollback 8, 80 ms: 5 blanks
    each; rollback 6, 50 ms with 15% of the packets dropped: 3.2 blanks each. In every run the two copies' fight
    values are the same at every blank compared (3,751 to 4,351 blanks of fighting), and the same as a lockstep
    run with the same input delay.
  - Linux against the Windows program under Wine, rollback 6, 50 ms: the same (4,323 blanks of fighting).
  - Two windows in real time, rollback 4, 40 ms: in step; blanks 16.65 to 16.71 ms apart, none late.
  - The session switch test with rollback on: sessions connect and end as before.
- Seen: in the two-window run one copy did nearly all the rollbacks (359 against 6). Nothing keeps the two copies'
  clocks together yet: the one that is ahead guesses, the one behind always has the input already.
- Not done: keeping the two copies in step in time; a setting in the Dragon Net Battle window (it is the
  environment variable for now); what a rollback does to a pad recording being played (the recording is rewound
  with the state: fine for the tests' scripts, which are read by blank number); real Windows; two machines.

## Keeping the two copies together in time (2026-10-07)

- Each input packet now carries how many blanks the sender is beyond the input it has from the other side
  (`ahead`, taken when sending; the packet's header is 20 bytes). On an even line the two numbers are equal; the
  copy whose clock is ahead has the larger one, by twice the clocks' difference. When the smoothed difference
  reaches a blank and a half, that copy lets its blanks come a millisecond later each (`gPortPaceShiftNs`, the
  pacing grid of plat_stub.c moves) until they agree. Only with rollback on. `BT3_NET_NOBALANCE=1` turns it off.
- The uneven rollback counts of the first two-window run were not the clocks: in session6's input player 1 does
  nearly everything, so only the copy that has to guess player 1 goes back. The clocks were half a blank apart.
- Test (`BT3_NET_SKEW=60`: one copy falls 60 ms behind at blank 1500; rollback 8, 40 ms): without balancing the
  other copy stays 6 blanks ahead and every rollback is 6 blanks; with it, it slows by 72 ms over the next
  blanks, both are 2 to 3 ahead again and rollbacks are 2 to 3 blanks. Fight values the same on both either way.

## Rollback on a real Windows (2026-10-07)

- The user, with the two archives of commit bbf72ff (Linux here, Windows in their VM, another processor), rollback
  on: "it worked and stayed in sync". By eye; no checksum log. Not known yet: whether `BT3_NET_LATENCY` was set
  (without it, on a local network, the game hardly ever goes back, so the saves are exercised on Windows but the
  going back barely is), and how long a frame with a rollback takes there.

## Choices in the window; the end of a match (2026-10-07)

- Dragon Net Battle, Host tab: Rollback (off, up to 2 / 4 / 6 / 8 frames; 4 to begin with) and input delay (0 to
  6 frames; 1 to begin with), kept in the settings file (`net_rollback`, `net_delay`). `Port_NetOptions` hands
  them to gs/net.c; the environment variables still win, for tests.
- The host's answer to the greeting (`T_HELLO_ACK`, now 16 bytes) carries its delay and rollback limit and the
  joining side takes them. The delay has to be the same on both sides; the rollback limit need not be (a copy
  that rolls back plays against one that waits). The joining side no longer counts as connected through an input
  packet, only through that answer, and its input tables are set up after it.
- `T_BYE`: sent three times by `Port_NetLeave`. The other side stops at once with "The other player left the
  match." Without it: 6 seconds (was 15) with no input, then "The connection to the other player was lost."
  Either way the copy goes back to its own game (in a session) and the line is shown over the picture for 6
  seconds (`Port_UiNotice`, ui.cpp). While a copy waits those 6 seconds its picture stands still.
- Checked without windows: a Windows joiner (Wine) started with nothing set takes delay 1 / rollback 4 from a
  Linux host, fight values the same on both and as lockstep; one side leaving: the other is told at the next
  blank and its own game goes on where it was; one side killed: the other gives up after 6 seconds and its own
  game goes on; the session switch test as before.
- Not looked at: the window's new controls and the line over the picture (no automated way here to see the
  overlay; screenshots do not contain it).

## The memory card on this branch (2026-10-07)

plat_mc.c was split into state and host data for the state saves; saving had not been tried since.

- The user recorded `port/build/save1.pad` on an empty card (`BT3_SAVES=<empty folder> BT3_NOMOVIE=1
  BT3_MENU_ITEM4=0`): a new game, the save created, and saved again.
- Played back without a window from an empty card: this branch, the main line (branch `port` at d39fd80, built in
  a work tree with the same data tables), this branch a second time, the Windows program under Wine and the
  32-bit program all write the same three files, byte for byte, and they are the files the user's own play wrote
  (`BASLUS-21678DBZT3` 16,384 bytes, `icon.sys` 964, `dbzsm.ico` 40,090).
- Reading it back: started again on that card, the game's state differs from a start on an empty card from the
  blank the card is read, so the save is taken in; with session6's input both builds leave the same save behind.
- Not covered: a card that is full or damaged, the second slot (the port has none), saving during an online
  session (it goes to the session's own folder, which is emptied at the start of each).

## A meter, the ping, and a version in the greeting (2026-10-07)

After the first match over the internet (the user and a friend on Windows, same city, default settings, machines
like the user's): "we both felt fps lag", a constant low frame rate on both sides. Not explained yet; with a short
line and fast machines neither the cost of going back nor waiting for late input accounts for it, which leaves the
pacing (the two copies kept in step) as the suspect. The meter is there to see it.

- F1 -> Video -> "Show frame rate, and the connection in an online match" (setting `meter`; `BT3_METER=1`): frames
  shown per second and the game's speed (vertical blanks really gone through per second, of 60: `gPortLiveBlanks`,
  not counting blanks run again), and in a match the ping, how often per second the game went back and how many
  frames, how long and how often it waited for the other side, the input delay and the rollback limit.
- Ping: every input packet carries its send time, the other side's last send time that arrived and how long ago
  that was (the header is 32 bytes now); the round trip is now - echoed time - their holding time, and the
  smallest of the last 64 is shown (a packet waits in the socket for the next blank's look on both sides, up to
  two blanks on a single measurement).
- The greeting and its answer carry `NET_VERSION` (2). A copy of another version does not get an answer; a
  joining copy that gets an old answer says "The host's game is a different version". 0.1.8 and 0.1.9 say no
  version (they count as 1) and cannot play against this.
- Checked: the meter seen in a connected run (60 fps, speed 100%, ping, rollbacks, waits); a rollback match of
  the recorded input, Linux against the Windows program under Wine, with the new packets: fight values the same at
  all 3,723 blanks of the fight. Not checked: the version messages (no old copy was run against it).

## The first internet match explained; automatic input delay (2026-10-07)

- The user's screenshots of the meter in that match: ping 218 ms, speed 85 to 90%, "waited" 930 to 1010 ms per
  second on 40 to 59 of the 60 blanks, every rollback 4 frames (the limit), with the defaults of then (delay 1,
  rollback 4). The line was slow because the user was on a VPN with Tailscale on top (their words; not measured
  further). Half of 218 ms is 6.5 blanks: with 1 blank of delay the game would have to run about 6 blanks on
  guesses, the limit was 4, so it waited for input at nearly every blank.
- Reproduced with `BT3_NET_LATENCY=109` (220 ms round trip measured), delay 1, rollback 4: 417 waits per 600
  blanks and 3,941 blanks in 75 s where a full-speed run does 4,444 (89%): the same picture.
- Now: the host measures the round trip when a match starts (12 pings in 0.4 s, the smallest; `T_PING` / `T_PONG`),
  chooses the delay from it if that is automatic (`auto_delay`: about ceil(trip / 2 / 16.7 + 1) - 4 blanks, 1 to
  6) and sends its choices (`T_CONFIG`, repeated until `T_CONFIG_ACK`); the joining side waits for them. Host tab:
  Input delay "Automatic" (the default; `BT3_NET_DELAY=auto`) or 0 to 6 frames; the rollback limit starts at 8.
  The settings have new names (`net_rollback2`, `net_delay2`) so that the old defaults do not stay with those who
  hosted once.
- Checked, two copies, the recorded input, 75 s each: 220 ms -> delay 4, 0 waits, rollbacks of 3 blanks, 4,444
  blanks; 22 ms -> delay 1, rollbacks of 1 blank; 102 ms -> delay 1, rollbacks of 3 blanks; fight values the same
  on both copies in every run.
- Not done: the ping shown in the lobby before the match; changing the delay during a match when the line
  changes; the measurement is the host's only.

## Room codes and a relay (2026-10-09, branch matchmaking)

The aim: a match without port forwarding. Three parts, all checked against the real services.

**The service** (`port/matchmaking`, a Cloudflare Worker with a D1 table): the host posts its name and addresses and
gets a six-character code; the one who joins posts the code and gets the host's addresses, and the host, asking
every two seconds, gets the joiner's. Rooms last ten minutes and are given up as soon as both are known. The
game speaks to it with the system's HTTPS (WinHTTP on Windows; the curl library, loaded when needed, on Linux; the
`curl` program if neither is there), on a thread (`net_match.c`).

**The addresses** a game posts: what a STUN server sees (`stun.cloudflare.com`, then Google's), asked from the very
socket the match will use, and the local network address with that socket's port. Both sides then send to every
address of the other every 200 ms (the joiner its greeting, the host an empty "knock", `T_PUNCH`): a router lets a
packet in from where one has just gone out to. The address that answers is the one the match uses.

**The relay** (`net_relay.c`), for pairs whose routers do not allow that. Only the host uses it: it asks Cloudflare's
TURN service for a relayed address and posts it with its others (`relay=ip:port`); for the joiner it is one more
address, tried when the direct ones have been silent for three seconds. What arrives there reaches the host
wrapped in a "data indication", and the host's packets to that player go out wrapped in a "send indication" (36
bytes more each). `net.c` sends and receives every packet through `net_send` / `net_recv`, which do the wrapping.
The login for the TURN service is made by the Worker for each room (the key stays in the Worker's secrets) and is
good for three hours. The client is written here (RFC 5766 over UDP: Allocate with the long-term login,
CreatePermission, Refresh, Send and Data indications; MD5 and HMAC-SHA1 for the login) rather than taken from a
library: with one side only and no negotiation it is about 450 lines.

Verified:
- The Worker's whole sequence by hand (host, poll, join, wrong version, full room, wrong key, leave).
- The matchmaking client alone, two processes: each learns the other's public and local address. The Windows build
  of it under Wine reaches the Worker through WinHTTP.
- The relay client alone against Cloudflare: a packet sent to the relayed address from another socket arrives
  wrapped, the answer goes back through the relay; 40 more of two sizes, with the host's socket opened again in
  between.
- Two copies of the 64-bit game on one machine, without windows (`BT3_LOBBY=host`, `BT3_LOBBY=join:CODE`): a room
  code through the real Worker, then a match; with `BT3_RELAY_ONLY=1` (the joiner tries nothing but the relay
  address) the match runs through Cloudflare's relay. Whole-state checksums equal on every blank compared
  (about 2,700 a run), three runs through the relay and two direct; round trip through the relay 18 ms here.

Found on the way:
- **The socket must not be closed between the lobby and the match.** The lobby used to close its socket and the
  session opened a new one on the same port. For those 20 ms the other side's packets met a closed port, the
  system answered "port unreachable", and Cloudflare's relay then passed nothing more from that player: the
  lobby connected through the relay and the match never began. The lobby's socket is now handed to the session
  (`sHandSock`); greetings and answers of the lobby that are still in it are recognised by their length.
- **Cloudflare's TURN service sometimes answers nothing at all to one conversation** (every request from one local
  port, six in a row) while another port gets through at once; about one in ten here, on port 3478 and on 53. The
  Allocate is therefore tried on the other port after two silent requests. An answer can also be lost in the
  middle: a request that got no answer is sent again unchanged (same transaction number), so that the server
  repeats its answer; with a new number the second request was refused as "437, an address is held already"
  and the address given in the lost answer was never learned. A 437 is now answered by giving the address up and
  asking anew.
- A relay request with an address of a private network is refused (403); harmless, the public one is accepted.
- `xor_addr(attr_find(..., &len), len, ...)` read `len` before it was set: the same order-of-evaluation trap the
  bug search had listed in the game's own code.

**Channels.** Once the host knows the other player's address it binds a channel to it (ChannelBind), and the
match's packets then travel as channel data, 4 bytes longer each, instead of each inside an indication (36 bytes):
what ICE libraries do for relayed data. `BT3_RELAY_NOCHAN=1` keeps to indications.

**Two networks (the user, 2026-10-09):** a PC on a home line and one on a mobile hotspot behind carrier NAT: a room
code connects them and the match plays; with `BT3_RELAY_ONLY=1` on the one who joins, the same through the relay,
at full speed, ping about 30 ms. Linux and Windows. (Played with the build before channels.)

**Seen and not explained: a relayed match between two copies behind one router crawls.** With both players on one
network and the relay forced, about four matches in ten drop to some 10 blanks a second roughly ten seconds after
they begin and stay there (the user saw it between a Windows and a Linux machine: "waited 1000 ms/s", 15 frames a
second on both). Measured in such a match: each side sends about 220 packets a second (the lockstep's repeats
while it waits), all through the relay, none refused by the system; each side receives 3 or 4 a second; the
system's UDP counters show them not arriving at the machine (no drops for a full buffer). The states stay equal.
Ruled out by experiment: the indication format (5 slow of 12 with channels bound), the host's knocking (1 slow of
the first 5 without it), packet size, rate and content (a stand-alone sender through the same relay, game-shaped
packets of 320 bytes at 330 a second each way for 45 seconds, several runs, the same again after a refused
permission: all arrive). What every slow case has in common is two senders with one public address; whether the
home router or Cloudflare limits that is not known. It does not arise in use (two players on one network reach
each other at the local address and never use the relay) and did not happen between two networks.

Not verified: a relayed match on real hardware with the channel build; a session
longer than the login's three hours; the 32-bit build, which restarts the program for a session and so loses the
relay address (it still connects directly).

(Earlier list, before the two-network test:) Not verified then: two machines on two networks (the direct way through two real routers, and the relay where it is
needed); real Windows (WinHTTP there, and the relay code's Windows build has only been compiled); a session
longer than the login's three hours; the 32-bit build, which restarts the program for a session and so loses the
relay address (it still connects directly).
