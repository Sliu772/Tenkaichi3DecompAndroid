; ModuleID = '/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid/src/menu/menu_i_b.c'
source_filename = "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid/src/menu/menu_i_b.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-ios15.0.0"

@gBootCard = local_unnamed_addr global i32 0, align 4
@gMenuArc0 = external local_unnamed_addr global i32, align 4

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define void @BootCard_OnFlowDone() #0 !dbg !10 {
  %1 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !14
  %2 = getelementptr inbounds nuw i8, ptr addrspace(271) %1, i32 8, !dbg !15
  %rb1 = ptrtoint ptr addrspace(271) %2 to i32
  %rb2 = zext i32 %rb1 to i64
  %rb3 = getelementptr i8, ptr @_mh_execute_header, i64 %rb2
  %3 = load i32, ptr %rb3, align 4, !dbg !16
  %4 = or i32 %3, 1, !dbg !16
  %rb4 = ptrtoint ptr addrspace(271) %2 to i32
  %rb5 = zext i32 %rb4 to i64
  %rb6 = getelementptr i8, ptr @_mh_execute_header, i64 %rb5
  %p32st.1 = getelementptr i8, ptr %rb6, i64 0
  store i32 %4, ptr %p32st.1, align 4, !dbg !16
  %5 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !17
  %6 = getelementptr inbounds nuw i8, ptr addrspace(271) %5, i32 8, !dbg !18
  %rb7 = ptrtoint ptr addrspace(271) %6 to i32
  %rb8 = zext i32 %rb7 to i64
  %rb9 = getelementptr i8, ptr @_mh_execute_header, i64 %rb8
  %7 = load i32, ptr %rb9, align 4, !dbg !19
  %8 = or i32 %7, 2, !dbg !19
  %rb10 = ptrtoint ptr addrspace(271) %6 to i32
  %rb11 = zext i32 %rb10 to i64
  %rb12 = getelementptr i8, ptr @_mh_execute_header, i64 %rb11
  %p32st.2 = getelementptr i8, ptr %rb12, i64 0
  store i32 %8, ptr %p32st.2, align 4, !dbg !19
  %9 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !20
  %10 = getelementptr inbounds nuw i8, ptr addrspace(271) %9, i32 12, !dbg !21
  %rb13 = ptrtoint ptr addrspace(271) %10 to i32
  %rb14 = zext i32 %rb13 to i64
  %rb15 = getelementptr i8, ptr @_mh_execute_header, i64 %rb14
  %p32st.3 = getelementptr i8, ptr %rb15, i64 0
  store i32 15, ptr %p32st.3, align 4, !dbg !22
  ret void, !dbg !23
}

; Function Attrs: nounwind uwtable(sync)
define void @BootCard_Init(i32 noundef %0) local_unnamed_addr #1 !dbg !24 {
  %2 = tail call ptr @Heap_Alloc(i32 noundef 20, i32 noundef 32, i32 noundef 0, i32 noundef 2) #3, !dbg !25
  %rb16 = ptrtoint ptr %2 to i64
  %rb17 = ptrtoint ptr @_mh_execute_header to i64
  %rb18 = sub i64 %rb16, %rb17
  %rb19 = trunc i64 %rb18 to i32
  %rb20 = icmp eq ptr %2, null
  %rb21 = select i1 %rb20, i32 0, i32 %rb19
  %3 = inttoptr i32 %rb21 to ptr addrspace(271), !dbg !25
  store ptr addrspace(271) %3, ptr @gBootCard, align 4, !dbg !26
  %4 = tail call ptr @memset(ptr noundef %2, i32 noundef 0, i32 noundef 20) #3, !dbg !27
  %5 = load ptr addrspace(271), ptr @gMenuArc0, align 4, !dbg !28
  %6 = getelementptr inbounds i32, ptr addrspace(271) %5, i32 %0, !dbg !29
  %rb22 = ptrtoint ptr addrspace(271) %6 to i32
  %rb23 = zext i32 %rb22 to i64
  %rb24 = getelementptr i8, ptr @_mh_execute_header, i64 %rb23
  %7 = load i32, ptr %rb24, align 4, !dbg !29
  %8 = and i32 %7, -4, !dbg !30
  %9 = getelementptr inbounds nuw i8, ptr addrspace(271) %5, i32 %8, !dbg !31
  %10 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !32
  %rb25 = ptrtoint ptr addrspace(271) %10 to i32
  %rb26 = zext i32 %rb25 to i64
  %rb27 = getelementptr i8, ptr @_mh_execute_header, i64 %rb26
  %p32st.4 = getelementptr i8, ptr %rb27, i64 0
  store ptr addrspace(271) %9, ptr %p32st.4, align 4, !dbg !33
  %11 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !34
  %rb28 = ptrtoint ptr addrspace(271) %11 to i32
  %rb29 = zext i32 %rb28 to i64
  %rb30 = getelementptr i8, ptr @_mh_execute_header, i64 %rb29
  %12 = load ptr addrspace(271), ptr %rb30, align 4, !dbg !35
  %rb31 = ptrtoint ptr addrspace(271) %12 to i32
  %rb32 = zext i32 %rb31 to i64
  %rb33 = getelementptr i8, ptr @_mh_execute_header, i64 %rb32
  %rb34 = icmp eq i32 %rb31, 0
  %rb35 = select i1 %rb34, ptr null, ptr %rb33
  %13 = getelementptr i8, ptr %rb35, i64 0, !dbg !34
  %14 = tail call ptr @Sprite_Unpack(ptr noundef %13, ptr noundef null, ptr noundef null) #3, !dbg !36
  %rb36 = ptrtoint ptr %14 to i64
  %rb37 = ptrtoint ptr @_mh_execute_header to i64
  %rb38 = sub i64 %rb36, %rb37
  %rb39 = trunc i64 %rb38 to i32
  %rb40 = icmp eq ptr %14, null
  %rb41 = select i1 %rb40, i32 0, i32 %rb39
  %15 = inttoptr i32 %rb41 to ptr addrspace(271), !dbg !36
  %16 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !37
  %17 = getelementptr inbounds nuw i8, ptr addrspace(271) %16, i32 4, !dbg !38
  %rb42 = ptrtoint ptr addrspace(271) %17 to i32
  %rb43 = zext i32 %rb42 to i64
  %rb44 = getelementptr i8, ptr @_mh_execute_header, i64 %rb43
  %p32st.5 = getelementptr i8, ptr %rb44, i64 0
  store ptr addrspace(271) %15, ptr %p32st.5, align 4, !dbg !39
  %18 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !40
  %19 = getelementptr inbounds nuw i8, ptr addrspace(271) %18, i32 4, !dbg !41
  %rb45 = ptrtoint ptr addrspace(271) %19 to i32
  %rb46 = zext i32 %rb45 to i64
  %rb47 = getelementptr i8, ptr @_mh_execute_header, i64 %rb46
  %20 = load ptr addrspace(271), ptr %rb47, align 4, !dbg !41
  %21 = getelementptr inbounds nuw i8, ptr addrspace(271) %20, i32 4, !dbg !42
  %rb48 = ptrtoint ptr addrspace(271) %21 to i32
  %rb49 = zext i32 %rb48 to i64
  %rb50 = getelementptr i8, ptr @_mh_execute_header, i64 %rb49
  %22 = load i32, ptr %rb50, align 4, !dbg !42
  %23 = and i32 %22, -4, !dbg !43
  %24 = getelementptr inbounds nuw i8, ptr addrspace(271) %20, i32 %23, !dbg !44
  %rb51 = ptrtoint ptr addrspace(271) %24 to i32
  %rb52 = zext i32 %rb51 to i64
  %rb53 = getelementptr i8, ptr @_mh_execute_header, i64 %rb52
  %rb54 = icmp eq i32 %rb51, 0
  %rb55 = select i1 %rb54, ptr null, ptr %rb53
  %25 = getelementptr i8, ptr %rb55, i64 0, !dbg !45
  tail call void @Dialog_Init(ptr noundef %25, ptr noundef null, i32 noundef 0) #3, !dbg !46
  tail call void @McFlow_Init(i32 noundef 1) #3, !dbg !47
  tail call void @McFlow_SetDoneCb(i32 noundef 0, ptr noundef nonnull @BootCard_OnFlowDone, ptr noundef null) #3, !dbg !48
  tail call void @McFlow_SetDoneCb(i32 noundef 1, ptr noundef nonnull @BootCard_OnFlowDone, ptr noundef null) #3, !dbg !49
  ret void, !dbg !50
}

declare !dbg !51 ptr @Heap_Alloc(i32 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !53 ptr @memset(ptr noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !54 ptr @Sprite_Unpack(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !55 void @Dialog_Init(ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !56 void @McFlow_Init(i32 noundef) local_unnamed_addr #2

declare !dbg !57 void @McFlow_SetDoneCb(i32 noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @BootCard_Term() local_unnamed_addr #1 !dbg !58 {
  tail call void @Dialog_Term() #3, !dbg !59
  tail call void @McFlow_Term() #3, !dbg !60
  %1 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !61
  %2 = getelementptr inbounds nuw i8, ptr addrspace(271) %1, i32 4, !dbg !62
  %rb56 = ptrtoint ptr addrspace(271) %2 to i32
  %rb57 = zext i32 %rb56 to i64
  %rb58 = getelementptr i8, ptr @_mh_execute_header, i64 %rb57
  %3 = load ptr addrspace(271), ptr %rb58, align 4, !dbg !62
  %4 = icmp eq ptr addrspace(271) %3, null, !dbg !63
  br i1 %4, label %10, label %5, !dbg !63

5:                                                ; preds = %0
  %rb59 = ptrtoint ptr addrspace(271) %3 to i32
  %rb60 = zext i32 %rb59 to i64
  %rb61 = getelementptr i8, ptr @_mh_execute_header, i64 %rb60
  %rb62 = icmp eq i32 %rb59, 0
  %rb63 = select i1 %rb62, ptr null, ptr %rb61
  %6 = getelementptr i8, ptr %rb63, i64 0, !dbg !64
  tail call void @Heap_Free(ptr noundef %6) #3, !dbg !65
  %7 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !66
  %8 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 4, !dbg !67
  %rb64 = ptrtoint ptr addrspace(271) %8 to i32
  %rb65 = zext i32 %rb64 to i64
  %rb66 = getelementptr i8, ptr @_mh_execute_header, i64 %rb65
  %p32st.6 = getelementptr i8, ptr %rb66, i64 0
  store ptr addrspace(271) null, ptr %p32st.6, align 4, !dbg !68
  %9 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !69
  br label %10, !dbg !70

10:                                               ; preds = %5, %0
  %11 = phi ptr addrspace(271) [ %9, %5 ], [ %1, %0 ], !dbg !69
  %12 = icmp eq ptr addrspace(271) %11, null, !dbg !71
  br i1 %12, label %15, label %13, !dbg !71

13:                                               ; preds = %10
  %rb67 = ptrtoint ptr addrspace(271) %11 to i32
  %rb68 = zext i32 %rb67 to i64
  %rb69 = getelementptr i8, ptr @_mh_execute_header, i64 %rb68
  %rb70 = icmp eq i32 %rb67, 0
  %rb71 = select i1 %rb70, ptr null, ptr %rb69
  %14 = getelementptr i8, ptr %rb71, i64 0, !dbg !72
  tail call void @Heap_Free(ptr noundef %14) #3, !dbg !73
  store ptr addrspace(271) null, ptr @gBootCard, align 4, !dbg !74
  br label %15, !dbg !75

15:                                               ; preds = %13, %10
  ret void, !dbg !76
}

declare !dbg !77 void @Dialog_Term() local_unnamed_addr #2

declare !dbg !78 void @McFlow_Term() local_unnamed_addr #2

declare !dbg !79 void @Heap_Free(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define noundef i32 @BootCard_Run(i32 noundef %0) local_unnamed_addr #1 !dbg !80 {
  tail call void @BootCard_Init(i32 noundef %0) #4, !dbg !81
  tail call void @ColorFade_StartIn(i32 noundef 0, i32 noundef 0, i32 noundef 0, i32 noundef 20) #3, !dbg !82
  br label %2, !dbg !83

2:                                                ; preds = %28, %1
  tail call void @Gfx_BeginFrame() #3, !dbg !84
  tail call void @Pad_Update() #3, !dbg !85
  tail call void @Snd_Update() #3, !dbg !86
  tail call void @ColorFade_Update() #3, !dbg !87
  %3 = tail call i32 @McFlow_Update() #3, !dbg !88
  %4 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !89
  %5 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 16, !dbg !90
  %rb72 = ptrtoint ptr addrspace(271) %5 to i32
  %rb73 = zext i32 %rb72 to i64
  %rb74 = getelementptr i8, ptr @_mh_execute_header, i64 %rb73
  %p32st.7 = getelementptr i8, ptr %rb74, i64 0
  store i32 %3, ptr %p32st.7, align 4, !dbg !91
  tail call void @ColorFade_Draw() #3, !dbg !92
  tail call void @Gfx_EndFrame(i32 noundef 1) #3, !dbg !93
  tail call void @Dma_Flush() #3, !dbg !94
  tail call void @File_Stub264D90() #3, !dbg !95
  %6 = tail call i32 @ColorFade_IsInDone() #3, !dbg !96
  %7 = icmp eq i32 %6, 0, !dbg !96
  br i1 %7, label %16, label %8, !dbg !96

8:                                                ; preds = %2
  %9 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !97
  %10 = getelementptr inbounds nuw i8, ptr addrspace(271) %9, i32 8, !dbg !98
  %rb75 = ptrtoint ptr addrspace(271) %10 to i32
  %rb76 = zext i32 %rb75 to i64
  %rb77 = getelementptr i8, ptr @_mh_execute_header, i64 %rb76
  %11 = load i32, ptr %rb77, align 4, !dbg !98
  %12 = and i32 %11, 8, !dbg !99
  %13 = icmp eq i32 %12, 0, !dbg !99
  br i1 %13, label %14, label %16, !dbg !100

14:                                               ; preds = %8
  %15 = or disjoint i32 %11, 8, !dbg !101
  %rb78 = ptrtoint ptr addrspace(271) %10 to i32
  %rb79 = zext i32 %rb78 to i64
  %rb80 = getelementptr i8, ptr @_mh_execute_header, i64 %rb79
  %p32st.8 = getelementptr i8, ptr %rb80, i64 0
  store i32 %15, ptr %p32st.8, align 4, !dbg !101
  tail call void @McFlow_Start(i32 noundef 2) #3, !dbg !102
  br label %16, !dbg !103

16:                                               ; preds = %8, %14, %2
  %17 = tail call i32 @ColorFade_IsFadingOut() #3, !dbg !104
  %18 = icmp eq i32 %17, 0, !dbg !104
  br i1 %18, label %19, label %28, !dbg !104

19:                                               ; preds = %16
  %20 = tail call i32 @ColorFade_IsOutDone() #3, !dbg !105
  %21 = icmp eq i32 %20, 0, !dbg !105
  br i1 %21, label %22, label %35, !dbg !105

22:                                               ; preds = %19
  %23 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !106
  %24 = getelementptr inbounds nuw i8, ptr addrspace(271) %23, i32 8, !dbg !107
  %rb81 = ptrtoint ptr addrspace(271) %24 to i32
  %rb82 = zext i32 %rb81 to i64
  %rb83 = getelementptr i8, ptr @_mh_execute_header, i64 %rb82
  %25 = load i32, ptr %rb83, align 4, !dbg !107
  %26 = and i32 %25, 2, !dbg !108
  %27 = icmp eq i32 %26, 0, !dbg !108
  br i1 %27, label %28, label %29, !dbg !108

28:                                               ; preds = %22, %34, %29, %16
  br label %2, !dbg !84

29:                                               ; preds = %22
  %30 = getelementptr inbounds nuw i8, ptr addrspace(271) %23, i32 12, !dbg !109
  %rb84 = ptrtoint ptr addrspace(271) %30 to i32
  %rb85 = zext i32 %rb84 to i64
  %rb86 = getelementptr i8, ptr @_mh_execute_header, i64 %rb85
  %31 = load i32, ptr %rb86, align 4, !dbg !110
  %32 = add nsw i32 %31, -1, !dbg !110
  %rb87 = ptrtoint ptr addrspace(271) %30 to i32
  %rb88 = zext i32 %rb87 to i64
  %rb89 = getelementptr i8, ptr @_mh_execute_header, i64 %rb88
  %p32st.9 = getelementptr i8, ptr %rb89, i64 0
  store i32 %32, ptr %p32st.9, align 4, !dbg !110
  %33 = icmp eq i32 %31, 0, !dbg !111
  br i1 %33, label %34, label %28, !dbg !111

34:                                               ; preds = %29
  tail call void @ColorFade_StartOut(i32 noundef 0, i32 noundef 0, i32 noundef 0, i32 noundef 20) #3, !dbg !112
  br label %28, !dbg !113

35:                                               ; preds = %19
  %36 = tail call i32 @sceGsSyncPath(i32 noundef 0, i16 noundef 0) #3, !dbg !114
  tail call void @Dialog_Term() #3, !dbg !115
  tail call void @McFlow_Term() #3, !dbg !117
  %37 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !118
  %38 = getelementptr inbounds nuw i8, ptr addrspace(271) %37, i32 4, !dbg !119
  %rb90 = ptrtoint ptr addrspace(271) %38 to i32
  %rb91 = zext i32 %rb90 to i64
  %rb92 = getelementptr i8, ptr @_mh_execute_header, i64 %rb91
  %39 = load ptr addrspace(271), ptr %rb92, align 4, !dbg !119
  %40 = icmp eq ptr addrspace(271) %39, null, !dbg !120
  br i1 %40, label %46, label %41, !dbg !120

41:                                               ; preds = %35
  %rb93 = ptrtoint ptr addrspace(271) %39 to i32
  %rb94 = zext i32 %rb93 to i64
  %rb95 = getelementptr i8, ptr @_mh_execute_header, i64 %rb94
  %rb96 = icmp eq i32 %rb93, 0
  %rb97 = select i1 %rb96, ptr null, ptr %rb95
  %42 = getelementptr i8, ptr %rb97, i64 0, !dbg !121
  tail call void @Heap_Free(ptr noundef %42) #3, !dbg !122
  %43 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !123
  %44 = getelementptr inbounds nuw i8, ptr addrspace(271) %43, i32 4, !dbg !124
  %rb98 = ptrtoint ptr addrspace(271) %44 to i32
  %rb99 = zext i32 %rb98 to i64
  %rb100 = getelementptr i8, ptr @_mh_execute_header, i64 %rb99
  %p32st.10 = getelementptr i8, ptr %rb100, i64 0
  store ptr addrspace(271) null, ptr %p32st.10, align 4, !dbg !125
  %45 = load ptr addrspace(271), ptr @gBootCard, align 4, !dbg !126
  br label %46, !dbg !127

46:                                               ; preds = %41, %35
  %47 = phi ptr addrspace(271) [ %45, %41 ], [ %37, %35 ], !dbg !126
  %48 = icmp eq ptr addrspace(271) %47, null, !dbg !128
  br i1 %48, label %51, label %49, !dbg !128

49:                                               ; preds = %46
  %rb101 = ptrtoint ptr addrspace(271) %47 to i32
  %rb102 = zext i32 %rb101 to i64
  %rb103 = getelementptr i8, ptr @_mh_execute_header, i64 %rb102
  %rb104 = icmp eq i32 %rb101, 0
  %rb105 = select i1 %rb104, ptr null, ptr %rb103
  %50 = getelementptr i8, ptr %rb105, i64 0, !dbg !129
  tail call void @Heap_Free(ptr noundef %50) #3, !dbg !130
  store ptr addrspace(271) null, ptr @gBootCard, align 4, !dbg !131
  br label %51, !dbg !132

51:                                               ; preds = %46, %49
  tail call void @Dma_ResetBuffers() #3, !dbg !133
  ret i32 1, !dbg !134
}

declare !dbg !135 void @ColorFade_StartIn(i32 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !136 void @Gfx_BeginFrame() local_unnamed_addr #2

declare !dbg !137 void @Pad_Update() local_unnamed_addr #2

declare !dbg !138 void @Snd_Update() local_unnamed_addr #2

declare !dbg !139 void @ColorFade_Update() local_unnamed_addr #2

declare !dbg !140 i32 @McFlow_Update() local_unnamed_addr #2

declare !dbg !141 void @ColorFade_Draw() local_unnamed_addr #2

declare !dbg !142 void @Gfx_EndFrame(i32 noundef) local_unnamed_addr #2

declare !dbg !143 void @Dma_Flush() local_unnamed_addr #2

declare !dbg !144 void @File_Stub264D90() local_unnamed_addr #2

declare !dbg !145 i32 @ColorFade_IsInDone() local_unnamed_addr #2

declare !dbg !146 void @McFlow_Start(i32 noundef) local_unnamed_addr #2

declare !dbg !147 i32 @ColorFade_IsFadingOut() local_unnamed_addr #2

declare !dbg !148 i32 @ColorFade_IsOutDone() local_unnamed_addr #2

declare !dbg !149 void @ColorFade_StartOut(i32 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !150 i32 @sceGsSyncPath(i32 noundef, i16 noundef) local_unnamed_addr #2

declare !dbg !151 void @Dma_ResetBuffers() local_unnamed_addr #2

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync) "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #1 = { nounwind uwtable(sync) "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #2 = { "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #3 = { nobuiltin nounwind "no-builtins" }
attributes #4 = { nobuiltin "no-builtins" }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5, !6}
!llvm.dbg.cu = !{!7}
!llvm.ident = !{!9}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 17, i32 5]}
!1 = !{i32 7, !"Dwarf Version", i32 4}
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 4}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 1}
!6 = !{i32 7, !"frame-pointer", i32 1}
!7 = distinct !DICompileUnit(language: DW_LANG_C89, file: !8, producer: "Homebrew clang version 21.1.8", isOptimized: true, runtimeVersion: 0, emissionKind: LineTablesOnly, splitDebugInlining: false, nameTableKind: Apple, sysroot: "/")
!8 = !DIFile(filename: "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid/src/menu/menu_i_b.c", directory: "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid")
!9 = !{!"Homebrew clang version 21.1.8"}
!10 = distinct !DISubprogram(name: "BootCard_OnFlowDone", scope: !11, file: !11, line: 13, type: !12, scopeLine: 13, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!11 = !DIFile(filename: "src/menu/menu_i_b.c", directory: "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid")
!12 = !DISubroutineType(types: !13)
!13 = !{}
!14 = !DILocation(line: 14, column: 5, scope: !10)
!15 = !DILocation(line: 14, column: 16, scope: !10)
!16 = !DILocation(line: 14, column: 22, scope: !10)
!17 = !DILocation(line: 15, column: 5, scope: !10)
!18 = !DILocation(line: 15, column: 16, scope: !10)
!19 = !DILocation(line: 15, column: 22, scope: !10)
!20 = !DILocation(line: 16, column: 5, scope: !10)
!21 = !DILocation(line: 16, column: 16, scope: !10)
!22 = !DILocation(line: 16, column: 22, scope: !10)
!23 = !DILocation(line: 17, column: 1, scope: !10)
!24 = distinct !DISubprogram(name: "BootCard_Init", scope: !11, file: !11, line: 20, type: !12, scopeLine: 20, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!25 = !DILocation(line: 21, column: 17, scope: !24)
!26 = !DILocation(line: 21, column: 15, scope: !24)
!27 = !DILocation(line: 22, column: 5, scope: !24)
!28 = !DILocation(line: 23, column: 70, scope: !24)
!29 = !DILocation(line: 23, column: 85, scope: !24)
!30 = !DILocation(line: 23, column: 137, scope: !24)
!31 = !DILocation(line: 23, column: 81, scope: !24)
!32 = !DILocation(line: 23, column: 5, scope: !24)
!33 = !DILocation(line: 23, column: 21, scope: !24)
!34 = !DILocation(line: 24, column: 36, scope: !24)
!35 = !DILocation(line: 24, column: 47, scope: !24)
!36 = !DILocation(line: 24, column: 22, scope: !24)
!37 = !DILocation(line: 24, column: 5, scope: !24)
!38 = !DILocation(line: 24, column: 16, scope: !24)
!39 = !DILocation(line: 24, column: 20, scope: !24)
!40 = !DILocation(line: 25, column: 41, scope: !24)
!41 = !DILocation(line: 25, column: 52, scope: !24)
!42 = !DILocation(line: 25, column: 61, scope: !24)
!43 = !DILocation(line: 25, column: 112, scope: !24)
!44 = !DILocation(line: 25, column: 57, scope: !24)
!45 = !DILocation(line: 25, column: 17, scope: !24)
!46 = !DILocation(line: 25, column: 5, scope: !24)
!47 = !DILocation(line: 26, column: 5, scope: !24)
!48 = !DILocation(line: 27, column: 5, scope: !24)
!49 = !DILocation(line: 28, column: 5, scope: !24)
!50 = !DILocation(line: 29, column: 1, scope: !24)
!51 = !DISubprogram(name: "Heap_Alloc", scope: !52, file: !52, line: 90, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!52 = !DIFile(filename: "include/menu/menu_a.h", directory: "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid")
!53 = !DISubprogram(name: "memset", scope: !52, file: !52, line: 88, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!54 = !DISubprogram(name: "Sprite_Unpack", scope: !52, file: !52, line: 92, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!55 = !DISubprogram(name: "Dialog_Init", scope: !52, file: !52, line: 145, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!56 = !DISubprogram(name: "McFlow_Init", scope: !52, file: !52, line: 147, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!57 = !DISubprogram(name: "McFlow_SetDoneCb", scope: !52, file: !52, line: 151, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!58 = distinct !DISubprogram(name: "BootCard_Term", scope: !11, file: !11, line: 32, type: !12, scopeLine: 32, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!59 = !DILocation(line: 33, column: 5, scope: !58)
!60 = !DILocation(line: 34, column: 5, scope: !58)
!61 = !DILocation(line: 35, column: 9, scope: !58)
!62 = !DILocation(line: 35, column: 20, scope: !58)
!63 = !DILocation(line: 35, column: 24, scope: !58)
!64 = !DILocation(line: 36, column: 19, scope: !58)
!65 = !DILocation(line: 36, column: 9, scope: !58)
!66 = !DILocation(line: 37, column: 9, scope: !58)
!67 = !DILocation(line: 37, column: 20, scope: !58)
!68 = !DILocation(line: 37, column: 24, scope: !58)
!69 = !DILocation(line: 39, column: 9, scope: !58)
!70 = !DILocation(line: 38, column: 5, scope: !58)
!71 = !DILocation(line: 39, column: 19, scope: !58)
!72 = !DILocation(line: 40, column: 19, scope: !58)
!73 = !DILocation(line: 40, column: 9, scope: !58)
!74 = !DILocation(line: 41, column: 19, scope: !58)
!75 = !DILocation(line: 42, column: 5, scope: !58)
!76 = !DILocation(line: 43, column: 1, scope: !58)
!77 = !DISubprogram(name: "Dialog_Term", scope: !52, file: !52, line: 146, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!78 = !DISubprogram(name: "McFlow_Term", scope: !52, file: !52, line: 148, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!79 = !DISubprogram(name: "Heap_Free", scope: !52, file: !52, line: 91, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!80 = distinct !DISubprogram(name: "BootCard_Run", scope: !11, file: !11, line: 46, type: !12, scopeLine: 46, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!81 = !DILocation(line: 47, column: 5, scope: !80)
!82 = !DILocation(line: 48, column: 5, scope: !80)
!83 = !DILocation(line: 49, column: 5, scope: !80)
!84 = !DILocation(line: 50, column: 9, scope: !80)
!85 = !DILocation(line: 51, column: 9, scope: !80)
!86 = !DILocation(line: 52, column: 9, scope: !80)
!87 = !DILocation(line: 53, column: 9, scope: !80)
!88 = !DILocation(line: 54, column: 30, scope: !80)
!89 = !DILocation(line: 54, column: 9, scope: !80)
!90 = !DILocation(line: 54, column: 20, scope: !80)
!91 = !DILocation(line: 54, column: 28, scope: !80)
!92 = !DILocation(line: 55, column: 9, scope: !80)
!93 = !DILocation(line: 56, column: 9, scope: !80)
!94 = !DILocation(line: 57, column: 9, scope: !80)
!95 = !DILocation(line: 58, column: 9, scope: !80)
!96 = !DILocation(line: 59, column: 13, scope: !80)
!97 = !DILocation(line: 60, column: 19, scope: !80)
!98 = !DILocation(line: 60, column: 30, scope: !80)
!99 = !DILocation(line: 60, column: 36, scope: !80)
!100 = !DILocation(line: 60, column: 17, scope: !80)
!101 = !DILocation(line: 61, column: 34, scope: !80)
!102 = !DILocation(line: 62, column: 17, scope: !80)
!103 = !DILocation(line: 63, column: 13, scope: !80)
!104 = !DILocation(line: 65, column: 13, scope: !80)
!105 = !DILocation(line: 68, column: 13, scope: !80)
!106 = !DILocation(line: 71, column: 13, scope: !80)
!107 = !DILocation(line: 71, column: 24, scope: !80)
!108 = !DILocation(line: 71, column: 30, scope: !80)
!109 = !DILocation(line: 72, column: 30, scope: !80)
!110 = !DILocation(line: 72, column: 17, scope: !80)
!111 = !DILocation(line: 72, column: 36, scope: !80)
!112 = !DILocation(line: 73, column: 17, scope: !80)
!113 = !DILocation(line: 74, column: 13, scope: !80)
!114 = !DILocation(line: 77, column: 5, scope: !80)
!115 = !DILocation(line: 33, column: 5, scope: !58, inlinedAt: !116)
!116 = distinct !DILocation(line: 78, column: 5, scope: !80)
!117 = !DILocation(line: 34, column: 5, scope: !58, inlinedAt: !116)
!118 = !DILocation(line: 35, column: 9, scope: !58, inlinedAt: !116)
!119 = !DILocation(line: 35, column: 20, scope: !58, inlinedAt: !116)
!120 = !DILocation(line: 35, column: 24, scope: !58, inlinedAt: !116)
!121 = !DILocation(line: 36, column: 19, scope: !58, inlinedAt: !116)
!122 = !DILocation(line: 36, column: 9, scope: !58, inlinedAt: !116)
!123 = !DILocation(line: 37, column: 9, scope: !58, inlinedAt: !116)
!124 = !DILocation(line: 37, column: 20, scope: !58, inlinedAt: !116)
!125 = !DILocation(line: 37, column: 24, scope: !58, inlinedAt: !116)
!126 = !DILocation(line: 39, column: 9, scope: !58, inlinedAt: !116)
!127 = !DILocation(line: 38, column: 5, scope: !58, inlinedAt: !116)
!128 = !DILocation(line: 39, column: 19, scope: !58, inlinedAt: !116)
!129 = !DILocation(line: 40, column: 19, scope: !58, inlinedAt: !116)
!130 = !DILocation(line: 40, column: 9, scope: !58, inlinedAt: !116)
!131 = !DILocation(line: 41, column: 19, scope: !58, inlinedAt: !116)
!132 = !DILocation(line: 42, column: 5, scope: !58, inlinedAt: !116)
!133 = !DILocation(line: 79, column: 5, scope: !80)
!134 = !DILocation(line: 80, column: 5, scope: !80)
!135 = !DISubprogram(name: "ColorFade_StartIn", scope: !52, file: !52, line: 136, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!136 = !DISubprogram(name: "Gfx_BeginFrame", scope: !52, file: !52, line: 130, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!137 = !DISubprogram(name: "Pad_Update", scope: !52, file: !52, line: 129, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!138 = !DISubprogram(name: "Snd_Update", scope: !52, file: !52, line: 128, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!139 = !DISubprogram(name: "ColorFade_Update", scope: !52, file: !52, line: 138, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!140 = !DISubprogram(name: "McFlow_Update", scope: !52, file: !52, line: 150, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!141 = !DISubprogram(name: "ColorFade_Draw", scope: !52, file: !52, line: 139, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!142 = !DISubprogram(name: "Gfx_EndFrame", scope: !52, file: !52, line: 131, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!143 = !DISubprogram(name: "Dma_Flush", scope: !52, file: !52, line: 132, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!144 = !DISubprogram(name: "File_Stub264D90", scope: !52, file: !52, line: 134, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!145 = !DISubprogram(name: "ColorFade_IsInDone", scope: !52, file: !52, line: 140, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!146 = !DISubprogram(name: "McFlow_Start", scope: !52, file: !52, line: 149, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!147 = !DISubprogram(name: "ColorFade_IsFadingOut", scope: !52, file: !52, line: 142, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!148 = !DISubprogram(name: "ColorFade_IsOutDone", scope: !52, file: !52, line: 141, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!149 = !DISubprogram(name: "ColorFade_StartOut", scope: !52, file: !52, line: 137, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!150 = !DISubprogram(name: "sceGsSyncPath", scope: !52, file: !52, line: 135, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!151 = !DISubprogram(name: "Dma_ResetBuffers", scope: !52, file: !52, line: 133, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)

@_mh_execute_header = external hidden global i8, align 4
