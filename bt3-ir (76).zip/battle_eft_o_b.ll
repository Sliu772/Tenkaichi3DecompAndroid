; ModuleID = '/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid/src/battle/eft_o_b.c'
source_filename = "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid/src/battle/eft_o_b.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-ios15.0.0"

%struct.EftOVec = type { float, float, float, float }
%struct.EftBlastObjArg = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, float, float, float, i32 }
%struct.Mtx44 = type { [4 x [4 x float]] }
%struct.Vec4 = type { float, float, float, float }
%struct.EftOGroup = type { i32, i32, i8, [7 x i8] }
%struct.EftOPart = type { [8 x i8], i8, i8, i8, [53 x i8] }
%struct.EftBlastObjSel = type { i32, i32 }
%struct.EftOEmitNode = type { i32, [3 x i32], %struct.Vec4 }

@__const.EftBlastObj_UpdateModel.ofs = private unnamed_addr constant %struct.EftOVec { float 0.000000e+00, float 5.500000e+00, float 0.000000e+00, float 1.000000e+00 }, align 16
@EftBlastObj_Init.n = internal unnamed_addr global i32 0, align 4
@__stderrp = external local_unnamed_addr global ptr, align 8
@.str = private unnamed_addr constant [73 x i8] c"bt3 blast init: task %p w %p arg %p (raw 0x%x) arg->nodes %p (raw 0x%x)\0A\00", align 1
@__const.EftBlastObj_Init.slots = private unnamed_addr constant [7 x i32] [i32 0, i32 1, i32 3, i32 4, i32 5, i32 -1, i32 -1], align 4
@__const.EftBlastObj_Init.bits = private unnamed_addr constant [6 x i32] [i32 2, i32 4, i32 8, i32 16, i32 32, i32 64], align 4
@gEftBlastObjMgr = external local_unnamed_addr global i32, align 4
@gEftBlastObjList = external local_unnamed_addr global i32, align 4
@EftBlastObj_Create.a = internal global %struct.EftBlastObjArg zeroinitializer, align 4
@EftBlastObj_Create.n = internal unnamed_addr global i32 0, align 4
@.str.1 = private unnamed_addr constant [90 x i8] c"bt3 blast create: arg %p (raw 0x%x) &a %p (raw 0x%x) a.nodes %p (raw 0x%x) src %p set %p\0A\00", align 1
@gEftBlastObjClass = external global [6 x i32], align 4
@EftBlastObj_CreateWithModel.a = internal global %struct.EftBlastObjArg zeroinitializer, align 4

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_AddHit(ptr noundef %0) local_unnamed_addr #0 !dbg !10 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !14
  %3 = load ptr addrspace(271), ptr %2, align 4, !dbg !14
  %4 = tail call ptr @EftHit_GetNew() #7, !dbg !15
  %rb1 = ptrtoint ptr %4 to i64
  %rb2 = ptrtoint ptr @_mh_execute_header to i64
  %rb3 = sub i64 %rb1, %rb2
  %rb4 = trunc i64 %rb3 to i32
  %rb5 = icmp eq ptr %4, null
  %rb6 = select i1 %rb5, i32 0, i32 %rb4
  %5 = inttoptr i32 %rb6 to ptr addrspace(271), !dbg !15
  %rb7 = ptrtoint ptr addrspace(271) %3 to i32
  %rb8 = zext i32 %rb7 to i64
  %rb9 = getelementptr i8, ptr @_mh_execute_header, i64 %rb8
  %6 = load ptr addrspace(271), ptr %rb9, align 16, !dbg !16
  %7 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1420, !dbg !17
  %rb10 = ptrtoint ptr addrspace(271) %7 to i32
  %rb11 = zext i32 %rb10 to i64
  %rb12 = getelementptr i8, ptr @_mh_execute_header, i64 %rb11
  %8 = load float, ptr %rb12, align 4, !dbg !17
  %9 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 656, !dbg !18
  %rb13 = ptrtoint ptr addrspace(271) %9 to i32
  %rb14 = zext i32 %rb13 to i64
  %rb15 = getelementptr i8, ptr @_mh_execute_header, i64 %rb14
  %rb16 = icmp eq i32 %rb13, 0
  %rb17 = select i1 %rb16, ptr null, ptr %rb15
  %10 = getelementptr i8, ptr %rb17, i64 0, !dbg !19
  %11 = tail call float @EftEmit_GetTrailWidth(ptr noundef %10) #7, !dbg !20
  %12 = fmul float %8, %11, !dbg !21
  %13 = getelementptr inbounds nuw i8, ptr addrspace(271) %5, i32 16, !dbg !22
  %14 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1440, !dbg !23
  %rb18 = ptrtoint ptr addrspace(271) %13 to i32
  %rb19 = zext i32 %rb18 to i64
  %rb20 = getelementptr i8, ptr @_mh_execute_header, i64 %rb19
  %p32fix.1 = getelementptr i8, ptr %rb20, i64 0
  %rb21 = ptrtoint ptr addrspace(271) %14 to i32
  %rb22 = zext i32 %rb21 to i64
  %rb23 = getelementptr i8, ptr @_mh_execute_header, i64 %rb22
  %p32fix.2 = getelementptr i8, ptr %rb23, i64 0
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %p32fix.1, ptr noundef nonnull align 16 dereferenceable(64) %p32fix.2, i64 64, i1 false), !dbg !23
  %rb24 = ptrtoint ptr %0 to i64
  %rb25 = ptrtoint ptr @_mh_execute_header to i64
  %rb26 = sub i64 %rb24, %rb25
  %rb27 = trunc i64 %rb26 to i32
  %rb28 = icmp eq ptr %0, null
  %rb29 = select i1 %rb28, i32 0, i32 %rb27
  %15 = inttoptr i32 %rb29 to ptr addrspace(271), !dbg !24
  %16 = getelementptr inbounds nuw i8, ptr addrspace(271) %5, i32 96, !dbg !25
  %rb30 = ptrtoint ptr addrspace(271) %16 to i32
  %rb31 = zext i32 %rb30 to i64
  %rb32 = getelementptr i8, ptr @_mh_execute_header, i64 %rb31
  %p32st.3 = getelementptr i8, ptr %rb32, i64 0
  store ptr addrspace(271) %15, ptr %p32st.3, align 8, !dbg !26
  %17 = getelementptr inbounds nuw i8, ptr addrspace(271) %5, i32 100, !dbg !27
  %rb33 = ptrtoint ptr addrspace(271) %17 to i32
  %rb34 = zext i32 %rb33 to i64
  %rb35 = getelementptr i8, ptr @_mh_execute_header, i64 %rb34
  %p32st.4 = getelementptr i8, ptr %rb35, i64 0
  store ptr addrspace(271) %6, ptr %p32st.4, align 4, !dbg !28
  %18 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1408, !dbg !29
  %rb36 = ptrtoint ptr addrspace(271) %18 to i32
  %rb37 = zext i32 %rb36 to i64
  %rb38 = getelementptr i8, ptr @_mh_execute_header, i64 %rb37
  %19 = load i32, ptr %rb38, align 16, !dbg !29
  %20 = and i32 %19, 256, !dbg !30
  %21 = icmp eq i32 %20, 0, !dbg !30
  br i1 %21, label %27, label %22, !dbg !30

22:                                               ; preds = %1
  %23 = getelementptr inbounds nuw i8, ptr addrspace(271) %5, i32 80, !dbg !31
  %rb39 = ptrtoint ptr addrspace(271) %23 to i32
  %rb40 = zext i32 %rb39 to i64
  %rb41 = getelementptr i8, ptr @_mh_execute_header, i64 %rb40
  %24 = load i32, ptr %rb41, align 8, !dbg !32
  %25 = or i32 %24, 128, !dbg !32
  %rb42 = ptrtoint ptr addrspace(271) %23 to i32
  %rb43 = zext i32 %rb42 to i64
  %rb44 = getelementptr i8, ptr @_mh_execute_header, i64 %rb43
  %p32st.5 = getelementptr i8, ptr %rb44, i64 0
  store i32 %25, ptr %p32st.5, align 8, !dbg !32
  %rb45 = ptrtoint ptr addrspace(271) %18 to i32
  %rb46 = zext i32 %rb45 to i64
  %rb47 = getelementptr i8, ptr @_mh_execute_header, i64 %rb46
  %26 = load i32, ptr %rb47, align 16, !dbg !33
  br label %27, !dbg !34

27:                                               ; preds = %22, %1
  %28 = phi i32 [ %26, %22 ], [ %19, %1 ], !dbg !33
  %29 = and i32 %28, 2048, !dbg !35
  %30 = icmp eq i32 %29, 0, !dbg !35
  br i1 %30, label %35, label %31, !dbg !35

31:                                               ; preds = %27
  %32 = getelementptr inbounds nuw i8, ptr addrspace(271) %5, i32 80, !dbg !36
  %rb48 = ptrtoint ptr addrspace(271) %32 to i32
  %rb49 = zext i32 %rb48 to i64
  %rb50 = getelementptr i8, ptr @_mh_execute_header, i64 %rb49
  %33 = load i32, ptr %rb50, align 8, !dbg !37
  %34 = or i32 %33, 16, !dbg !37
  %rb51 = ptrtoint ptr addrspace(271) %32 to i32
  %rb52 = zext i32 %rb51 to i64
  %rb53 = getelementptr i8, ptr @_mh_execute_header, i64 %rb52
  %p32st.6 = getelementptr i8, ptr %rb53, i64 0
  store i32 %34, ptr %p32st.6, align 8, !dbg !37
  br label %35, !dbg !38

35:                                               ; preds = %31, %27
  %36 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 36, !dbg !39
  %rb54 = ptrtoint ptr addrspace(271) %36 to i32
  %rb55 = zext i32 %rb54 to i64
  %rb56 = getelementptr i8, ptr @_mh_execute_header, i64 %rb55
  %37 = load ptr addrspace(271), ptr %rb56, align 4, !dbg !39
  %38 = getelementptr inbounds nuw i8, ptr addrspace(271) %37, i32 8, !dbg !40
  %rb57 = ptrtoint ptr addrspace(271) %38 to i32
  %rb58 = zext i32 %rb57 to i64
  %rb59 = getelementptr i8, ptr @_mh_execute_header, i64 %rb58
  %39 = load i8, ptr %rb59, align 4, !dbg !40
  switch i8 %39, label %56 [
    i8 1, label %40
    i8 0, label %48
  ], !dbg !41

40:                                               ; preds = %35
  %41 = tail call ptr @EftHitArena_AllocBox() #7, !dbg !42
  %42 = tail call ptr @EftHitArena_AllocBox() #7, !dbg !43
  %rb60 = ptrtoint ptr addrspace(271) %14 to i32
  %rb61 = zext i32 %rb60 to i64
  %rb62 = getelementptr i8, ptr @_mh_execute_header, i64 %rb61
  %rb63 = icmp eq i32 %rb60, 0
  %rb64 = select i1 %rb63, ptr null, ptr %rb62
  %43 = getelementptr i8, ptr %rb64, i64 0, !dbg !44
  %44 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1456, !dbg !45
  %rb65 = ptrtoint ptr addrspace(271) %44 to i32
  %rb66 = zext i32 %rb65 to i64
  %rb67 = getelementptr i8, ptr @_mh_execute_header, i64 %rb66
  %rb68 = icmp eq i32 %rb65, 0
  %rb69 = select i1 %rb68, ptr null, ptr %rb67
  %45 = getelementptr i8, ptr %rb69, i64 0, !dbg !46
  tail call void @ColCapsule_Set(ptr noundef %41, ptr noundef %43, ptr noundef %45, float noundef %12) #7, !dbg !47
  %46 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1472, !dbg !48
  %rb70 = ptrtoint ptr addrspace(271) %46 to i32
  %rb71 = zext i32 %rb70 to i64
  %rb72 = getelementptr i8, ptr @_mh_execute_header, i64 %rb71
  %rb73 = icmp eq i32 %rb70, 0
  %rb74 = select i1 %rb73, ptr null, ptr %rb72
  %47 = getelementptr i8, ptr %rb74, i64 0, !dbg !49
  tail call void @ColCapsule_Set(ptr noundef %42, ptr noundef %43, ptr noundef %47, float noundef %12) #7, !dbg !50
  tail call void @EftHit_SetShapeBoxes(ptr noundef %4, ptr noundef %41, ptr noundef %42) #7, !dbg !51
  br label %55

48:                                               ; preds = %35
  %49 = tail call ptr @EftHitArena_AllocSphere() #7, !dbg !52
  %50 = tail call ptr @EftHitArena_AllocSphere() #7, !dbg !53
  %51 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1456, !dbg !54
  %rb75 = ptrtoint ptr addrspace(271) %51 to i32
  %rb76 = zext i32 %rb75 to i64
  %rb77 = getelementptr i8, ptr @_mh_execute_header, i64 %rb76
  %rb78 = icmp eq i32 %rb75, 0
  %rb79 = select i1 %rb78, ptr null, ptr %rb77
  %52 = getelementptr i8, ptr %rb79, i64 0, !dbg !55
  tail call void @ColSphere_Set(ptr noundef %49, ptr noundef %52, float noundef %12) #7, !dbg !56
  %53 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1472, !dbg !57
  %rb80 = ptrtoint ptr addrspace(271) %53 to i32
  %rb81 = zext i32 %rb80 to i64
  %rb82 = getelementptr i8, ptr @_mh_execute_header, i64 %rb81
  %rb83 = icmp eq i32 %rb80, 0
  %rb84 = select i1 %rb83, ptr null, ptr %rb82
  %54 = getelementptr i8, ptr %rb84, i64 0, !dbg !58
  tail call void @ColSphere_Set(ptr noundef %50, ptr noundef %54, float noundef %12) #7, !dbg !59
  tail call void @EftHit_SetShapeSpheres(ptr noundef %4, ptr noundef %49, ptr noundef %50) #7, !dbg !60
  br label %55

55:                                               ; preds = %48, %40
  tail call void @EftHit_Add(ptr noundef %4) #7, !dbg !61
  br label %56, !dbg !62

56:                                               ; preds = %35, %55
  ret void, !dbg !62
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #1

declare !dbg !63 ptr @EftHit_GetNew() local_unnamed_addr #2

declare !dbg !64 float @EftEmit_GetTrailWidth(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p271.p271.i64(ptr addrspace(271) noalias writeonly captures(none), ptr addrspace(271) noalias readonly captures(none), i64, i1 immarg) #3

declare !dbg !65 ptr @EftHitArena_AllocBox() local_unnamed_addr #2

declare !dbg !66 void @ColCapsule_Set(ptr noundef, ptr noundef, ptr noundef, float noundef) local_unnamed_addr #2

declare !dbg !67 void @EftHit_SetShapeBoxes(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #1

declare !dbg !68 ptr @EftHitArena_AllocSphere() local_unnamed_addr #2

declare !dbg !69 void @ColSphere_Set(ptr noundef, ptr noundef, float noundef) local_unnamed_addr #2

declare !dbg !70 void @EftHit_SetShapeSpheres(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !71 void @EftHit_Add(ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_InitModel(ptr noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !72 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !73
  %3 = load ptr addrspace(271), ptr %2, align 4, !dbg !73
  %4 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1504, !dbg !74
  %5 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1508, !dbg !75
  %rb85 = ptrtoint ptr addrspace(271) %5 to i32
  %rb86 = zext i32 %rb85 to i64
  %rb87 = getelementptr i8, ptr @_mh_execute_header, i64 %rb86
  %rb88 = icmp eq i32 %rb85, 0
  %rb89 = select i1 %rb88, ptr null, ptr %rb87
  %6 = getelementptr i8, ptr %rb89, i64 0, !dbg !76
  %rb90 = ptrtoint ptr addrspace(271) %4 to i32
  %rb91 = zext i32 %rb90 to i64
  %rb92 = getelementptr i8, ptr @_mh_execute_header, i64 %rb91
  %7 = load ptr addrspace(271), ptr %rb92, align 4, !dbg !77
  %rb93 = ptrtoint ptr addrspace(271) %7 to i32
  %rb94 = zext i32 %rb93 to i64
  %rb95 = getelementptr i8, ptr @_mh_execute_header, i64 %rb94
  %rb96 = icmp eq i32 %rb93, 0
  %rb97 = select i1 %rb96, ptr null, ptr %rb95
  %8 = getelementptr i8, ptr %rb97, i64 0, !dbg !78
  %9 = tail call i32 @EftObj_Create(ptr noundef %6, ptr noundef %8) #7, !dbg !79
  %10 = trunc i32 %9 to i8, !dbg !79
  %11 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1557, !dbg !80
  %rb98 = ptrtoint ptr addrspace(271) %11 to i32
  %rb99 = zext i32 %rb98 to i64
  %rb100 = getelementptr i8, ptr @_mh_execute_header, i64 %rb99
  %p32st.7 = getelementptr i8, ptr %rb100, i64 0
  store i8 %10, ptr %p32st.7, align 1, !dbg !81
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1558, !dbg !82
  %rb101 = ptrtoint ptr addrspace(271) %12 to i32
  %rb102 = zext i32 %rb101 to i64
  %rb103 = getelementptr i8, ptr @_mh_execute_header, i64 %rb102
  %p32st.8 = getelementptr i8, ptr %rb103, i64 0
  store i8 -1, ptr %p32st.8, align 2, !dbg !83
  %13 = shl i32 %9, 24, !dbg !84
  %14 = ashr exact i32 %13, 24, !dbg !84
  tail call void @EftObj_SetVisible(i32 noundef %14, i32 noundef 0) #7, !dbg !85
  %rb104 = ptrtoint ptr addrspace(271) %11 to i32
  %rb105 = zext i32 %rb104 to i64
  %rb106 = getelementptr i8, ptr @_mh_execute_header, i64 %rb105
  %15 = load i8, ptr %rb106, align 1, !dbg !86
  %16 = sext i8 %15 to i32, !dbg !87
  tail call void @EftObj_Nop(i32 noundef %16, i32 noundef 0) #7, !dbg !88
  ret void, !dbg !89
}

declare !dbg !90 i32 @EftObj_Create(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !91 void @EftObj_SetVisible(i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !92 void @EftObj_Nop(i32 noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_UpdateModel(ptr noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !93 {
  %2 = alloca %struct.Mtx44, align 4
  %3 = alloca %struct.Vec4, align 4
  %4 = alloca %struct.Vec4, align 4
  %5 = alloca %struct.EftOVec, align 16
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2) #8, !dbg !94
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #8, !dbg !95
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #8, !dbg !96
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !97
  %7 = load ptr addrspace(271), ptr %6, align 4, !dbg !97
  call void @Mtx_StoreIdentity(ptr noundef nonnull %2) #7, !dbg !98
  %8 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1420, !dbg !99
  %rb107 = ptrtoint ptr addrspace(271) %8 to i32
  %rb108 = zext i32 %rb107 to i64
  %rb109 = getelementptr i8, ptr @_mh_execute_header, i64 %rb108
  %9 = load float, ptr %rb109, align 4, !dbg !99
  call void @Mtx_ScaleDiagUniform(ptr noundef nonnull %2, ptr noundef nonnull %2, float noundef %9) #7, !dbg !100
  %10 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1408, !dbg !101
  %rb110 = ptrtoint ptr addrspace(271) %10 to i32
  %rb111 = zext i32 %rb110 to i64
  %rb112 = getelementptr i8, ptr @_mh_execute_header, i64 %rb111
  %11 = load i32, ptr %rb112, align 16, !dbg !101
  %12 = and i32 %11, 8192, !dbg !102
  %13 = icmp eq i32 %12, 0, !dbg !102
  br i1 %13, label %107, label %14, !dbg !102

14:                                               ; preds = %1
  %15 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1558, !dbg !103
  %rb113 = ptrtoint ptr addrspace(271) %15 to i32
  %rb114 = zext i32 %rb113 to i64
  %rb115 = getelementptr i8, ptr @_mh_execute_header, i64 %rb114
  %16 = load i8, ptr %rb115, align 2, !dbg !103
  %17 = icmp slt i8 %16, 0, !dbg !104
  br i1 %17, label %18, label %24, !dbg !104

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1560, !dbg !105
  %rb116 = ptrtoint ptr addrspace(271) %19 to i32
  %rb117 = zext i32 %rb116 to i64
  %rb118 = getelementptr i8, ptr @_mh_execute_header, i64 %rb117
  %20 = load float, ptr %rb118, align 4, !dbg !105
  %21 = fcmp ult float %20, 0.000000e+00, !dbg !106
  br i1 %21, label %72, label %22, !dbg !106

22:                                               ; preds = %18
  %23 = add nsw i8 %16, 1, !dbg !107
  %rb119 = ptrtoint ptr addrspace(271) %15 to i32
  %rb120 = zext i32 %rb119 to i64
  %rb121 = getelementptr i8, ptr @_mh_execute_header, i64 %rb120
  %p32st.9 = getelementptr i8, ptr %rb121, i64 0
  store i8 %23, ptr %p32st.9, align 2, !dbg !107
  br label %65, !dbg !108

24:                                               ; preds = %14
  switch i8 %16, label %53 [
    i8 0, label %25
    i8 1, label %35
    i8 2, label %41
  ], !dbg !109

25:                                               ; preds = %24
  %26 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1557, !dbg !110
  %rb122 = ptrtoint ptr addrspace(271) %26 to i32
  %rb123 = zext i32 %rb122 to i64
  %rb124 = getelementptr i8, ptr @_mh_execute_header, i64 %rb123
  %27 = load i8, ptr %rb124, align 1, !dbg !110
  %28 = sext i8 %27 to i32, !dbg !111
  %29 = call i32 @EftObj_IsAnimPlaying(i32 noundef %28) #7, !dbg !112
  %30 = icmp eq i32 %29, 0, !dbg !112
  br i1 %30, label %31, label %72, !dbg !113

31:                                               ; preds = %25
  %32 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1560, !dbg !114
  %rb125 = ptrtoint ptr addrspace(271) %32 to i32
  %rb126 = zext i32 %rb125 to i64
  %rb127 = getelementptr i8, ptr @_mh_execute_header, i64 %rb126
  %p32st.10 = getelementptr i8, ptr %rb127, i64 0
  store float 0.000000e+00, ptr %p32st.10, align 4, !dbg !115
  %rb128 = ptrtoint ptr addrspace(271) %15 to i32
  %rb129 = zext i32 %rb128 to i64
  %rb130 = getelementptr i8, ptr @_mh_execute_header, i64 %rb129
  %33 = load i8, ptr %rb130, align 2, !dbg !116
  %34 = add i8 %33, 1, !dbg !116
  %rb131 = ptrtoint ptr addrspace(271) %15 to i32
  %rb132 = zext i32 %rb131 to i64
  %rb133 = getelementptr i8, ptr @_mh_execute_header, i64 %rb132
  %p32st.11 = getelementptr i8, ptr %rb133, i64 0
  store i8 %34, ptr %p32st.11, align 2, !dbg !116
  br label %65, !dbg !117

35:                                               ; preds = %24
  %36 = and i32 %11, 16384, !dbg !118
  %37 = icmp eq i32 %36, 0, !dbg !118
  br i1 %37, label %72, label %38, !dbg !118

38:                                               ; preds = %35
  %39 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1560, !dbg !119
  %rb134 = ptrtoint ptr addrspace(271) %39 to i32
  %rb135 = zext i32 %rb134 to i64
  %rb136 = getelementptr i8, ptr @_mh_execute_header, i64 %rb135
  %p32st.12 = getelementptr i8, ptr %rb136, i64 0
  store float 0.000000e+00, ptr %p32st.12, align 4, !dbg !120
  %rb137 = ptrtoint ptr addrspace(271) %15 to i32
  %rb138 = zext i32 %rb137 to i64
  %rb139 = getelementptr i8, ptr @_mh_execute_header, i64 %rb138
  %p32st.13 = getelementptr i8, ptr %rb139, i64 0
  store i8 2, ptr %p32st.13, align 2, !dbg !121
  %40 = and i32 %11, -129, !dbg !122
  %rb140 = ptrtoint ptr addrspace(271) %10 to i32
  %rb141 = zext i32 %rb140 to i64
  %rb142 = getelementptr i8, ptr @_mh_execute_header, i64 %rb141
  %p32st.14 = getelementptr i8, ptr %rb142, i64 0
  store i32 %40, ptr %p32st.14, align 16, !dbg !122
  br label %65, !dbg !123

41:                                               ; preds = %24
  %42 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1557, !dbg !124
  %rb143 = ptrtoint ptr addrspace(271) %42 to i32
  %rb144 = zext i32 %rb143 to i64
  %rb145 = getelementptr i8, ptr @_mh_execute_header, i64 %rb144
  %43 = load i8, ptr %rb145, align 1, !dbg !124
  %44 = sext i8 %43 to i32, !dbg !125
  %45 = call i32 @EftObj_IsAnimPlaying(i32 noundef %44) #7, !dbg !126
  %46 = icmp eq i32 %45, 0, !dbg !126
  br i1 %46, label %47, label %72, !dbg !127

47:                                               ; preds = %41
  %rb146 = ptrtoint ptr addrspace(271) %15 to i32
  %rb147 = zext i32 %rb146 to i64
  %rb148 = getelementptr i8, ptr @_mh_execute_header, i64 %rb147
  %48 = load i8, ptr %rb148, align 2, !dbg !128
  %49 = add i8 %48, 1, !dbg !128
  %rb149 = ptrtoint ptr addrspace(271) %15 to i32
  %rb150 = zext i32 %rb149 to i64
  %rb151 = getelementptr i8, ptr @_mh_execute_header, i64 %rb150
  %p32st.15 = getelementptr i8, ptr %rb151, i64 0
  store i8 %49, ptr %p32st.15, align 2, !dbg !128
  %50 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1560, !dbg !129
  %rb152 = ptrtoint ptr addrspace(271) %50 to i32
  %rb153 = zext i32 %rb152 to i64
  %rb154 = getelementptr i8, ptr @_mh_execute_header, i64 %rb153
  %p32st.16 = getelementptr i8, ptr %rb154, i64 0
  store float 0.000000e+00, ptr %p32st.16, align 4, !dbg !130
  %rb155 = ptrtoint ptr addrspace(271) %10 to i32
  %rb156 = zext i32 %rb155 to i64
  %rb157 = getelementptr i8, ptr @_mh_execute_header, i64 %rb156
  %51 = load i32, ptr %rb157, align 16, !dbg !131
  %52 = and i32 %51, -65, !dbg !131
  %rb158 = ptrtoint ptr addrspace(271) %10 to i32
  %rb159 = zext i32 %rb158 to i64
  %rb160 = getelementptr i8, ptr @_mh_execute_header, i64 %rb159
  %p32st.17 = getelementptr i8, ptr %rb160, i64 0
  store i32 %52, ptr %p32st.17, align 16, !dbg !131
  br label %65, !dbg !132

53:                                               ; preds = %24
  %54 = icmp samesign ult i8 %16, 4, !dbg !133
  br i1 %54, label %55, label %72, !dbg !133

55:                                               ; preds = %53
  %56 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1557, !dbg !134
  %rb161 = ptrtoint ptr addrspace(271) %56 to i32
  %rb162 = zext i32 %rb161 to i64
  %rb163 = getelementptr i8, ptr @_mh_execute_header, i64 %rb162
  %57 = load i8, ptr %rb163, align 1, !dbg !134
  %58 = sext i8 %57 to i32, !dbg !135
  %59 = call i32 @EftObj_IsAnimPlaying(i32 noundef %58) #7, !dbg !136
  %60 = icmp eq i32 %59, 0, !dbg !136
  br i1 %60, label %61, label %72, !dbg !137

61:                                               ; preds = %55
  %62 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1560, !dbg !138
  %rb164 = ptrtoint ptr addrspace(271) %62 to i32
  %rb165 = zext i32 %rb164 to i64
  %rb166 = getelementptr i8, ptr @_mh_execute_header, i64 %rb165
  %p32st.18 = getelementptr i8, ptr %rb166, i64 0
  store float 0.000000e+00, ptr %p32st.18, align 4, !dbg !139
  %rb167 = ptrtoint ptr addrspace(271) %15 to i32
  %rb168 = zext i32 %rb167 to i64
  %rb169 = getelementptr i8, ptr @_mh_execute_header, i64 %rb168
  %63 = load i8, ptr %rb169, align 2, !dbg !140
  %64 = add i8 %63, 1, !dbg !140
  %rb170 = ptrtoint ptr addrspace(271) %15 to i32
  %rb171 = zext i32 %rb170 to i64
  %rb172 = getelementptr i8, ptr @_mh_execute_header, i64 %rb171
  %p32st.19 = getelementptr i8, ptr %rb172, i64 0
  store i8 %64, ptr %p32st.19, align 2, !dbg !140
  br label %65, !dbg !141

65:                                               ; preds = %22, %38, %61, %47, %31
  %66 = phi i8 [ %23, %22 ], [ %34, %31 ], [ 2, %38 ], [ %49, %47 ], [ %64, %61 ], !dbg !142
  %67 = phi i32 [ 1, %22 ], [ 2, %31 ], [ 1, %38 ], [ 1, %47 ], [ 2, %61 ], !dbg !143
  %68 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1557, !dbg !144
  %rb173 = ptrtoint ptr addrspace(271) %68 to i32
  %rb174 = zext i32 %rb173 to i64
  %rb175 = getelementptr i8, ptr @_mh_execute_header, i64 %rb174
  %69 = load i8, ptr %rb175, align 1, !dbg !144
  %70 = sext i8 %69 to i32, !dbg !145
  %71 = sext i8 %66 to i32, !dbg !146
  call void @EftObj_PlayAnim(i32 noundef %70, i32 noundef %71, i32 noundef %67) #7, !dbg !147
  br label %72, !dbg !148

72:                                               ; preds = %53, %55, %41, %35, %25, %18, %65
  %73 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1376, !dbg !149
  %rb176 = ptrtoint ptr addrspace(271) %73 to i32
  %rb177 = zext i32 %rb176 to i64
  %rb178 = getelementptr i8, ptr @_mh_execute_header, i64 %rb177
  %rb179 = icmp eq i32 %rb176, 0
  %rb180 = select i1 %rb179, ptr null, ptr %rb178
  %74 = getelementptr i8, ptr %rb180, i64 0, !dbg !150
  call void @Vec3_Clamp(ptr noundef nonnull %3, ptr noundef %74, float noundef -1.000000e+00, float noundef 1.000000e+00) #7, !dbg !151
  %rb181 = ptrtoint ptr addrspace(271) %10 to i32
  %rb182 = zext i32 %rb181 to i64
  %rb183 = getelementptr i8, ptr @_mh_execute_header, i64 %rb182
  %75 = load i32, ptr %rb183, align 16, !dbg !152
  %76 = and i32 %75, 64, !dbg !153
  %77 = icmp eq i32 %76, 0, !dbg !153
  br i1 %77, label %78, label %83, !dbg !154

78:                                               ; preds = %72
  %79 = getelementptr inbounds nuw i8, ptr %3, i64 4, !dbg !155
  %80 = load float, ptr %79, align 4, !dbg !155
  %81 = call float @Mathf_Asin(float noundef %80) #7, !dbg !156
  %82 = call float @EftMath_WrapAngle(float noundef %81) #7, !dbg !157
  call void @Mtx_RotateX(ptr noundef nonnull %2, ptr noundef nonnull %2, float noundef %82) #7, !dbg !158
  br label %83, !dbg !159

83:                                               ; preds = %78, %72
  %84 = load float, ptr %3, align 4, !dbg !160
  %85 = getelementptr inbounds nuw i8, ptr %3, i64 8, !dbg !161
  %86 = load float, ptr %85, align 4, !dbg !161
  %87 = call float @Port_atan2f(float noundef %84, float noundef %86) #7, !dbg !162
  %88 = fadd float %87, 0x400921FB40000000, !dbg !163
  %89 = call float @EftMath_WrapAngle(float noundef %88) #7, !dbg !164
  call void @Mtx_RotateY(ptr noundef nonnull %2, ptr noundef nonnull %2, float noundef %89) #7, !dbg !165
  %90 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1456, !dbg !166
  %rb184 = ptrtoint ptr addrspace(271) %90 to i32
  %rb185 = zext i32 %rb184 to i64
  %rb186 = getelementptr i8, ptr @_mh_execute_header, i64 %rb185
  %rb187 = icmp eq i32 %rb184, 0
  %rb188 = select i1 %rb187, ptr null, ptr %rb186
  %91 = getelementptr i8, ptr %rb188, i64 0, !dbg !167
  call void @Vec4_Copy(ptr noundef nonnull %4, ptr noundef %91) #7, !dbg !168
  %rb189 = ptrtoint ptr addrspace(271) %10 to i32
  %rb190 = zext i32 %rb189 to i64
  %rb191 = getelementptr i8, ptr @_mh_execute_header, i64 %rb190
  %92 = load i32, ptr %rb191, align 16, !dbg !169
  %93 = and i32 %92, 64, !dbg !170
  %94 = icmp eq i32 %93, 0, !dbg !170
  br i1 %94, label %95, label %122, !dbg !171

95:                                               ; preds = %83
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %5) #8, !dbg !172
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %5, ptr noundef nonnull align 16 dereferenceable(16) @__const.EftBlastObj_UpdateModel.ofs, i64 16, i1 false), !dbg !173
  %rb192 = ptrtoint ptr addrspace(271) %7 to i32
  %rb193 = zext i32 %rb192 to i64
  %rb194 = getelementptr i8, ptr @_mh_execute_header, i64 %rb193
  %96 = load ptr addrspace(271), ptr %rb194, align 16, !dbg !174
  %97 = getelementptr inbounds nuw i8, ptr addrspace(271) %96, i32 36, !dbg !175
  %rb195 = ptrtoint ptr addrspace(271) %97 to i32
  %rb196 = zext i32 %rb195 to i64
  %rb197 = getelementptr i8, ptr @_mh_execute_header, i64 %rb196
  %98 = load ptr addrspace(271), ptr %rb197, align 4, !dbg !175
  %rb198 = ptrtoint ptr addrspace(271) %98 to i32
  %rb199 = zext i32 %rb198 to i64
  %rb200 = getelementptr i8, ptr @_mh_execute_header, i64 %rb199
  %99 = load i16, ptr %rb200, align 4, !dbg !176
  switch i16 %99, label %106 [
    i16 622, label %101
    i16 623, label %100
  ], !dbg !177

100:                                              ; preds = %95
  br label %101, !dbg !178

101:                                              ; preds = %95, %100
  %102 = phi float [ 7.000000e+00, %100 ], [ 5.500000e+00, %95 ]
  %rb201 = ptrtoint ptr addrspace(271) %8 to i32
  %rb202 = zext i32 %rb201 to i64
  %rb203 = getelementptr i8, ptr @_mh_execute_header, i64 %rb202
  %103 = load float, ptr %rb203, align 4, !dbg !143
  %104 = fmul float %103, %102, !dbg !143
  %105 = getelementptr inbounds nuw i8, ptr %5, i64 4, !dbg !143
  store float %104, ptr %105, align 4, !dbg !143
  br label %106, !dbg !179

106:                                              ; preds = %101, %95
  call void @Mtx_MulVec4(ptr noundef nonnull %5, ptr noundef nonnull %2, ptr noundef nonnull %5) #7, !dbg !179
  call void @Vec3_Add(ptr noundef nonnull %4, ptr noundef nonnull %4, ptr noundef nonnull %5) #7, !dbg !180
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %5) #8, !dbg !181
  br label %122, !dbg !181

107:                                              ; preds = %1
  %108 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1376, !dbg !182
  %rb204 = ptrtoint ptr addrspace(271) %108 to i32
  %rb205 = zext i32 %rb204 to i64
  %rb206 = getelementptr i8, ptr @_mh_execute_header, i64 %rb205
  %rb207 = icmp eq i32 %rb204, 0
  %rb208 = select i1 %rb207, ptr null, ptr %rb206
  %109 = getelementptr i8, ptr %rb208, i64 0, !dbg !183
  call void @Vec3_Clamp(ptr noundef nonnull %3, ptr noundef %109, float noundef -1.000000e+00, float noundef 1.000000e+00) #7, !dbg !184
  %110 = getelementptr inbounds nuw i8, ptr %3, i64 4, !dbg !185
  %111 = load float, ptr %110, align 4, !dbg !185
  %112 = call float @Mathf_Asin(float noundef %111) #7, !dbg !186
  %113 = load float, ptr %3, align 4, !dbg !187
  %114 = getelementptr inbounds nuw i8, ptr %3, i64 8, !dbg !188
  %115 = load float, ptr %114, align 4, !dbg !188
  %116 = call float @Port_atan2f(float noundef %113, float noundef %115) #7, !dbg !189
  %117 = fadd float %116, 0x400921FB40000000, !dbg !190
  %118 = call float @EftMath_WrapAngle(float noundef %112) #7, !dbg !191
  %119 = call float @EftMath_WrapAngle(float noundef %117) #7, !dbg !192
  call void @Mtx_RotateY(ptr noundef nonnull %2, ptr noundef nonnull %2, float noundef %119) #7, !dbg !193
  call void @Mtx_RotateX(ptr noundef nonnull %2, ptr noundef nonnull %2, float noundef %118) #7, !dbg !194
  %120 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1456, !dbg !195
  %rb209 = ptrtoint ptr addrspace(271) %120 to i32
  %rb210 = zext i32 %rb209 to i64
  %rb211 = getelementptr i8, ptr @_mh_execute_header, i64 %rb210
  %rb212 = icmp eq i32 %rb209, 0
  %rb213 = select i1 %rb212, ptr null, ptr %rb211
  %121 = getelementptr i8, ptr %rb213, i64 0, !dbg !196
  br label %122

122:                                              ; preds = %83, %106, %107
  %123 = phi ptr [ %121, %107 ], [ %4, %106 ], [ %4, %83 ]
  call void @Mtx_Translate(ptr noundef nonnull %2, ptr noundef nonnull %2, ptr noundef %123) #7, !dbg !143
  %124 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1557, !dbg !197
  %rb214 = ptrtoint ptr addrspace(271) %124 to i32
  %rb215 = zext i32 %rb214 to i64
  %rb216 = getelementptr i8, ptr @_mh_execute_header, i64 %rb215
  %125 = load i8, ptr %rb216, align 1, !dbg !197
  %126 = sext i8 %125 to i32, !dbg !198
  call void @EftObj_SetMtx(i32 noundef %126, ptr noundef nonnull %2) #7, !dbg !199
  %rb217 = ptrtoint ptr addrspace(271) %124 to i32
  %rb218 = zext i32 %rb217 to i64
  %rb219 = getelementptr i8, ptr @_mh_execute_header, i64 %rb218
  %127 = load i8, ptr %rb219, align 1, !dbg !200
  %128 = sext i8 %127 to i32, !dbg !201
  call void @EftObj_SetVisible(i32 noundef %128, i32 noundef 1) #7, !dbg !202
  %129 = getelementptr inbounds nuw i8, ptr addrspace(271) %7, i32 1560, !dbg !203
  %rb220 = ptrtoint ptr addrspace(271) %129 to i32
  %rb221 = zext i32 %rb220 to i64
  %rb222 = getelementptr i8, ptr @_mh_execute_header, i64 %rb221
  %130 = load float, ptr %rb222, align 4, !dbg !204
  %131 = fadd float %130, 1.000000e+00, !dbg !204
  %rb223 = ptrtoint ptr addrspace(271) %129 to i32
  %rb224 = zext i32 %rb223 to i64
  %rb225 = getelementptr i8, ptr @_mh_execute_header, i64 %rb224
  %p32st.20 = getelementptr i8, ptr %rb225, i64 0
  store float %131, ptr %p32st.20, align 4, !dbg !204
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #8, !dbg !205
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #8, !dbg !205
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2) #8, !dbg !205
  ret void, !dbg !205
}

declare !dbg !206 void @Mtx_StoreIdentity(ptr noundef) local_unnamed_addr #2

declare !dbg !207 void @Mtx_ScaleDiagUniform(ptr noundef, ptr noundef, float noundef) local_unnamed_addr #2

declare !dbg !208 i32 @EftObj_IsAnimPlaying(i32 noundef) local_unnamed_addr #2

declare !dbg !209 void @EftObj_PlayAnim(i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !210 void @Vec3_Clamp(ptr noundef, ptr noundef, float noundef, float noundef) local_unnamed_addr #2

declare !dbg !211 float @EftMath_WrapAngle(float noundef) local_unnamed_addr #2

declare !dbg !212 float @Mathf_Asin(float noundef) local_unnamed_addr #2

declare !dbg !213 void @Mtx_RotateX(ptr noundef, ptr noundef, float noundef) local_unnamed_addr #2

declare !dbg !214 float @Port_atan2f(float noundef, float noundef) local_unnamed_addr #2

declare !dbg !215 void @Mtx_RotateY(ptr noundef, ptr noundef, float noundef) local_unnamed_addr #2

declare !dbg !216 void @Vec4_Copy(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

declare !dbg !217 void @Mtx_MulVec4(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !218 void @Vec3_Add(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !219 void @Mtx_Translate(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !220 void @EftObj_SetMtx(i32 noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_TermModel(ptr noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !221 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !222
  %3 = load ptr addrspace(271), ptr %2, align 4, !dbg !222
  %4 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1557, !dbg !223
  %rb226 = ptrtoint ptr addrspace(271) %4 to i32
  %rb227 = zext i32 %rb226 to i64
  %rb228 = getelementptr i8, ptr @_mh_execute_header, i64 %rb227
  %5 = load i8, ptr %rb228, align 1, !dbg !223
  %6 = sext i8 %5 to i32, !dbg !224
  tail call void @EftObj_Destroy(i32 noundef %6) #7, !dbg !225
  ret void, !dbg !226
}

declare !dbg !227 void @EftObj_Destroy(i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_UpdateParts(i32 noundef %0, ptr noundef readonly captures(none) %1, ptr noundef %2, i32 noundef %3) local_unnamed_addr #0 !dbg !228 {
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 56, !dbg !229
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !229
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %8 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 1412
  %9 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %10 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 32
  %11 = icmp eq i32 %3, 0
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 656
  %rb229 = ptrtoint ptr addrspace(271) %12 to i32
  %rb230 = zext i32 %rb229 to i64
  %rb231 = getelementptr i8, ptr @_mh_execute_header, i64 %rb230
  %rb232 = icmp eq i32 %rb229, 0
  %rb233 = select i1 %rb232, ptr null, ptr %rb231
  %13 = getelementptr i8, ptr %rb233, i64 0
  %14 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 1408
  %15 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 64
  %rb234 = ptrtoint ptr addrspace(271) %15 to i32
  %rb235 = zext i32 %rb234 to i64
  %rb236 = getelementptr i8, ptr @_mh_execute_header, i64 %rb235
  %rb237 = icmp eq i32 %rb234, 0
  %rb238 = select i1 %rb237, ptr null, ptr %rb236
  %16 = getelementptr i8, ptr %rb238, i64 0
  %17 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 1456
  %rb239 = ptrtoint ptr addrspace(271) %17 to i32
  %rb240 = zext i32 %rb239 to i64
  %rb241 = getelementptr i8, ptr @_mh_execute_header, i64 %rb240
  %rb242 = icmp eq i32 %rb239, 0
  %rb243 = select i1 %rb242, ptr null, ptr %rb241
  %18 = getelementptr i8, ptr %rb243, i64 0
  %19 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 1376
  %rb244 = ptrtoint ptr addrspace(271) %19 to i32
  %rb245 = zext i32 %rb244 to i64
  %rb246 = getelementptr i8, ptr @_mh_execute_header, i64 %rb245
  %rb247 = icmp eq i32 %rb244, 0
  %rb248 = select i1 %rb247, ptr null, ptr %rb246
  %20 = getelementptr i8, ptr %rb248, i64 0
  %21 = getelementptr inbounds nuw i8, ptr addrspace(271) %6, i32 1420
  br label %22, !dbg !230

22:                                               ; preds = %4, %86
  %23 = phi i64 [ 0, %4 ], [ %87, %86 ]
  %24 = load ptr addrspace(271), ptr %2, align 4, !dbg !231
  %rb249 = ptrtoint ptr addrspace(271) %24 to i32
  %rb250 = zext i32 %rb249 to i64
  %rb251 = getelementptr i8, ptr @_mh_execute_header, i64 %rb250
  %25 = load i32, ptr %rb251, align 4, !dbg !232
  %26 = trunc nuw nsw i64 %23 to i32, !dbg !233
  %27 = shl nuw nsw i32 1, %26, !dbg !233
  %28 = and i32 %25, %27, !dbg !234
  %29 = icmp eq i32 %28, 0, !dbg !234
  br i1 %29, label %86, label %30, !dbg !234

30:                                               ; preds = %22
  %31 = getelementptr inbounds nuw [19 x %struct.EftOGroup], ptr %7, i64 0, i64 %23, !dbg !235
  %32 = load ptr addrspace(271), ptr %31, align 4, !dbg !236
  %33 = getelementptr inbounds nuw i8, ptr addrspace(271) %32, i32 1
  %rb252 = ptrtoint ptr addrspace(271) %33 to i32
  %rb253 = zext i32 %rb252 to i64
  %rb254 = getelementptr i8, ptr @_mh_execute_header, i64 %rb253
  %34 = load i8, ptr %rb254, align 1, !dbg !237
  %35 = icmp eq i8 %34, 0, !dbg !238
  br i1 %35, label %86, label %36, !dbg !239

36:                                               ; preds = %30
  %37 = getelementptr inbounds nuw i8, ptr %31, i64 8
  br label %38, !dbg !239

38:                                               ; preds = %36, %81
  %39 = phi i32 [ 0, %36 ], [ %82, %81 ]
  %rb255 = ptrtoint ptr addrspace(271) %8 to i32
  %rb256 = zext i32 %rb255 to i64
  %rb257 = getelementptr i8, ptr @_mh_execute_header, i64 %rb256
  %40 = load i32, ptr %rb257, align 4
  %41 = icmp sgt i32 %40, 0, !dbg !240
  br i1 %41, label %42, label %81, !dbg !241

42:                                               ; preds = %38
  %43 = load i8, ptr %37, align 4, !dbg !242
  %44 = zext i8 %43 to i32, !dbg !243
  %45 = load ptr addrspace(271), ptr %9, align 4
  %46 = getelementptr inbounds nuw %struct.EftOPart, ptr addrspace(271) %45, i32 %39
  %47 = getelementptr inbounds nuw %struct.EftOPart, ptr addrspace(271) %46, i32 %44
  %48 = getelementptr inbounds nuw i8, ptr addrspace(271) %47, i32 8
  %rb258 = ptrtoint ptr addrspace(271) %48 to i32
  %rb259 = zext i32 %rb258 to i64
  %rb260 = getelementptr i8, ptr @_mh_execute_header, i64 %rb259
  %49 = load i8, ptr %rb260, align 1
  %50 = zext i8 %49 to i32
  %51 = getelementptr inbounds nuw i8, ptr addrspace(271) %47, i32 10
  br label %52, !dbg !241

52:                                               ; preds = %42, %65
  %53 = phi i32 [ 0, %42 ], [ %66, %65 ]
  %54 = getelementptr inbounds nuw [2 x %struct.EftBlastObjSel], ptr addrspace(271) %10, i32 0, i32 %53, !dbg !244
  %rb261 = ptrtoint ptr addrspace(271) %54 to i32
  %rb262 = zext i32 %rb261 to i64
  %rb263 = getelementptr i8, ptr @_mh_execute_header, i64 %rb262
  %55 = load i32, ptr %rb263, align 8, !dbg !245
  %56 = icmp eq i32 %55, %50, !dbg !246
  br i1 %56, label %57, label %65, !dbg !246

57:                                               ; preds = %52
  %rb264 = ptrtoint ptr addrspace(271) %51 to i32
  %rb265 = zext i32 %rb264 to i64
  %rb266 = getelementptr i8, ptr @_mh_execute_header, i64 %rb265
  %58 = load i8, ptr %rb266, align 1, !dbg !247
  %59 = zext i8 %58 to i32, !dbg !248
  %60 = getelementptr inbounds nuw i8, ptr addrspace(271) %54, i32 4, !dbg !249
  %rb267 = ptrtoint ptr addrspace(271) %60 to i32
  %rb268 = zext i32 %rb267 to i64
  %rb269 = getelementptr i8, ptr @_mh_execute_header, i64 %rb268
  %61 = load i32, ptr %rb269, align 4, !dbg !249
  %62 = icmp eq i32 %61, %59, !dbg !250
  %63 = icmp eq i8 %58, 5
  %64 = or i1 %63, %62, !dbg !250
  br i1 %64, label %68, label %65, !dbg !250

65:                                               ; preds = %57, %52
  %66 = add nuw nsw i32 %53, 1, !dbg !251
  %67 = icmp eq i32 %66, %40, !dbg !240
  br i1 %67, label %81, label %52, !dbg !241, !llvm.loop !252

68:                                               ; preds = %57
  br i1 %11, label %69, label %74, !dbg !254

69:                                               ; preds = %68
  %rb270 = ptrtoint ptr addrspace(271) %14 to i32
  %rb271 = zext i32 %rb270 to i64
  %rb272 = getelementptr i8, ptr @_mh_execute_header, i64 %rb271
  %70 = load i32, ptr %rb272, align 16, !dbg !255
  %71 = and i32 %70, 2, !dbg !256
  %72 = and i32 %70, 8, !dbg !257
  %73 = tail call i32 @EftEmit_GetFlagsFromReq(ptr noundef nonnull %2, ptr noundef %13, i32 noundef %0, i32 noundef %26, i32 noundef %39, i32 noundef %71, i32 noundef %72) #7, !dbg !258
  br label %76, !dbg !259

74:                                               ; preds = %68
  %75 = tail call i32 @EftEmit_GetResetFlags(ptr noundef nonnull %2, ptr noundef %13, i32 noundef %26, i32 noundef %39) #7, !dbg !260
  br label %76

76:                                               ; preds = %74, %69
  %77 = phi i32 [ %73, %69 ], [ %75, %74 ], !dbg !261
  %78 = icmp eq i32 %77, 0, !dbg !262
  br i1 %78, label %81, label %79, !dbg !262

79:                                               ; preds = %76
  %rb273 = ptrtoint ptr addrspace(271) %21 to i32
  %rb274 = zext i32 %rb273 to i64
  %rb275 = getelementptr i8, ptr @_mh_execute_header, i64 %rb274
  %80 = load float, ptr %rb275, align 4, !dbg !263
  tail call void @EftEmit_SpawnOwn(ptr noundef nonnull %2, ptr noundef %13, ptr noundef %16, ptr noundef %18, ptr noundef %20, i32 noundef %26, i32 noundef %39, i32 noundef %77, float noundef %80) #7, !dbg !264
  br label %81, !dbg !265

81:                                               ; preds = %65, %38, %76, %79
  %82 = add nuw nsw i32 %39, 1, !dbg !266
  %rb276 = ptrtoint ptr addrspace(271) %33 to i32
  %rb277 = zext i32 %rb276 to i64
  %rb278 = getelementptr i8, ptr @_mh_execute_header, i64 %rb277
  %83 = load i8, ptr %rb278, align 1, !dbg !237
  %84 = zext i8 %83 to i32, !dbg !267
  %85 = icmp samesign ult i32 %82, %84, !dbg !238
  br i1 %85, label %38, label %86, !dbg !239, !llvm.loop !268

86:                                               ; preds = %81, %30, %22
  %87 = add nuw nsw i64 %23, 1, !dbg !270
  %88 = icmp eq i64 %87, 19, !dbg !271
  br i1 %88, label %89, label %22, !dbg !230, !llvm.loop !272

89:                                               ; preds = %86
  ret void, !dbg !274
}

declare !dbg !275 i32 @EftEmit_GetFlagsFromReq(ptr noundef, ptr noundef, i32 noundef, i32 noundef, i32 noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !276 i32 @EftEmit_GetResetFlags(ptr noundef, ptr noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !277 void @EftEmit_SpawnOwn(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef, i32 noundef, i32 noundef, i32 noundef, float noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_Init(ptr noundef %0, ptr noundef %1) local_unnamed_addr #0 !dbg !278 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !279
  %4 = load ptr addrspace(271), ptr %3, align 4, !dbg !279
  %5 = load i32, ptr @EftBlastObj_Init.n, align 4, !dbg !280
  %6 = icmp slt i32 %5, 6, !dbg !281
  br i1 %6, label %7, label %18, !dbg !281

7:                                                ; preds = %2
  %8 = add nuw nsw i32 %5, 1, !dbg !282
  store i32 %8, ptr @EftBlastObj_Init.n, align 4, !dbg !282
  %9 = load ptr, ptr @__stderrp, align 8, !dbg !283
  %rb279 = ptrtoint ptr addrspace(271) %4 to i32
  %rb280 = zext i32 %rb279 to i64
  %rb281 = getelementptr i8, ptr @_mh_execute_header, i64 %rb280
  %rb282 = icmp eq i32 %rb279, 0
  %rb283 = select i1 %rb282, ptr null, ptr %rb281
  %10 = getelementptr i8, ptr %rb283, i64 0, !dbg !284
  %11 = ptrtoint ptr %1 to i64, !dbg !285
  %12 = trunc i64 %11 to i32, !dbg !285
  %13 = getelementptr inbounds nuw i8, ptr %1, i64 8, !dbg !286
  %14 = load ptr addrspace(271), ptr %13, align 4, !dbg !286
  %rb284 = ptrtoint ptr addrspace(271) %14 to i32
  %rb285 = zext i32 %rb284 to i64
  %rb286 = getelementptr i8, ptr @_mh_execute_header, i64 %rb285
  %rb287 = icmp eq i32 %rb284, 0
  %rb288 = select i1 %rb287, ptr null, ptr %rb286
  %15 = getelementptr i8, ptr %rb288, i64 0, !dbg !287
  %16 = ptrtoint ptr addrspace(271) %14 to i32, !dbg !288
  %17 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %9, ptr noundef nonnull @.str, ptr noundef nonnull %0, ptr noundef %10, ptr noundef %1, i32 noundef %12, ptr noundef %15, i32 noundef %16) #7, !dbg !289
  br label %18, !dbg !290

18:                                               ; preds = %2, %7
  %rb289 = ptrtoint ptr addrspace(271) %4 to i32
  %rb290 = zext i32 %rb289 to i64
  %rb291 = getelementptr i8, ptr @_mh_execute_header, i64 %rb290
  %rb292 = icmp eq i32 %rb289, 0
  %rb293 = select i1 %rb292, ptr null, ptr %rb291
  %19 = getelementptr i8, ptr %rb293, i64 0, !dbg !291
  %20 = tail call ptr @memset(ptr noundef %19, i32 noundef 0, i32 noundef 1568) #7, !dbg !292
  %21 = getelementptr inbounds nuw i8, ptr %1, i64 4, !dbg !293
  %22 = load ptr addrspace(271), ptr %21, align 4, !dbg !293
  %23 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 48, !dbg !294
  %rb294 = ptrtoint ptr addrspace(271) %23 to i32
  %rb295 = zext i32 %rb294 to i64
  %rb296 = getelementptr i8, ptr @_mh_execute_header, i64 %rb295
  %p32st.21 = getelementptr i8, ptr %rb296, i64 0
  store ptr addrspace(271) %22, ptr %p32st.21, align 16, !dbg !295
  %24 = load ptr addrspace(271), ptr %1, align 4, !dbg !296
  %rb297 = ptrtoint ptr addrspace(271) %4 to i32
  %rb298 = zext i32 %rb297 to i64
  %rb299 = getelementptr i8, ptr @_mh_execute_header, i64 %rb298
  %p32st.22 = getelementptr i8, ptr %rb299, i64 0
  store ptr addrspace(271) %24, ptr %p32st.22, align 16, !dbg !297
  %25 = getelementptr inbounds nuw i8, ptr %1, i64 12, !dbg !298
  %26 = load ptr addrspace(271), ptr %25, align 4, !dbg !298
  %27 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 4, !dbg !299
  %rb300 = ptrtoint ptr addrspace(271) %27 to i32
  %rb301 = zext i32 %rb300 to i64
  %rb302 = getelementptr i8, ptr @_mh_execute_header, i64 %rb301
  %p32st.23 = getelementptr i8, ptr %rb302, i64 0
  store ptr addrspace(271) %26, ptr %p32st.23, align 4, !dbg !300
  %28 = getelementptr inbounds nuw i8, ptr %1, i64 16, !dbg !301
  %29 = load ptr addrspace(271), ptr %28, align 4, !dbg !301
  %30 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 8, !dbg !302
  %rb303 = ptrtoint ptr addrspace(271) %30 to i32
  %rb304 = zext i32 %rb303 to i64
  %rb305 = getelementptr i8, ptr @_mh_execute_header, i64 %rb304
  %p32st.24 = getelementptr i8, ptr %rb305, i64 0
  store ptr addrspace(271) %29, ptr %p32st.24, align 8, !dbg !303
  %31 = getelementptr inbounds nuw i8, ptr %1, i64 20, !dbg !304
  %32 = load i32, ptr %31, align 4, !dbg !304
  %33 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 12, !dbg !305
  %rb306 = ptrtoint ptr addrspace(271) %33 to i32
  %rb307 = zext i32 %rb306 to i64
  %rb308 = getelementptr i8, ptr @_mh_execute_header, i64 %rb307
  %p32st.25 = getelementptr i8, ptr %rb308, i64 0
  store i32 %32, ptr %p32st.25, align 4, !dbg !306
  %34 = getelementptr inbounds nuw i8, ptr %1, i64 24, !dbg !307
  %35 = load i32, ptr %34, align 4, !dbg !307
  %36 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 16, !dbg !308
  %rb309 = ptrtoint ptr addrspace(271) %36 to i32
  %rb310 = zext i32 %rb309 to i64
  %rb311 = getelementptr i8, ptr @_mh_execute_header, i64 %rb310
  %p32st.26 = getelementptr i8, ptr %rb311, i64 0
  store i32 %35, ptr %p32st.26, align 16, !dbg !309
  %37 = getelementptr inbounds nuw i8, ptr %1, i64 36, !dbg !310
  %38 = load float, ptr %37, align 4, !dbg !310
  %39 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 20, !dbg !311
  %rb312 = ptrtoint ptr addrspace(271) %39 to i32
  %rb313 = zext i32 %rb312 to i64
  %rb314 = getelementptr i8, ptr @_mh_execute_header, i64 %rb313
  %p32st.27 = getelementptr i8, ptr %rb314, i64 0
  store float %38, ptr %p32st.27, align 4, !dbg !312
  %40 = getelementptr inbounds nuw i8, ptr %1, i64 40, !dbg !313
  %41 = load float, ptr %40, align 4, !dbg !313
  %42 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 24, !dbg !314
  %rb315 = ptrtoint ptr addrspace(271) %42 to i32
  %rb316 = zext i32 %rb315 to i64
  %rb317 = getelementptr i8, ptr @_mh_execute_header, i64 %rb316
  %p32st.28 = getelementptr i8, ptr %rb317, i64 0
  store float %41, ptr %p32st.28, align 8, !dbg !315
  %43 = getelementptr inbounds nuw i8, ptr %1, i64 44, !dbg !316
  %44 = load float, ptr %43, align 4, !dbg !316
  %45 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 28, !dbg !317
  %rb318 = ptrtoint ptr addrspace(271) %45 to i32
  %rb319 = zext i32 %rb318 to i64
  %rb320 = getelementptr i8, ptr @_mh_execute_header, i64 %rb319
  %p32st.29 = getelementptr i8, ptr %rb320, i64 0
  store float %44, ptr %p32st.29, align 4, !dbg !318
  %46 = getelementptr inbounds nuw i8, ptr %1, i64 28, !dbg !319
  %47 = load i32, ptr %46, align 4, !dbg !319
  %48 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 32, !dbg !320
  %rb321 = ptrtoint ptr addrspace(271) %48 to i32
  %rb322 = zext i32 %rb321 to i64
  %rb323 = getelementptr i8, ptr @_mh_execute_header, i64 %rb322
  %p32st.30 = getelementptr i8, ptr %rb323, i64 0
  store i32 %47, ptr %p32st.30, align 16, !dbg !321
  %49 = getelementptr inbounds nuw i8, ptr %1, i64 32, !dbg !322
  %50 = load i32, ptr %49, align 4, !dbg !322
  %51 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 36, !dbg !323
  %rb324 = ptrtoint ptr addrspace(271) %51 to i32
  %rb325 = zext i32 %rb324 to i64
  %rb326 = getelementptr i8, ptr @_mh_execute_header, i64 %rb325
  %p32st.31 = getelementptr i8, ptr %rb326, i64 0
  store i32 %50, ptr %p32st.31, align 4, !dbg !324
  %52 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1412, !dbg !325
  %rb327 = ptrtoint ptr addrspace(271) %52 to i32
  %rb328 = zext i32 %rb327 to i64
  %rb329 = getelementptr i8, ptr @_mh_execute_header, i64 %rb328
  %p32st.32 = getelementptr i8, ptr %rb329, i64 0
  store i32 1, ptr %p32st.32, align 4, !dbg !326
  %53 = sext i32 %50 to i64, !dbg !327
  %54 = getelementptr inbounds [7 x i32], ptr @__const.EftBlastObj_Init.slots, i64 0, i64 %53, !dbg !327
  %55 = load i32, ptr %54, align 4, !dbg !327
  %56 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 64, !dbg !328
  %57 = getelementptr inbounds nuw i8, ptr %1, i64 8, !dbg !329
  %58 = load ptr addrspace(271), ptr %57, align 4, !dbg !329
  %rb330 = ptrtoint ptr addrspace(271) %56 to i32
  %rb331 = zext i32 %rb330 to i64
  %rb332 = getelementptr i8, ptr @_mh_execute_header, i64 %rb331
  %p32fix.33 = getelementptr i8, ptr %rb332, i64 0
  %rb333 = ptrtoint ptr addrspace(271) %58 to i32
  %rb334 = zext i32 %rb333 to i64
  %rb335 = getelementptr i8, ptr @_mh_execute_header, i64 %rb334
  %p32fix.34 = getelementptr i8, ptr %rb335, i64 0
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(592) %p32fix.33, ptr noundef align 8 dereferenceable(592) %p32fix.34, i64 592, i1 false), !dbg !330
  %59 = add i32 %50, -7, !dbg !331
  %60 = icmp ult i32 %59, -2, !dbg !331
  br i1 %60, label %61, label %74, !dbg !331

61:                                               ; preds = %18
  %rb336 = ptrtoint ptr addrspace(271) %24 to i32
  %rb337 = zext i32 %rb336 to i64
  %rb338 = getelementptr i8, ptr @_mh_execute_header, i64 %rb337
  %62 = load i32, ptr %rb338, align 4, !dbg !332
  %63 = zext nneg i32 %55 to i64, !dbg !333
  %64 = getelementptr inbounds nuw [6 x i32], ptr @__const.EftBlastObj_Init.bits, i64 0, i64 %63, !dbg !333
  %65 = load i32, ptr %64, align 4, !dbg !333
  %66 = sext i32 %65 to i64, !dbg !333
  %67 = tail call i32 @EftShot_GetAttrKind(i32 noundef %62, i64 noundef %66) #7, !dbg !334
  %68 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 80, !dbg !335
  %69 = getelementptr inbounds [6 x [2 x %struct.EftOEmitNode]], ptr addrspace(271) %68, i32 0, i32 %55, !dbg !336
  %rb339 = ptrtoint ptr addrspace(271) %69 to i32
  %rb340 = zext i32 %rb339 to i64
  %rb341 = getelementptr i8, ptr @_mh_execute_header, i64 %rb340
  %p32st.35 = getelementptr i8, ptr %rb341, i64 0
  store i32 %67, ptr %p32st.35, align 16, !dbg !337
  %rb342 = ptrtoint ptr addrspace(271) %24 to i32
  %rb343 = zext i32 %rb342 to i64
  %rb344 = getelementptr i8, ptr @_mh_execute_header, i64 %rb343
  %70 = load i32, ptr %rb344, align 4, !dbg !338
  %71 = getelementptr inbounds nuw i8, ptr addrspace(271) %69, i32 16, !dbg !339
  %rb345 = ptrtoint ptr addrspace(271) %71 to i32
  %rb346 = zext i32 %rb345 to i64
  %rb347 = getelementptr i8, ptr @_mh_execute_header, i64 %rb346
  %rb348 = icmp eq i32 %rb345, 0
  %rb349 = select i1 %rb348, ptr null, ptr %rb347
  %72 = getelementptr i8, ptr %rb349, i64 0, !dbg !340
  tail call void @BtlCharApi_GetNodePos(i32 noundef %70, i32 noundef %67, ptr noundef %72) #7, !dbg !341
  %rb350 = ptrtoint ptr addrspace(271) %39 to i32
  %rb351 = zext i32 %rb350 to i64
  %rb352 = getelementptr i8, ptr @_mh_execute_header, i64 %rb351
  %73 = load float, ptr %rb352, align 4, !dbg !342
  br label %74, !dbg !343

74:                                               ; preds = %61, %18
  %75 = phi float [ %73, %61 ], [ %38, %18 ], !dbg !342
  %76 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1408, !dbg !344
  %rb353 = ptrtoint ptr addrspace(271) %76 to i32
  %rb354 = zext i32 %rb353 to i64
  %rb355 = getelementptr i8, ptr @_mh_execute_header, i64 %rb354
  %77 = load i32, ptr %rb355, align 16, !dbg !345
  %78 = or i32 %77, 1, !dbg !345
  %rb356 = ptrtoint ptr addrspace(271) %76 to i32
  %rb357 = zext i32 %rb356 to i64
  %rb358 = getelementptr i8, ptr @_mh_execute_header, i64 %rb357
  %p32st.36 = getelementptr i8, ptr %rb358, i64 0
  store i32 %78, ptr %p32st.36, align 16, !dbg !345
  %79 = fcmp ogt float %75, 0.000000e+00, !dbg !346
  br i1 %79, label %80, label %84, !dbg !346

80:                                               ; preds = %74
  %81 = or i32 %77, 1025, !dbg !347
  %rb359 = ptrtoint ptr addrspace(271) %76 to i32
  %rb360 = zext i32 %rb359 to i64
  %rb361 = getelementptr i8, ptr @_mh_execute_header, i64 %rb360
  %p32st.37 = getelementptr i8, ptr %rb361, i64 0
  store i32 %81, ptr %p32st.37, align 16, !dbg !347
  %82 = fmul float %75, 3.000000e+01, !dbg !348
  %83 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1416, !dbg !349
  %rb362 = ptrtoint ptr addrspace(271) %83 to i32
  %rb363 = zext i32 %rb362 to i64
  %rb364 = getelementptr i8, ptr @_mh_execute_header, i64 %rb363
  %p32st.38 = getelementptr i8, ptr %rb364, i64 0
  store float %82, ptr %p32st.38, align 8, !dbg !350
  br label %84, !dbg !351

84:                                               ; preds = %80, %74
  %rb365 = ptrtoint ptr addrspace(271) %42 to i32
  %rb366 = zext i32 %rb365 to i64
  %rb367 = getelementptr i8, ptr @_mh_execute_header, i64 %rb366
  %85 = load float, ptr %rb367, align 8, !dbg !352
  %86 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1420, !dbg !353
  %rb368 = ptrtoint ptr addrspace(271) %86 to i32
  %rb369 = zext i32 %rb368 to i64
  %rb370 = getelementptr i8, ptr @_mh_execute_header, i64 %rb369
  %p32st.39 = getelementptr i8, ptr %rb370, i64 0
  store float %85, ptr %p32st.39, align 4, !dbg !354
  %87 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1440, !dbg !355
  %rb371 = ptrtoint ptr addrspace(271) %87 to i32
  %rb372 = zext i32 %rb371 to i64
  %rb373 = getelementptr i8, ptr @_mh_execute_header, i64 %rb372
  %rb374 = icmp eq i32 %rb371, 0
  %rb375 = select i1 %rb374, ptr null, ptr %rb373
  %88 = getelementptr i8, ptr %rb375, i64 0, !dbg !356
  %rb376 = ptrtoint ptr addrspace(271) %27 to i32
  %rb377 = zext i32 %rb376 to i64
  %rb378 = getelementptr i8, ptr @_mh_execute_header, i64 %rb377
  %89 = load ptr addrspace(271), ptr %rb378, align 4, !dbg !357
  %rb379 = ptrtoint ptr addrspace(271) %89 to i32
  %rb380 = zext i32 %rb379 to i64
  %rb381 = getelementptr i8, ptr @_mh_execute_header, i64 %rb380
  %rb382 = icmp eq i32 %rb379, 0
  %rb383 = select i1 %rb382, ptr null, ptr %rb381
  %90 = getelementptr i8, ptr %rb383, i64 0, !dbg !358
  tail call void @Vec4_Copy(ptr noundef %88, ptr noundef %90) #7, !dbg !359
  %91 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1456, !dbg !360
  %rb384 = ptrtoint ptr addrspace(271) %91 to i32
  %rb385 = zext i32 %rb384 to i64
  %rb386 = getelementptr i8, ptr @_mh_execute_header, i64 %rb385
  %rb387 = icmp eq i32 %rb384, 0
  %rb388 = select i1 %rb387, ptr null, ptr %rb386
  %92 = getelementptr i8, ptr %rb388, i64 0, !dbg !361
  tail call void @Vec4_Copy(ptr noundef %92, ptr noundef %88) #7, !dbg !362
  %93 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1376, !dbg !363
  %rb389 = ptrtoint ptr addrspace(271) %93 to i32
  %rb390 = zext i32 %rb389 to i64
  %rb391 = getelementptr i8, ptr @_mh_execute_header, i64 %rb390
  %rb392 = icmp eq i32 %rb389, 0
  %rb393 = select i1 %rb392, ptr null, ptr %rb391
  %94 = getelementptr i8, ptr %rb393, i64 0, !dbg !364
  %rb394 = ptrtoint ptr addrspace(271) %30 to i32
  %rb395 = zext i32 %rb394 to i64
  %rb396 = getelementptr i8, ptr @_mh_execute_header, i64 %rb395
  %95 = load ptr addrspace(271), ptr %rb396, align 8, !dbg !365
  %rb397 = ptrtoint ptr addrspace(271) %95 to i32
  %rb398 = zext i32 %rb397 to i64
  %rb399 = getelementptr i8, ptr @_mh_execute_header, i64 %rb398
  %rb400 = icmp eq i32 %rb397, 0
  %rb401 = select i1 %rb400, ptr null, ptr %rb399
  %96 = getelementptr i8, ptr %rb401, i64 0, !dbg !366
  tail call void @Vec4_Copy(ptr noundef %94, ptr noundef %96) #7, !dbg !367
  %rb402 = ptrtoint ptr addrspace(271) %24 to i32
  %rb403 = zext i32 %rb402 to i64
  %rb404 = getelementptr i8, ptr @_mh_execute_header, i64 %rb403
  %97 = load i32, ptr %rb404, align 4, !dbg !368
  %98 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1472, !dbg !369
  %rb405 = ptrtoint ptr addrspace(271) %98 to i32
  %rb406 = zext i32 %rb405 to i64
  %rb407 = getelementptr i8, ptr @_mh_execute_header, i64 %rb406
  %rb408 = icmp eq i32 %rb405, 0
  %rb409 = select i1 %rb408, ptr null, ptr %rb407
  %99 = getelementptr i8, ptr %rb409, i64 0, !dbg !370
  tail call void @BtlCharApi_GetNodePos(i32 noundef %97, i32 noundef 17, ptr noundef %99) #7, !dbg !371
  %100 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1488, !dbg !372
  %rb410 = ptrtoint ptr addrspace(271) %100 to i32
  %rb411 = zext i32 %rb410 to i64
  %rb412 = getelementptr i8, ptr @_mh_execute_header, i64 %rb411
  %rb413 = icmp eq i32 %rb410, 0
  %rb414 = select i1 %rb413, ptr null, ptr %rb412
  %101 = getelementptr i8, ptr %rb414, i64 0, !dbg !373
  %rb415 = ptrtoint ptr addrspace(271) %45 to i32
  %rb416 = zext i32 %rb415 to i64
  %rb417 = getelementptr i8, ptr @_mh_execute_header, i64 %rb416
  %102 = load float, ptr %rb417, align 4, !dbg !374
  tail call void @Vec3_Scale(ptr noundef %101, ptr noundef %94, float noundef %102) #7, !dbg !375
  %103 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1424, !dbg !376
  %rb418 = ptrtoint ptr addrspace(271) %103 to i32
  %rb419 = zext i32 %rb418 to i64
  %rb420 = getelementptr i8, ptr @_mh_execute_header, i64 %rb419
  %p32st.40 = getelementptr i8, ptr %rb420, i64 0
  store float 1.000000e+00, ptr %p32st.40, align 16, !dbg !377
  %rb421 = ptrtoint ptr addrspace(271) %23 to i32
  %rb422 = zext i32 %rb421 to i64
  %rb423 = getelementptr i8, ptr @_mh_execute_header, i64 %rb422
  %104 = load ptr addrspace(271), ptr %rb423, align 16, !dbg !378
  %rb424 = ptrtoint ptr addrspace(271) %104 to i32
  %rb425 = zext i32 %rb424 to i64
  %rb426 = getelementptr i8, ptr @_mh_execute_header, i64 %rb425
  %rb427 = icmp eq i32 %rb424, 0
  %rb428 = select i1 %rb427, ptr null, ptr %rb426
  %105 = getelementptr i8, ptr %rb428, i64 0, !dbg !379
  %106 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 656, !dbg !380
  %rb429 = ptrtoint ptr addrspace(271) %106 to i32
  %rb430 = zext i32 %rb429 to i64
  %rb431 = getelementptr i8, ptr @_mh_execute_header, i64 %rb430
  %rb432 = icmp eq i32 %rb429, 0
  %rb433 = select i1 %rb432, ptr null, ptr %rb431
  %107 = getelementptr i8, ptr %rb433, i64 0, !dbg !381
  tail call void @EftEmit_InitState(ptr noundef %105, ptr noundef %107) #7, !dbg !382
  %108 = getelementptr inbounds nuw i8, ptr %1, i64 48, !dbg !383
  %109 = load ptr addrspace(271), ptr %108, align 4, !dbg !383
  %110 = icmp eq ptr addrspace(271) %109, null, !dbg !384
  br i1 %110, label %130, label %111, !dbg !384

111:                                              ; preds = %84
  %rb434 = ptrtoint ptr addrspace(271) %76 to i32
  %rb435 = zext i32 %rb434 to i64
  %rb436 = getelementptr i8, ptr @_mh_execute_header, i64 %rb435
  %112 = load i32, ptr %rb436, align 16, !dbg !385
  %113 = or i32 %112, 4096, !dbg !385
  %rb437 = ptrtoint ptr addrspace(271) %76 to i32
  %rb438 = zext i32 %rb437 to i64
  %rb439 = getelementptr i8, ptr @_mh_execute_header, i64 %rb438
  %p32st.41 = getelementptr i8, ptr %rb439, i64 0
  store i32 %113, ptr %p32st.41, align 16, !dbg !385
  %114 = load ptr addrspace(271), ptr %108, align 4, !dbg !386
  %115 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 1504, !dbg !387
  %rb440 = ptrtoint ptr addrspace(271) %115 to i32
  %rb441 = zext i32 %rb440 to i64
  %rb442 = getelementptr i8, ptr @_mh_execute_header, i64 %rb441
  %p32st.42 = getelementptr i8, ptr %rb442, i64 0
  store ptr addrspace(271) %114, ptr %p32st.42, align 16, !dbg !388
  %116 = load ptr addrspace(271), ptr %3, align 4, !dbg !389
  %117 = getelementptr inbounds nuw i8, ptr addrspace(271) %116, i32 1504, !dbg !391
  %118 = getelementptr inbounds nuw i8, ptr addrspace(271) %116, i32 1508, !dbg !392
  %rb443 = ptrtoint ptr addrspace(271) %118 to i32
  %rb444 = zext i32 %rb443 to i64
  %rb445 = getelementptr i8, ptr @_mh_execute_header, i64 %rb444
  %rb446 = icmp eq i32 %rb443, 0
  %rb447 = select i1 %rb446, ptr null, ptr %rb445
  %119 = getelementptr i8, ptr %rb447, i64 0, !dbg !393
  %rb448 = ptrtoint ptr addrspace(271) %117 to i32
  %rb449 = zext i32 %rb448 to i64
  %rb450 = getelementptr i8, ptr @_mh_execute_header, i64 %rb449
  %120 = load ptr addrspace(271), ptr %rb450, align 4, !dbg !394
  %rb451 = ptrtoint ptr addrspace(271) %120 to i32
  %rb452 = zext i32 %rb451 to i64
  %rb453 = getelementptr i8, ptr @_mh_execute_header, i64 %rb452
  %rb454 = icmp eq i32 %rb451, 0
  %rb455 = select i1 %rb454, ptr null, ptr %rb453
  %121 = getelementptr i8, ptr %rb455, i64 0, !dbg !395
  %122 = tail call i32 @EftObj_Create(ptr noundef %119, ptr noundef %121) #7, !dbg !396
  %123 = trunc i32 %122 to i8, !dbg !396
  %124 = getelementptr inbounds nuw i8, ptr addrspace(271) %116, i32 1557, !dbg !397
  %rb456 = ptrtoint ptr addrspace(271) %124 to i32
  %rb457 = zext i32 %rb456 to i64
  %rb458 = getelementptr i8, ptr @_mh_execute_header, i64 %rb457
  %p32st.43 = getelementptr i8, ptr %rb458, i64 0
  store i8 %123, ptr %p32st.43, align 1, !dbg !398
  %125 = getelementptr inbounds nuw i8, ptr addrspace(271) %116, i32 1558, !dbg !399
  %rb459 = ptrtoint ptr addrspace(271) %125 to i32
  %rb460 = zext i32 %rb459 to i64
  %rb461 = getelementptr i8, ptr @_mh_execute_header, i64 %rb460
  %p32st.44 = getelementptr i8, ptr %rb461, i64 0
  store i8 -1, ptr %p32st.44, align 2, !dbg !400
  %126 = shl i32 %122, 24, !dbg !401
  %127 = ashr exact i32 %126, 24, !dbg !401
  tail call void @EftObj_SetVisible(i32 noundef %127, i32 noundef 0) #7, !dbg !402
  %rb462 = ptrtoint ptr addrspace(271) %124 to i32
  %rb463 = zext i32 %rb462 to i64
  %rb464 = getelementptr i8, ptr @_mh_execute_header, i64 %rb463
  %128 = load i8, ptr %rb464, align 1, !dbg !403
  %129 = sext i8 %128 to i32, !dbg !404
  tail call void @EftObj_Nop(i32 noundef %129, i32 noundef 0) #7, !dbg !405
  br label %130, !dbg !406

130:                                              ; preds = %111, %84
  %rb465 = ptrtoint ptr addrspace(271) %24 to i32
  %rb466 = zext i32 %rb465 to i64
  %rb467 = getelementptr i8, ptr @_mh_execute_header, i64 %rb466
  %131 = load i32, ptr %rb467, align 4, !dbg !407
  %132 = icmp eq i32 %131, 0, !dbg !408
  %133 = select i1 %132, i32 2048, i32 4096, !dbg !409
  tail call void @BtlTask_SetOwnerTag(ptr noundef nonnull %0, i32 noundef %133) #7, !dbg !410
  ret void, !dbg !411
}

declare !dbg !412 i32 @fprintf(ptr noundef, ptr noundef, ...) local_unnamed_addr #2

declare !dbg !414 ptr @memset(ptr noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !415 i32 @EftShot_GetAttrKind(i32 noundef, i64 noundef) local_unnamed_addr #2

declare !dbg !416 void @BtlCharApi_GetNodePos(i32 noundef, i32 noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !417 void @Vec3_Scale(ptr noundef, ptr noundef, float noundef) local_unnamed_addr #2

declare !dbg !418 void @EftEmit_InitState(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !419 void @BtlTask_SetOwnerTag(ptr noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_Term(ptr noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !420 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !421
  %3 = load ptr addrspace(271), ptr %2, align 4, !dbg !421
  %4 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1408, !dbg !422
  %rb468 = ptrtoint ptr addrspace(271) %4 to i32
  %rb469 = zext i32 %rb468 to i64
  %rb470 = getelementptr i8, ptr @_mh_execute_header, i64 %rb469
  %5 = load i32, ptr %rb470, align 16, !dbg !422
  %6 = and i32 %5, 4096, !dbg !423
  %7 = icmp eq i32 %6, 0, !dbg !423
  br i1 %7, label %12, label %8, !dbg !423

8:                                                ; preds = %1
  %9 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1557, !dbg !424
  %rb471 = ptrtoint ptr addrspace(271) %9 to i32
  %rb472 = zext i32 %rb471 to i64
  %rb473 = getelementptr i8, ptr @_mh_execute_header, i64 %rb472
  %10 = load i8, ptr %rb473, align 1, !dbg !424
  %11 = sext i8 %10 to i32, !dbg !426
  tail call void @EftObj_Destroy(i32 noundef %11) #7, !dbg !427
  br label %12, !dbg !428

12:                                               ; preds = %8, %1
  %13 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 48, !dbg !429
  %rb474 = ptrtoint ptr addrspace(271) %13 to i32
  %rb475 = zext i32 %rb474 to i64
  %rb476 = getelementptr i8, ptr @_mh_execute_header, i64 %rb475
  %14 = load ptr addrspace(271), ptr %rb476, align 16, !dbg !429
  %rb477 = ptrtoint ptr addrspace(271) %14 to i32
  %rb478 = zext i32 %rb477 to i64
  %rb479 = getelementptr i8, ptr @_mh_execute_header, i64 %rb478
  %rb480 = icmp eq i32 %rb477, 0
  %rb481 = select i1 %rb480, ptr null, ptr %rb479
  %15 = getelementptr i8, ptr %rb481, i64 0, !dbg !430
  %16 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 656, !dbg !431
  %rb482 = ptrtoint ptr addrspace(271) %16 to i32
  %rb483 = zext i32 %rb482 to i64
  %rb484 = getelementptr i8, ptr @_mh_execute_header, i64 %rb483
  %rb485 = icmp eq i32 %rb482, 0
  %rb486 = select i1 %rb485, ptr null, ptr %rb484
  %17 = getelementptr i8, ptr %rb486, i64 0, !dbg !432
  tail call void @EftEmit_TermState(ptr noundef %15, ptr noundef %17) #7, !dbg !433
  %rb487 = ptrtoint ptr addrspace(271) %4 to i32
  %rb488 = zext i32 %rb487 to i64
  %rb489 = getelementptr i8, ptr @_mh_execute_header, i64 %rb488
  %p32st.45 = getelementptr i8, ptr %rb489, i64 0
  store i32 0, ptr %p32st.45, align 16, !dbg !434
  ret void, !dbg !435
}

declare !dbg !436 void @EftEmit_TermState(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_Update(ptr noundef %0) #0 !dbg !437 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !438
  %3 = load ptr addrspace(271), ptr %2, align 4, !dbg !438
  %rb490 = ptrtoint ptr addrspace(271) %3 to i32
  %rb491 = zext i32 %rb490 to i64
  %rb492 = getelementptr i8, ptr @_mh_execute_header, i64 %rb491
  %4 = load ptr addrspace(271), ptr %rb492, align 16, !dbg !439
  %rb493 = ptrtoint ptr addrspace(271) %4 to i32
  %rb494 = zext i32 %rb493 to i64
  %rb495 = getelementptr i8, ptr @_mh_execute_header, i64 %rb494
  %5 = load i32, ptr %rb495, align 4, !dbg !440
  %6 = tail call i32 @BtlScene_IsCharStopped(i32 noundef %5) #7, !dbg !441
  %7 = icmp eq i32 %6, 0, !dbg !441
  br i1 %7, label %8, label %118, !dbg !441

8:                                                ; preds = %1
  %9 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1408, !dbg !442
  %rb496 = ptrtoint ptr addrspace(271) %9 to i32
  %rb497 = zext i32 %rb496 to i64
  %rb498 = getelementptr i8, ptr @_mh_execute_header, i64 %rb497
  %10 = load i32, ptr %rb498, align 16, !dbg !442
  %11 = and i32 %10, 8192, !dbg !443
  %12 = icmp eq i32 %11, 0, !dbg !443
  br i1 %12, label %20, label %13, !dbg !444

13:                                               ; preds = %8
  %rb499 = ptrtoint ptr addrspace(271) %4 to i32
  %rb500 = zext i32 %rb499 to i64
  %rb501 = getelementptr i8, ptr @_mh_execute_header, i64 %rb500
  %14 = load i32, ptr %rb501, align 4, !dbg !445
  %15 = tail call i32 @EftShot_TestBits(i32 noundef %14, i32 noundef 4) #7, !dbg !446
  %16 = icmp eq i32 %15, 0, !dbg !446
  br i1 %16, label %20, label %17, !dbg !444

17:                                               ; preds = %13
  %rb502 = ptrtoint ptr addrspace(271) %9 to i32
  %rb503 = zext i32 %rb502 to i64
  %rb504 = getelementptr i8, ptr @_mh_execute_header, i64 %rb503
  %18 = load i32, ptr %rb504, align 16, !dbg !447
  %19 = or i32 %18, 16384, !dbg !447
  %rb505 = ptrtoint ptr addrspace(271) %9 to i32
  %rb506 = zext i32 %rb505 to i64
  %rb507 = getelementptr i8, ptr @_mh_execute_header, i64 %rb506
  %p32st.46 = getelementptr i8, ptr %rb507, i64 0
  store i32 %19, ptr %p32st.46, align 16, !dbg !447
  br label %20, !dbg !448

20:                                               ; preds = %17, %13, %8
  %rb508 = ptrtoint ptr addrspace(271) %4 to i32
  %rb509 = zext i32 %rb508 to i64
  %rb510 = getelementptr i8, ptr @_mh_execute_header, i64 %rb509
  %rb511 = icmp eq i32 %rb508, 0
  %rb512 = select i1 %rb511, ptr null, ptr %rb510
  %21 = getelementptr i8, ptr %rb512, i64 0, !dbg !449
  %22 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 64, !dbg !450
  %rb513 = ptrtoint ptr addrspace(271) %22 to i32
  %rb514 = zext i32 %rb513 to i64
  %rb515 = getelementptr i8, ptr @_mh_execute_header, i64 %rb514
  %rb516 = icmp eq i32 %rb513, 0
  %rb517 = select i1 %rb516, ptr null, ptr %rb515
  %23 = getelementptr i8, ptr %rb517, i64 0, !dbg !451
  tail call void @EftEmit_UpdateNodesReq(ptr noundef %21, ptr noundef %23) #7, !dbg !452
  %24 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1424, !dbg !453
  %rb518 = ptrtoint ptr addrspace(271) %24 to i32
  %rb519 = zext i32 %rb518 to i64
  %rb520 = getelementptr i8, ptr @_mh_execute_header, i64 %rb519
  %25 = load float, ptr %rb520, align 16, !dbg !453
  %26 = fcmp ugt float %25, 0.000000e+00, !dbg !454
  br i1 %26, label %68, label %27, !dbg !455

27:                                               ; preds = %20
  %28 = getelementptr inbounds nuw i8, ptr addrspace(271) %4, i32 36, !dbg !456
  %rb521 = ptrtoint ptr addrspace(271) %28 to i32
  %rb522 = zext i32 %rb521 to i64
  %rb523 = getelementptr i8, ptr @_mh_execute_header, i64 %rb522
  %29 = load ptr addrspace(271), ptr %rb523, align 4, !dbg !456
  %30 = getelementptr inbounds nuw i8, ptr addrspace(271) %29, i32 60, !dbg !457
  %rb524 = ptrtoint ptr addrspace(271) %30 to i32
  %rb525 = zext i32 %rb524 to i64
  %rb526 = getelementptr i8, ptr @_mh_execute_header, i64 %rb525
  %31 = load i32, ptr %rb526, align 4, !dbg !457
  %32 = and i32 %31, 2, !dbg !458
  %33 = icmp eq i32 %32, 0, !dbg !458
  br i1 %33, label %34, label %66, !dbg !455

34:                                               ; preds = %27
  %rb527 = ptrtoint ptr addrspace(271) %9 to i32
  %rb528 = zext i32 %rb527 to i64
  %rb529 = getelementptr i8, ptr @_mh_execute_header, i64 %rb528
  %35 = load i32, ptr %rb529, align 16, !dbg !459
  %36 = and i32 %35, 96, !dbg !460
  %37 = icmp eq i32 %36, 0, !dbg !460
  br i1 %37, label %38, label %66, !dbg !460

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1472, !dbg !461
  %rb530 = ptrtoint ptr addrspace(271) %39 to i32
  %rb531 = zext i32 %rb530 to i64
  %rb532 = getelementptr i8, ptr @_mh_execute_header, i64 %rb531
  %rb533 = icmp eq i32 %rb530, 0
  %rb534 = select i1 %rb533, ptr null, ptr %rb532
  %40 = getelementptr i8, ptr %rb534, i64 0, !dbg !462
  %41 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1456, !dbg !463
  %rb535 = ptrtoint ptr addrspace(271) %41 to i32
  %rb536 = zext i32 %rb535 to i64
  %rb537 = getelementptr i8, ptr @_mh_execute_header, i64 %rb536
  %rb538 = icmp eq i32 %rb535, 0
  %rb539 = select i1 %rb538, ptr null, ptr %rb537
  %42 = getelementptr i8, ptr %rb539, i64 0, !dbg !464
  tail call void @Vec4_Copy(ptr noundef %40, ptr noundef %42) #7, !dbg !465
  %rb540 = ptrtoint ptr addrspace(271) %9 to i32
  %rb541 = zext i32 %rb540 to i64
  %rb542 = getelementptr i8, ptr @_mh_execute_header, i64 %rb541
  %43 = load i32, ptr %rb542, align 16, !dbg !466
  %44 = and i32 %43, 512, !dbg !467
  %45 = icmp eq i32 %44, 0, !dbg !467
  br i1 %45, label %49, label %46, !dbg !467

46:                                               ; preds = %38
  %47 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1392, !dbg !468
  %rb543 = ptrtoint ptr addrspace(271) %47 to i32
  %rb544 = zext i32 %rb543 to i64
  %rb545 = getelementptr i8, ptr @_mh_execute_header, i64 %rb544
  %rb546 = icmp eq i32 %rb543, 0
  %rb547 = select i1 %rb546, ptr null, ptr %rb545
  %48 = getelementptr i8, ptr %rb547, i64 0, !dbg !469
  tail call void @Vec4_Copy(ptr noundef %42, ptr noundef %48) #7, !dbg !470
  br label %66, !dbg !471

49:                                               ; preds = %38
  %rb548 = ptrtoint ptr addrspace(271) %28 to i32
  %rb549 = zext i32 %rb548 to i64
  %rb550 = getelementptr i8, ptr @_mh_execute_header, i64 %rb549
  %50 = load ptr addrspace(271), ptr %rb550, align 4, !dbg !472
  %51 = getelementptr inbounds nuw i8, ptr addrspace(271) %50, i32 56, !dbg !473
  %rb551 = ptrtoint ptr addrspace(271) %51 to i32
  %rb552 = zext i32 %rb551 to i64
  %rb553 = getelementptr i8, ptr @_mh_execute_header, i64 %rb552
  %52 = load float, ptr %rb553, align 4, !dbg !473
  %53 = fcmp ogt float %52, 0.000000e+00, !dbg !474
  br i1 %53, label %54, label %63, !dbg !474

54:                                               ; preds = %49
  %55 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1376, !dbg !475
  %rb554 = ptrtoint ptr addrspace(271) %55 to i32
  %rb555 = zext i32 %rb554 to i64
  %rb556 = getelementptr i8, ptr @_mh_execute_header, i64 %rb555
  %rb557 = icmp eq i32 %rb554, 0
  %rb558 = select i1 %rb557, ptr null, ptr %rb556
  %56 = getelementptr i8, ptr %rb558, i64 0, !dbg !476
  %rb559 = ptrtoint ptr addrspace(271) %4 to i32
  %rb560 = zext i32 %rb559 to i64
  %rb561 = getelementptr i8, ptr @_mh_execute_header, i64 %rb560
  %57 = load i32, ptr %rb561, align 4, !dbg !477
  %58 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 28, !dbg !478
  %rb562 = ptrtoint ptr addrspace(271) %58 to i32
  %rb563 = zext i32 %rb562 to i64
  %rb564 = getelementptr i8, ptr @_mh_execute_header, i64 %rb563
  %59 = load float, ptr %rb564, align 4, !dbg !478
  tail call void @EftAim_Home(ptr noundef %56, ptr noundef %42, ptr noundef %56, i32 noundef %57, float noundef %59, float noundef %52) #7, !dbg !479
  %60 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1488, !dbg !480
  %rb565 = ptrtoint ptr addrspace(271) %60 to i32
  %rb566 = zext i32 %rb565 to i64
  %rb567 = getelementptr i8, ptr @_mh_execute_header, i64 %rb566
  %rb568 = icmp eq i32 %rb565, 0
  %rb569 = select i1 %rb568, ptr null, ptr %rb567
  %61 = getelementptr i8, ptr %rb569, i64 0, !dbg !481
  %rb570 = ptrtoint ptr addrspace(271) %58 to i32
  %rb571 = zext i32 %rb570 to i64
  %rb572 = getelementptr i8, ptr @_mh_execute_header, i64 %rb571
  %62 = load float, ptr %rb572, align 4, !dbg !482
  tail call void @Vec3_Scale(ptr noundef %61, ptr noundef %56, float noundef %62) #7, !dbg !483
  br label %63, !dbg !484

63:                                               ; preds = %49, %54
  %64 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1488, !dbg !485
  %rb573 = ptrtoint ptr addrspace(271) %64 to i32
  %rb574 = zext i32 %rb573 to i64
  %rb575 = getelementptr i8, ptr @_mh_execute_header, i64 %rb574
  %rb576 = icmp eq i32 %rb573, 0
  %rb577 = select i1 %rb576, ptr null, ptr %rb575
  %65 = getelementptr i8, ptr %rb577, i64 0, !dbg !486
  tail call void @Vec3_Add(ptr noundef %42, ptr noundef %42, ptr noundef %65) #7, !dbg !487
  br label %66

66:                                               ; preds = %27, %63, %46, %34
  %rb578 = ptrtoint ptr addrspace(271) %24 to i32
  %rb579 = zext i32 %rb578 to i64
  %rb580 = getelementptr i8, ptr @_mh_execute_header, i64 %rb579
  %67 = load float, ptr %rb580, align 16, !dbg !488
  br label %68, !dbg !488

68:                                               ; preds = %66, %20
  %69 = phi float [ %67, %66 ], [ %25, %20 ], !dbg !488
  %70 = fcmp ogt float %69, 0.000000e+00, !dbg !489
  br i1 %70, label %71, label %73, !dbg !489

71:                                               ; preds = %68
  %72 = fadd float %69, -1.000000e+00, !dbg !490
  %rb581 = ptrtoint ptr addrspace(271) %24 to i32
  %rb582 = zext i32 %rb581 to i64
  %rb583 = getelementptr i8, ptr @_mh_execute_header, i64 %rb582
  %p32st.47 = getelementptr i8, ptr %rb583, i64 0
  store float %72, ptr %p32st.47, align 16, !dbg !490
  br label %73, !dbg !491

73:                                               ; preds = %71, %68
  %rb584 = ptrtoint ptr addrspace(271) %9 to i32
  %rb585 = zext i32 %rb584 to i64
  %rb586 = getelementptr i8, ptr @_mh_execute_header, i64 %rb585
  %74 = load i32, ptr %rb586, align 16, !dbg !492
  %75 = and i32 %74, 1024, !dbg !493
  %76 = icmp eq i32 %75, 0, !dbg !493
  br i1 %76, label %84, label %77, !dbg !493

77:                                               ; preds = %73
  %78 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1416, !dbg !494
  %rb587 = ptrtoint ptr addrspace(271) %78 to i32
  %rb588 = zext i32 %rb587 to i64
  %rb589 = getelementptr i8, ptr @_mh_execute_header, i64 %rb588
  %79 = load float, ptr %rb589, align 8, !dbg !495
  %80 = fadd float %79, -1.000000e+00, !dbg !495
  %rb590 = ptrtoint ptr addrspace(271) %78 to i32
  %rb591 = zext i32 %rb590 to i64
  %rb592 = getelementptr i8, ptr @_mh_execute_header, i64 %rb591
  %p32st.48 = getelementptr i8, ptr %rb592, i64 0
  store float %80, ptr %p32st.48, align 8, !dbg !495
  %81 = fcmp ugt float %80, 0.000000e+00, !dbg !496
  br i1 %81, label %84, label %82, !dbg !496

82:                                               ; preds = %77
  %83 = or i32 %74, 2, !dbg !497
  %rb593 = ptrtoint ptr addrspace(271) %9 to i32
  %rb594 = zext i32 %rb593 to i64
  %rb595 = getelementptr i8, ptr @_mh_execute_header, i64 %rb594
  %p32st.49 = getelementptr i8, ptr %rb595, i64 0
  store i32 %83, ptr %p32st.49, align 16, !dbg !497
  br label %84, !dbg !498

84:                                               ; preds = %77, %82, %73
  %rb596 = ptrtoint ptr addrspace(271) %4 to i32
  %rb597 = zext i32 %rb596 to i64
  %rb598 = getelementptr i8, ptr @_mh_execute_header, i64 %rb597
  %85 = load i32, ptr %rb598, align 4, !dbg !499
  %86 = tail call i32 @EftShot_TestBits(i32 noundef %85, i32 noundef 1024) #7, !dbg !500
  %87 = icmp eq i32 %86, 0, !dbg !500
  %rb599 = ptrtoint ptr addrspace(271) %9 to i32
  %rb600 = zext i32 %rb599 to i64
  %rb601 = getelementptr i8, ptr @_mh_execute_header, i64 %rb600
  %88 = load i32, ptr %rb601, align 16, !dbg !501
  br i1 %87, label %91, label %89, !dbg !500

89:                                               ; preds = %84
  %90 = or i32 %88, 2, !dbg !502
  %rb602 = ptrtoint ptr addrspace(271) %9 to i32
  %rb603 = zext i32 %rb602 to i64
  %rb604 = getelementptr i8, ptr @_mh_execute_header, i64 %rb603
  %p32st.50 = getelementptr i8, ptr %rb604, i64 0
  store i32 %90, ptr %p32st.50, align 16, !dbg !502
  br label %91, !dbg !503

91:                                               ; preds = %89, %84
  %92 = phi i32 [ %90, %89 ], [ %88, %84 ], !dbg !501
  %93 = and i32 %92, 4096, !dbg !504
  %94 = icmp eq i32 %93, 0, !dbg !504
  br i1 %94, label %96, label %95, !dbg !504

95:                                               ; preds = %91
  tail call void @EftBlastObj_UpdateModel(ptr noundef nonnull %0) #9, !dbg !505
  br label %96, !dbg !506

96:                                               ; preds = %95, %91
  %rb605 = ptrtoint ptr addrspace(271) %4 to i32
  %rb606 = zext i32 %rb605 to i64
  %rb607 = getelementptr i8, ptr @_mh_execute_header, i64 %rb606
  %97 = load i32, ptr %rb607, align 4, !dbg !507
  %98 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 48, !dbg !508
  %rb608 = ptrtoint ptr addrspace(271) %98 to i32
  %rb609 = zext i32 %rb608 to i64
  %rb610 = getelementptr i8, ptr @_mh_execute_header, i64 %rb609
  %99 = load ptr addrspace(271), ptr %rb610, align 16, !dbg !508
  %rb611 = ptrtoint ptr addrspace(271) %99 to i32
  %rb612 = zext i32 %rb611 to i64
  %rb613 = getelementptr i8, ptr @_mh_execute_header, i64 %rb612
  %rb614 = icmp eq i32 %rb611, 0
  %rb615 = select i1 %rb614, ptr null, ptr %rb613
  %100 = getelementptr i8, ptr %rb615, i64 0, !dbg !509
  tail call void @EftBlastObj_UpdateParts(i32 noundef %97, ptr noundef nonnull %0, ptr noundef %100, i32 noundef 0) #9, !dbg !510
  %rb616 = ptrtoint ptr addrspace(271) %9 to i32
  %rb617 = zext i32 %rb616 to i64
  %rb618 = getelementptr i8, ptr @_mh_execute_header, i64 %rb617
  %101 = load i32, ptr %rb618, align 16, !dbg !511
  %102 = and i32 %101, 4, !dbg !512
  %103 = icmp eq i32 %102, 0, !dbg !512
  br i1 %103, label %105, label %104, !dbg !512

104:                                              ; preds = %96
  tail call void @BtlTask_SetDead(ptr noundef nonnull %0) #7, !dbg !513
  br label %118, !dbg !514

105:                                              ; preds = %96
  %106 = and i32 %101, 2, !dbg !515
  %107 = icmp eq i32 %106, 0, !dbg !515
  br i1 %107, label %110, label %108, !dbg !515

108:                                              ; preds = %105
  %109 = or disjoint i32 %101, 4, !dbg !516
  %rb619 = ptrtoint ptr addrspace(271) %9 to i32
  %rb620 = zext i32 %rb619 to i64
  %rb621 = getelementptr i8, ptr @_mh_execute_header, i64 %rb620
  %p32st.51 = getelementptr i8, ptr %rb621, i64 0
  store i32 %109, ptr %p32st.51, align 16, !dbg !516
  br label %118, !dbg !517

110:                                              ; preds = %105
  %111 = and i32 %101, 128, !dbg !518
  %112 = icmp eq i32 %111, 0, !dbg !518
  br i1 %112, label %113, label %118, !dbg !519

113:                                              ; preds = %110
  %rb622 = ptrtoint ptr addrspace(271) %98 to i32
  %rb623 = zext i32 %rb622 to i64
  %rb624 = getelementptr i8, ptr @_mh_execute_header, i64 %rb623
  %114 = load ptr addrspace(271), ptr %rb624, align 16, !dbg !520
  %rb625 = ptrtoint ptr addrspace(271) %114 to i32
  %rb626 = zext i32 %rb625 to i64
  %rb627 = getelementptr i8, ptr @_mh_execute_header, i64 %rb626
  %rb628 = icmp eq i32 %rb625, 0
  %rb629 = select i1 %rb628, ptr null, ptr %rb627
  %115 = getelementptr i8, ptr %rb629, i64 0, !dbg !521
  %116 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 656, !dbg !522
  %rb630 = ptrtoint ptr addrspace(271) %116 to i32
  %rb631 = zext i32 %rb630 to i64
  %rb632 = getelementptr i8, ptr @_mh_execute_header, i64 %rb631
  %rb633 = icmp eq i32 %rb630, 0
  %rb634 = select i1 %rb633, ptr null, ptr %rb632
  %117 = getelementptr i8, ptr %rb634, i64 0, !dbg !523
  tail call void @EftEmit_UpdateTrailWidth(ptr noundef %115, ptr noundef %117) #7, !dbg !524
  tail call void @EftBlastObj_AddHit(ptr noundef nonnull %0) #9, !dbg !525
  br label %118, !dbg !526

118:                                              ; preds = %104, %110, %113, %108, %1
  ret void, !dbg !527
}

declare !dbg !528 i32 @BtlScene_IsCharStopped(i32 noundef) local_unnamed_addr #2

declare !dbg !529 i32 @EftShot_TestBits(i32 noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !530 void @EftEmit_UpdateNodesReq(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !531 void @EftAim_Home(ptr noundef, ptr noundef, ptr noundef, i32 noundef, float noundef, float noundef) local_unnamed_addr #2

declare !dbg !532 void @BtlTask_SetDead(ptr noundef) local_unnamed_addr #2

declare !dbg !533 void @EftEmit_UpdateTrailWidth(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_PostUpdate(ptr noundef %0) local_unnamed_addr #0 !dbg !534 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !535
  %3 = load ptr addrspace(271), ptr %2, align 4, !dbg !535
  %rb635 = ptrtoint ptr addrspace(271) %3 to i32
  %rb636 = zext i32 %rb635 to i64
  %rb637 = getelementptr i8, ptr @_mh_execute_header, i64 %rb636
  %4 = load ptr addrspace(271), ptr %rb637, align 16, !dbg !536
  %rb638 = ptrtoint ptr addrspace(271) %4 to i32
  %rb639 = zext i32 %rb638 to i64
  %rb640 = getelementptr i8, ptr @_mh_execute_header, i64 %rb639
  %5 = load i32, ptr %rb640, align 4, !dbg !537
  %6 = tail call i32 @BtlScene_IsCharStopped(i32 noundef %5) #7, !dbg !538
  %7 = icmp eq i32 %6, 0, !dbg !538
  br i1 %7, label %8, label %37, !dbg !538

8:                                                ; preds = %1
  %9 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 48, !dbg !539
  %rb641 = ptrtoint ptr addrspace(271) %9 to i32
  %rb642 = zext i32 %rb641 to i64
  %rb643 = getelementptr i8, ptr @_mh_execute_header, i64 %rb642
  %10 = load ptr addrspace(271), ptr %rb643, align 16, !dbg !539
  %rb644 = ptrtoint ptr addrspace(271) %10 to i32
  %rb645 = zext i32 %rb644 to i64
  %rb646 = getelementptr i8, ptr @_mh_execute_header, i64 %rb645
  %rb647 = icmp eq i32 %rb644, 0
  %rb648 = select i1 %rb647, ptr null, ptr %rb646
  %11 = getelementptr i8, ptr %rb648, i64 0, !dbg !540
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 656, !dbg !541
  %rb649 = ptrtoint ptr addrspace(271) %12 to i32
  %rb650 = zext i32 %rb649 to i64
  %rb651 = getelementptr i8, ptr @_mh_execute_header, i64 %rb650
  %rb652 = icmp eq i32 %rb649, 0
  %rb653 = select i1 %rb652, ptr null, ptr %rb651
  %13 = getelementptr i8, ptr %rb653, i64 0, !dbg !542
  %14 = tail call i32 @EftEmit_UpdateAlive(ptr noundef %11, ptr noundef %13) #7, !dbg !543
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8, !dbg !544
  %16 = load i16, ptr %15, align 4, !dbg !544
  %17 = and i16 %16, 1, !dbg !545
  %18 = icmp eq i16 %17, 0, !dbg !546
  br i1 %18, label %29, label %19, !dbg !546

19:                                               ; preds = %8
  %20 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1456, !dbg !547
  %rb654 = ptrtoint ptr addrspace(271) %20 to i32
  %rb655 = zext i32 %rb654 to i64
  %rb656 = getelementptr i8, ptr @_mh_execute_header, i64 %rb655
  %rb657 = icmp eq i32 %rb654, 0
  %rb658 = select i1 %rb657, ptr null, ptr %rb656
  %21 = getelementptr i8, ptr %rb658, i64 0, !dbg !548
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 16, !dbg !549
  tail call void @Vec3_Copy(ptr noundef %21, ptr noundef nonnull %22) #7, !dbg !550
  %23 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1408, !dbg !551
  %rb659 = ptrtoint ptr addrspace(271) %23 to i32
  %rb660 = zext i32 %rb659 to i64
  %rb661 = getelementptr i8, ptr @_mh_execute_header, i64 %rb660
  %24 = load i32, ptr %rb661, align 16, !dbg !551
  %25 = and i32 %24, 32, !dbg !552
  %26 = icmp eq i32 %25, 0, !dbg !552
  br i1 %26, label %27, label %29, !dbg !553

27:                                               ; preds = %19
  %28 = or disjoint i32 %24, 32, !dbg !554
  %rb662 = ptrtoint ptr addrspace(271) %23 to i32
  %rb663 = zext i32 %rb662 to i64
  %rb664 = getelementptr i8, ptr @_mh_execute_header, i64 %rb663
  %p32st.52 = getelementptr i8, ptr %rb664, i64 0
  store i32 %28, ptr %p32st.52, align 16, !dbg !554
  br label %29, !dbg !555

29:                                               ; preds = %19, %27, %8
  %30 = load i16, ptr %15, align 4, !dbg !556
  %31 = and i16 %30, 4, !dbg !557
  %32 = icmp eq i16 %31, 0, !dbg !557
  br i1 %32, label %37, label %33, !dbg !557

33:                                               ; preds = %29
  %34 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1408, !dbg !558
  %rb665 = ptrtoint ptr addrspace(271) %34 to i32
  %rb666 = zext i32 %rb665 to i64
  %rb667 = getelementptr i8, ptr @_mh_execute_header, i64 %rb666
  %35 = load i32, ptr %rb667, align 16, !dbg !559
  %36 = or i32 %35, 2, !dbg !559
  %rb668 = ptrtoint ptr addrspace(271) %34 to i32
  %rb669 = zext i32 %rb668 to i64
  %rb670 = getelementptr i8, ptr @_mh_execute_header, i64 %rb669
  %p32st.53 = getelementptr i8, ptr %rb670, i64 0
  store i32 %36, ptr %p32st.53, align 16, !dbg !559
  br label %37, !dbg !560

37:                                               ; preds = %29, %33, %1
  ret void, !dbg !561
}

declare !dbg !562 i32 @EftEmit_UpdateAlive(ptr noundef, ptr noundef) local_unnamed_addr #2

declare !dbg !563 void @Vec3_Copy(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObj_Reset(ptr noundef %0) local_unnamed_addr #0 !dbg !564 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !565
  %3 = load ptr addrspace(271), ptr %2, align 4, !dbg !565
  %4 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 1408, !dbg !566
  %rb671 = ptrtoint ptr addrspace(271) %4 to i32
  %rb672 = zext i32 %rb671 to i64
  %rb673 = getelementptr i8, ptr @_mh_execute_header, i64 %rb672
  %5 = load i32, ptr %rb673, align 16, !dbg !566
  %6 = and i32 %5, 16, !dbg !567
  %7 = icmp eq i32 %6, 0, !dbg !567
  br i1 %7, label %8, label %15, !dbg !568

8:                                                ; preds = %1
  %9 = or disjoint i32 %5, 16, !dbg !569
  %rb674 = ptrtoint ptr addrspace(271) %4 to i32
  %rb675 = zext i32 %rb674 to i64
  %rb676 = getelementptr i8, ptr @_mh_execute_header, i64 %rb675
  %p32st.54 = getelementptr i8, ptr %rb676, i64 0
  store i32 %9, ptr %p32st.54, align 16, !dbg !569
  %10 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 48, !dbg !570
  %rb677 = ptrtoint ptr addrspace(271) %10 to i32
  %rb678 = zext i32 %rb677 to i64
  %rb679 = getelementptr i8, ptr @_mh_execute_header, i64 %rb678
  %11 = load ptr addrspace(271), ptr %rb679, align 16, !dbg !570
  %rb680 = ptrtoint ptr addrspace(271) %11 to i32
  %rb681 = zext i32 %rb680 to i64
  %rb682 = getelementptr i8, ptr @_mh_execute_header, i64 %rb681
  %rb683 = icmp eq i32 %rb680, 0
  %rb684 = select i1 %rb683, ptr null, ptr %rb682
  %12 = getelementptr i8, ptr %rb684, i64 0, !dbg !571
  %13 = getelementptr inbounds nuw i8, ptr addrspace(271) %3, i32 656, !dbg !572
  %rb685 = ptrtoint ptr addrspace(271) %13 to i32
  %rb686 = zext i32 %rb685 to i64
  %rb687 = getelementptr i8, ptr @_mh_execute_header, i64 %rb686
  %rb688 = icmp eq i32 %rb685, 0
  %rb689 = select i1 %rb688, ptr null, ptr %rb687
  %14 = getelementptr i8, ptr %rb689, i64 0, !dbg !573
  tail call void @EftEmit_KillAll(ptr noundef %12, ptr noundef %14) #7, !dbg !574
  br label %15, !dbg !575

15:                                               ; preds = %8, %1
  tail call void @BtlTask_SetDead(ptr noundef nonnull %0) #7, !dbg !576
  ret void, !dbg !577
}

declare !dbg !578 void @EftEmit_KillAll(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable(sync)
define void @EftBlastObj_Draw(ptr noundef readnone captures(none) %0) local_unnamed_addr #4 !dbg !579 {
  ret void, !dbg !580
}

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObjMgr_Init(ptr noundef %0) local_unnamed_addr #0 !dbg !581 {
  %2 = tail call ptr @BtlPool_GetCurrent() #7, !dbg !582
  %3 = tail call ptr @BtlPool_Alloc(ptr noundef %2, i32 noundef 4) #7, !dbg !583
  %rb690 = ptrtoint ptr %3 to i64
  %rb691 = ptrtoint ptr @_mh_execute_header to i64
  %rb692 = sub i64 %rb690, %rb691
  %rb693 = trunc i64 %rb692 to i32
  %rb694 = icmp eq ptr %3, null
  %rb695 = select i1 %rb694, i32 0, i32 %rb693
  %4 = inttoptr i32 %rb695 to ptr addrspace(271), !dbg !584
  store ptr addrspace(271) %4, ptr @gEftBlastObjMgr, align 4, !dbg !585
  %rb696 = ptrtoint ptr addrspace(271) %4 to i32
  %rb697 = zext i32 %rb696 to i64
  %rb698 = getelementptr i8, ptr @_mh_execute_header, i64 %rb697
  %p32st.55 = getelementptr i8, ptr %rb698, i64 0
  store i32 0, ptr %p32st.55, align 4, !dbg !586
  %5 = tail call ptr @BtlTask_CreateChildList(ptr noundef %0, i32 noundef 60, i32 noundef 1568) #7, !dbg !587
  %rb699 = ptrtoint ptr %5 to i64
  %rb700 = ptrtoint ptr @_mh_execute_header to i64
  %rb701 = sub i64 %rb699, %rb700
  %rb702 = trunc i64 %rb701 to i32
  %rb703 = icmp eq ptr %5, null
  %rb704 = select i1 %rb703, i32 0, i32 %rb702
  %6 = inttoptr i32 %rb704 to ptr addrspace(271), !dbg !587
  store ptr addrspace(271) %6, ptr @gEftBlastObjList, align 4, !dbg !588
  ret void, !dbg !589
}

declare !dbg !590 ptr @BtlPool_GetCurrent() local_unnamed_addr #2

declare !dbg !591 ptr @BtlPool_Alloc(ptr noundef, i32 noundef) local_unnamed_addr #2

declare !dbg !592 ptr @BtlTask_CreateChildList(ptr noundef, i32 noundef, i32 noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define void @EftBlastObjMgr_Term() local_unnamed_addr #0 !dbg !593 {
  %1 = load ptr addrspace(271), ptr @gEftBlastObjMgr, align 4, !dbg !594
  %2 = tail call ptr @BtlPool_GetCurrent() #7, !dbg !595
  %rb705 = ptrtoint ptr addrspace(271) %1 to i32
  %rb706 = zext i32 %rb705 to i64
  %rb707 = getelementptr i8, ptr @_mh_execute_header, i64 %rb706
  %rb708 = icmp eq i32 %rb705, 0
  %rb709 = select i1 %rb708, ptr null, ptr %rb707
  %3 = getelementptr i8, ptr %rb709, i64 0, !dbg !596
  tail call void @BtlPool_Free(ptr noundef %2, ptr noundef %3) #7, !dbg !597
  store ptr addrspace(271) null, ptr @gEftBlastObjMgr, align 4, !dbg !598
  ret void, !dbg !599
}

declare !dbg !600 void @BtlPool_Free(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable(sync)
define void @EftBlastObjMgr_Update() local_unnamed_addr #4 !dbg !601 {
  ret void, !dbg !602
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable(sync)
define void @EftBlastObjMgr_Reset() local_unnamed_addr #4 !dbg !603 {
  ret void, !dbg !604
}

; Function Attrs: nounwind uwtable(sync)
define ptr @EftBlastObj_Create(ptr noundef %0) local_unnamed_addr #0 !dbg !605 {
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(52) @EftBlastObj_Create.a, ptr noundef nonnull align 4 dereferenceable(52) %0, i64 48, i1 false), !dbg !606
  store ptr addrspace(271) null, ptr getelementptr inbounds nuw (i8, ptr @EftBlastObj_Create.a, i64 48), align 4, !dbg !607
  %2 = load i32, ptr @EftBlastObj_Create.n, align 4, !dbg !608
  %3 = icmp slt i32 %2, 6, !dbg !609
  br i1 %3, label %4, label %17, !dbg !609

4:                                                ; preds = %1
  %5 = add nuw nsw i32 %2, 1, !dbg !610
  store i32 %5, ptr @EftBlastObj_Create.n, align 4, !dbg !610
  %6 = load ptr, ptr @__stderrp, align 8, !dbg !611
  %7 = ptrtoint ptr %0 to i64, !dbg !612
  %8 = trunc i64 %7 to i32, !dbg !612
  %9 = load ptr addrspace(271), ptr getelementptr inbounds nuw (i8, ptr @EftBlastObj_Create.a, i64 8), align 4, !dbg !613
  %rb710 = ptrtoint ptr addrspace(271) %9 to i32
  %rb711 = zext i32 %rb710 to i64
  %rb712 = getelementptr i8, ptr @_mh_execute_header, i64 %rb711
  %rb713 = icmp eq i32 %rb710, 0
  %rb714 = select i1 %rb713, ptr null, ptr %rb712
  %10 = getelementptr i8, ptr %rb714, i64 0, !dbg !614
  %11 = ptrtoint ptr addrspace(271) %9 to i32, !dbg !615
  %12 = load ptr addrspace(271), ptr @EftBlastObj_Create.a, align 4, !dbg !616
  %rb715 = ptrtoint ptr addrspace(271) %12 to i32
  %rb716 = zext i32 %rb715 to i64
  %rb717 = getelementptr i8, ptr @_mh_execute_header, i64 %rb716
  %rb718 = icmp eq i32 %rb715, 0
  %rb719 = select i1 %rb718, ptr null, ptr %rb717
  %13 = getelementptr i8, ptr %rb719, i64 0, !dbg !617
  %14 = load ptr addrspace(271), ptr getelementptr inbounds nuw (i8, ptr @EftBlastObj_Create.a, i64 4), align 4, !dbg !618
  %rb720 = ptrtoint ptr addrspace(271) %14 to i32
  %rb721 = zext i32 %rb720 to i64
  %rb722 = getelementptr i8, ptr @_mh_execute_header, i64 %rb721
  %rb723 = icmp eq i32 %rb720, 0
  %rb724 = select i1 %rb723, ptr null, ptr %rb722
  %15 = getelementptr i8, ptr %rb724, i64 0, !dbg !619
  %16 = tail call i32 (ptr, ptr, ...) @fprintf(ptr noundef %6, ptr noundef nonnull @.str.1, ptr noundef nonnull %0, i32 noundef %8, ptr noundef nonnull @EftBlastObj_Create.a, i32 noundef ptrtoint (ptr @EftBlastObj_Create.a to i32), ptr noundef %10, i32 noundef %11, ptr noundef %13, ptr noundef %15) #7, !dbg !620
  br label %17, !dbg !621

17:                                               ; preds = %4, %1
  %18 = load ptr addrspace(271), ptr @gEftBlastObjList, align 4, !dbg !622
  %rb725 = ptrtoint ptr addrspace(271) %18 to i32
  %rb726 = zext i32 %rb725 to i64
  %rb727 = getelementptr i8, ptr @_mh_execute_header, i64 %rb726
  %rb728 = icmp eq i32 %rb725, 0
  %rb729 = select i1 %rb728, ptr null, ptr %rb727
  %19 = getelementptr i8, ptr %rb729, i64 0, !dbg !622
  %20 = tail call ptr @BtlTaskList_AddTail(ptr noundef %19, ptr noundef nonnull @gEftBlastObjClass, ptr noundef nonnull @EftBlastObj_Create.a) #7, !dbg !623
  ret ptr %20, !dbg !624
}

declare !dbg !625 ptr @BtlTaskList_AddTail(ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: nounwind uwtable(sync)
define ptr @EftBlastObj_CreateWithModel(ptr noundef readonly captures(none) %0, ptr noundef %1) local_unnamed_addr #0 !dbg !626 {
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(52) @EftBlastObj_CreateWithModel.a, ptr noundef nonnull align 4 dereferenceable(52) %0, i64 48, i1 false), !dbg !627
  %rb730 = ptrtoint ptr %1 to i64
  %rb731 = ptrtoint ptr @_mh_execute_header to i64
  %rb732 = sub i64 %rb730, %rb731
  %rb733 = trunc i64 %rb732 to i32
  %rb734 = icmp eq ptr %1, null
  %rb735 = select i1 %rb734, i32 0, i32 %rb733
  %3 = inttoptr i32 %rb735 to ptr addrspace(271), !dbg !628
  store ptr addrspace(271) %3, ptr getelementptr inbounds nuw (i8, ptr @EftBlastObj_CreateWithModel.a, i64 48), align 4, !dbg !629
  %4 = load ptr addrspace(271), ptr @gEftBlastObjList, align 4, !dbg !630
  %rb736 = ptrtoint ptr addrspace(271) %4 to i32
  %rb737 = zext i32 %rb736 to i64
  %rb738 = getelementptr i8, ptr @_mh_execute_header, i64 %rb737
  %rb739 = icmp eq i32 %rb736, 0
  %rb740 = select i1 %rb739, ptr null, ptr %rb738
  %5 = getelementptr i8, ptr %rb740, i64 0, !dbg !630
  %6 = tail call ptr @BtlTaskList_AddTail(ptr noundef %5, ptr noundef nonnull @gEftBlastObjClass, ptr noundef nonnull @EftBlastObj_CreateWithModel.a) #7, !dbg !631
  ret ptr %6, !dbg !632
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_Stop(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #5 !dbg !633 {
  %2 = icmp eq ptr %0, null, !dbg !634
  br i1 %2, label %17, label %3, !dbg !634

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !635
  %5 = load ptr addrspace(271), ptr %4, align 4, !dbg !635
  %rb741 = ptrtoint ptr addrspace(271) %5 to i32
  %rb742 = zext i32 %rb741 to i64
  %rb743 = getelementptr i8, ptr @_mh_execute_header, i64 %rb742
  %6 = load ptr addrspace(271), ptr %rb743, align 4, !dbg !636
  %7 = icmp eq ptr addrspace(271) %6, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !637
  br i1 %7, label %8, label %17, !dbg !637

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !638
  %10 = load ptr addrspace(271), ptr %9, align 4, !dbg !638
  %11 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 1408, !dbg !639
  %rb744 = ptrtoint ptr addrspace(271) %11 to i32
  %rb745 = zext i32 %rb744 to i64
  %rb746 = getelementptr i8, ptr @_mh_execute_header, i64 %rb745
  %12 = load i32, ptr %rb746, align 16, !dbg !639
  %13 = and i32 %12, 1, !dbg !640
  %14 = icmp eq i32 %13, 0, !dbg !640
  br i1 %14, label %17, label %15, !dbg !641

15:                                               ; preds = %8
  %16 = or i32 %12, 2, !dbg !642
  %rb747 = ptrtoint ptr addrspace(271) %11 to i32
  %rb748 = zext i32 %rb747 to i64
  %rb749 = getelementptr i8, ptr @_mh_execute_header, i64 %rb748
  %p32st.56 = getelementptr i8, ptr %rb749, i64 0
  store i32 %16, ptr %p32st.56, align 16, !dbg !642
  br label %17, !dbg !643

17:                                               ; preds = %8, %3, %1, %15
  %18 = phi i32 [ 1, %15 ], [ 0, %1 ], [ 0, %3 ], [ 0, %8 ], !dbg !644
  ret i32 %18, !dbg !645
}

; Function Attrs: nounwind uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_Kill(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #0 !dbg !646 {
  %2 = icmp eq ptr %0, null, !dbg !647
  br i1 %2, label %26, label %3, !dbg !647

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !648
  %5 = load ptr addrspace(271), ptr %4, align 4, !dbg !648
  %rb750 = ptrtoint ptr addrspace(271) %5 to i32
  %rb751 = zext i32 %rb750 to i64
  %rb752 = getelementptr i8, ptr @_mh_execute_header, i64 %rb751
  %6 = load ptr addrspace(271), ptr %rb752, align 4, !dbg !649
  %7 = icmp eq ptr addrspace(271) %6, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !650
  br i1 %7, label %8, label %26, !dbg !650

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !651
  %10 = load ptr addrspace(271), ptr %9, align 4, !dbg !651
  %11 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 1408, !dbg !652
  %rb753 = ptrtoint ptr addrspace(271) %11 to i32
  %rb754 = zext i32 %rb753 to i64
  %rb755 = getelementptr i8, ptr @_mh_execute_header, i64 %rb754
  %12 = load i32, ptr %rb755, align 16, !dbg !652
  %13 = and i32 %12, 1, !dbg !653
  %14 = icmp eq i32 %13, 0, !dbg !653
  br i1 %14, label %26, label %15, !dbg !654

15:                                               ; preds = %8
  %16 = or i32 %12, 4, !dbg !655
  %rb756 = ptrtoint ptr addrspace(271) %11 to i32
  %rb757 = zext i32 %rb756 to i64
  %rb758 = getelementptr i8, ptr @_mh_execute_header, i64 %rb757
  %p32st.57 = getelementptr i8, ptr %rb758, i64 0
  store i32 %16, ptr %p32st.57, align 16, !dbg !655
  %17 = and i32 %12, 16, !dbg !656
  %18 = icmp eq i32 %17, 0, !dbg !656
  br i1 %18, label %19, label %26, !dbg !657

19:                                               ; preds = %15
  %20 = or i32 %12, 20, !dbg !658
  %rb759 = ptrtoint ptr addrspace(271) %11 to i32
  %rb760 = zext i32 %rb759 to i64
  %rb761 = getelementptr i8, ptr @_mh_execute_header, i64 %rb760
  %p32st.58 = getelementptr i8, ptr %rb761, i64 0
  store i32 %20, ptr %p32st.58, align 16, !dbg !658
  %21 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 48, !dbg !659
  %rb762 = ptrtoint ptr addrspace(271) %21 to i32
  %rb763 = zext i32 %rb762 to i64
  %rb764 = getelementptr i8, ptr @_mh_execute_header, i64 %rb763
  %22 = load ptr addrspace(271), ptr %rb764, align 16, !dbg !659
  %rb765 = ptrtoint ptr addrspace(271) %22 to i32
  %rb766 = zext i32 %rb765 to i64
  %rb767 = getelementptr i8, ptr @_mh_execute_header, i64 %rb766
  %rb768 = icmp eq i32 %rb765, 0
  %rb769 = select i1 %rb768, ptr null, ptr %rb767
  %23 = getelementptr i8, ptr %rb769, i64 0, !dbg !660
  %24 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 656, !dbg !661
  %rb770 = ptrtoint ptr addrspace(271) %24 to i32
  %rb771 = zext i32 %rb770 to i64
  %rb772 = getelementptr i8, ptr @_mh_execute_header, i64 %rb771
  %rb773 = icmp eq i32 %rb770, 0
  %rb774 = select i1 %rb773, ptr null, ptr %rb772
  %25 = getelementptr i8, ptr %rb774, i64 0, !dbg !662
  tail call void @EftEmit_KillAll(ptr noundef %23, ptr noundef %25) #7, !dbg !663
  br label %26, !dbg !664

26:                                               ; preds = %15, %19, %8, %3, %1
  %27 = phi i32 [ 0, %1 ], [ 0, %3 ], [ 0, %8 ], [ 1, %19 ], [ 1, %15 ], !dbg !665
  ret i32 %27, !dbg !666
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_IsAlive(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #6 !dbg !667 {
  %2 = icmp eq ptr %0, null, !dbg !668
  br i1 %2, label %14, label %3, !dbg !668

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !669
  %5 = load ptr addrspace(271), ptr %4, align 4, !dbg !669
  %rb775 = ptrtoint ptr addrspace(271) %5 to i32
  %rb776 = zext i32 %rb775 to i64
  %rb777 = getelementptr i8, ptr @_mh_execute_header, i64 %rb776
  %6 = load ptr addrspace(271), ptr %rb777, align 4, !dbg !670
  %7 = icmp eq ptr addrspace(271) %6, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !671
  br i1 %7, label %8, label %14, !dbg !671

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !672
  %10 = load ptr addrspace(271), ptr %9, align 4, !dbg !672
  %11 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 1408, !dbg !673
  %rb778 = ptrtoint ptr addrspace(271) %11 to i32
  %rb779 = zext i32 %rb778 to i64
  %rb780 = getelementptr i8, ptr @_mh_execute_header, i64 %rb779
  %12 = load i32, ptr %rb780, align 16, !dbg !673
  %13 = and i32 %12, 1, !dbg !674
  br label %14, !dbg !675

14:                                               ; preds = %8, %3, %1
  %15 = phi i32 [ 0, %1 ], [ 0, %3 ], [ %13, %8 ], !dbg !675
  ret i32 %15, !dbg !676
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_IsDying(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #6 !dbg !677 {
  %2 = icmp eq ptr %0, null, !dbg !678
  br i1 %2, label %18, label %3, !dbg !678

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !679
  %5 = load ptr addrspace(271), ptr %4, align 4, !dbg !679
  %rb781 = ptrtoint ptr addrspace(271) %5 to i32
  %rb782 = zext i32 %rb781 to i64
  %rb783 = getelementptr i8, ptr @_mh_execute_header, i64 %rb782
  %6 = load ptr addrspace(271), ptr %rb783, align 4, !dbg !680
  %7 = icmp eq ptr addrspace(271) %6, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !681
  br i1 %7, label %8, label %18, !dbg !681

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !682
  %10 = load ptr addrspace(271), ptr %9, align 4, !dbg !682
  %11 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 1408, !dbg !683
  %rb784 = ptrtoint ptr addrspace(271) %11 to i32
  %rb785 = zext i32 %rb784 to i64
  %rb786 = getelementptr i8, ptr @_mh_execute_header, i64 %rb785
  %12 = load i32, ptr %rb786, align 16, !dbg !683
  %13 = and i32 %12, 1, !dbg !684
  %14 = icmp eq i32 %13, 0, !dbg !684
  br i1 %14, label %18, label %15, !dbg !685

15:                                               ; preds = %8
  %16 = lshr i32 %12, 2, !dbg !686
  %17 = and i32 %16, 1, !dbg !686
  br label %18, !dbg !686

18:                                               ; preds = %15, %8, %3, %1
  %19 = phi i32 [ 0, %1 ], [ 0, %3 ], [ 0, %8 ], [ %17, %15 ], !dbg !686
  ret i32 %19, !dbg !687
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetSel(ptr noundef readonly captures(address_is_null) %0, i32 noundef %1, i32 noundef %2, i32 noundef %3) local_unnamed_addr #5 !dbg !688 {
  %5 = icmp eq ptr %0, null, !dbg !689
  br i1 %5, label %27, label %6, !dbg !689

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !690
  %8 = load ptr addrspace(271), ptr %7, align 4, !dbg !690
  %rb787 = ptrtoint ptr addrspace(271) %8 to i32
  %rb788 = zext i32 %rb787 to i64
  %rb789 = getelementptr i8, ptr @_mh_execute_header, i64 %rb788
  %9 = load ptr addrspace(271), ptr %rb789, align 4, !dbg !691
  %10 = icmp eq ptr addrspace(271) %9, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !692
  br i1 %10, label %11, label %27, !dbg !692

11:                                               ; preds = %6
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !693
  %13 = load ptr addrspace(271), ptr %12, align 4, !dbg !693
  %14 = getelementptr inbounds nuw i8, ptr addrspace(271) %13, i32 1408, !dbg !694
  %rb790 = ptrtoint ptr addrspace(271) %14 to i32
  %rb791 = zext i32 %rb790 to i64
  %rb792 = getelementptr i8, ptr @_mh_execute_header, i64 %rb791
  %15 = load i32, ptr %rb792, align 16, !dbg !694
  %16 = and i32 %15, 1, !dbg !695
  %17 = icmp eq i32 %16, 0, !dbg !695
  br i1 %17, label %27, label %18, !dbg !696

18:                                               ; preds = %11
  %19 = getelementptr inbounds nuw i8, ptr addrspace(271) %13, i32 32, !dbg !697
  %20 = getelementptr inbounds [2 x %struct.EftBlastObjSel], ptr addrspace(271) %19, i32 0, i32 %1, !dbg !698
  %rb793 = ptrtoint ptr addrspace(271) %20 to i32
  %rb794 = zext i32 %rb793 to i64
  %rb795 = getelementptr i8, ptr @_mh_execute_header, i64 %rb794
  %p32st.59 = getelementptr i8, ptr %rb795, i64 0
  store i32 %2, ptr %p32st.59, align 8, !dbg !699
  %21 = getelementptr inbounds nuw i8, ptr addrspace(271) %20, i32 4, !dbg !700
  %rb796 = ptrtoint ptr addrspace(271) %21 to i32
  %rb797 = zext i32 %rb796 to i64
  %rb798 = getelementptr i8, ptr @_mh_execute_header, i64 %rb797
  %p32st.60 = getelementptr i8, ptr %rb798, i64 0
  store i32 %3, ptr %p32st.60, align 4, !dbg !701
  %22 = getelementptr inbounds nuw i8, ptr addrspace(271) %13, i32 1412, !dbg !702
  %rb799 = ptrtoint ptr addrspace(271) %22 to i32
  %rb800 = zext i32 %rb799 to i64
  %rb801 = getelementptr i8, ptr @_mh_execute_header, i64 %rb800
  %23 = load i32, ptr %rb801, align 4, !dbg !702
  %24 = icmp slt i32 %1, %23, !dbg !703
  br i1 %24, label %27, label %25, !dbg !704

25:                                               ; preds = %18
  %26 = add nsw i32 %23, 1, !dbg !705
  %rb802 = ptrtoint ptr addrspace(271) %22 to i32
  %rb803 = zext i32 %rb802 to i64
  %rb804 = getelementptr i8, ptr @_mh_execute_header, i64 %rb803
  %p32st.61 = getelementptr i8, ptr %rb804, i64 0
  store i32 %26, ptr %p32st.61, align 4, !dbg !705
  br label %27, !dbg !706

27:                                               ; preds = %18, %25, %11, %6, %4
  %28 = phi i32 [ 0, %4 ], [ 0, %6 ], [ 0, %11 ], [ 1, %25 ], [ 1, %18 ], !dbg !707
  ret i32 %28, !dbg !708
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable(sync)
define ptr @EftBlastObj_GetPose(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #6 !dbg !709 {
  %2 = icmp eq ptr %0, null, !dbg !710
  br i1 %2, label %18, label %3, !dbg !710

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !711
  %5 = load ptr addrspace(271), ptr %4, align 4, !dbg !711
  %rb805 = ptrtoint ptr addrspace(271) %5 to i32
  %rb806 = zext i32 %rb805 to i64
  %rb807 = getelementptr i8, ptr @_mh_execute_header, i64 %rb806
  %6 = load ptr addrspace(271), ptr %rb807, align 4, !dbg !712
  %7 = icmp eq ptr addrspace(271) %6, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !713
  br i1 %7, label %8, label %18, !dbg !713

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !714
  %10 = load ptr addrspace(271), ptr %9, align 4, !dbg !714
  %11 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 1408, !dbg !715
  %rb808 = ptrtoint ptr addrspace(271) %11 to i32
  %rb809 = zext i32 %rb808 to i64
  %rb810 = getelementptr i8, ptr @_mh_execute_header, i64 %rb809
  %12 = load i32, ptr %rb810, align 16, !dbg !715
  %13 = and i32 %12, 1, !dbg !716
  %14 = icmp eq i32 %13, 0, !dbg !716
  br i1 %14, label %18, label %15, !dbg !717

15:                                               ; preds = %8
  %16 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 1440, !dbg !718
  %rb811 = ptrtoint ptr addrspace(271) %16 to i32
  %rb812 = zext i32 %rb811 to i64
  %rb813 = getelementptr i8, ptr @_mh_execute_header, i64 %rb812
  %rb814 = icmp eq i32 %rb811, 0
  %rb815 = select i1 %rb814, ptr null, ptr %rb813
  %17 = getelementptr i8, ptr %rb815, i64 0, !dbg !719
  br label %18, !dbg !720

18:                                               ; preds = %8, %3, %1, %15
  %19 = phi ptr [ %17, %15 ], [ null, %1 ], [ null, %3 ], [ null, %8 ], !dbg !721
  ret ptr %19, !dbg !722
}

; Function Attrs: nounwind uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetTarget(ptr noundef readonly captures(address_is_null) %0, i32 noundef %1, ptr noundef %2) local_unnamed_addr #0 !dbg !723 {
  %4 = icmp eq ptr %0, null, !dbg !724
  br i1 %4, label %25, label %5, !dbg !724

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !725
  %7 = load ptr addrspace(271), ptr %6, align 4, !dbg !725
  %rb816 = ptrtoint ptr addrspace(271) %7 to i32
  %rb817 = zext i32 %rb816 to i64
  %rb818 = getelementptr i8, ptr @_mh_execute_header, i64 %rb817
  %8 = load ptr addrspace(271), ptr %rb818, align 4, !dbg !726
  %9 = icmp eq ptr addrspace(271) %8, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !727
  br i1 %9, label %10, label %25, !dbg !727

10:                                               ; preds = %5
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !728
  %12 = load ptr addrspace(271), ptr %11, align 4, !dbg !728
  %13 = getelementptr inbounds nuw i8, ptr addrspace(271) %12, i32 1408, !dbg !729
  %rb819 = ptrtoint ptr addrspace(271) %13 to i32
  %rb820 = zext i32 %rb819 to i64
  %rb821 = getelementptr i8, ptr @_mh_execute_header, i64 %rb820
  %14 = load i32, ptr %rb821, align 16, !dbg !729
  %15 = and i32 %14, 1, !dbg !730
  %16 = icmp eq i32 %15, 0, !dbg !730
  br i1 %16, label %25, label %17, !dbg !731

17:                                               ; preds = %10
  %18 = icmp eq i32 %1, 0, !dbg !732
  br i1 %18, label %23, label %19, !dbg !732

19:                                               ; preds = %17
  %20 = or i32 %14, 512, !dbg !733
  %rb822 = ptrtoint ptr addrspace(271) %13 to i32
  %rb823 = zext i32 %rb822 to i64
  %rb824 = getelementptr i8, ptr @_mh_execute_header, i64 %rb823
  %p32st.62 = getelementptr i8, ptr %rb824, i64 0
  store i32 %20, ptr %p32st.62, align 16, !dbg !733
  %21 = getelementptr inbounds nuw i8, ptr addrspace(271) %12, i32 1392, !dbg !734
  %rb825 = ptrtoint ptr addrspace(271) %21 to i32
  %rb826 = zext i32 %rb825 to i64
  %rb827 = getelementptr i8, ptr @_mh_execute_header, i64 %rb826
  %rb828 = icmp eq i32 %rb825, 0
  %rb829 = select i1 %rb828, ptr null, ptr %rb827
  %22 = getelementptr i8, ptr %rb829, i64 0, !dbg !735
  tail call void @Vec4_Copy(ptr noundef %22, ptr noundef %2) #7, !dbg !736
  br label %25, !dbg !737

23:                                               ; preds = %17
  %24 = and i32 %14, -513, !dbg !738
  %rb830 = ptrtoint ptr addrspace(271) %13 to i32
  %rb831 = zext i32 %rb830 to i64
  %rb832 = getelementptr i8, ptr @_mh_execute_header, i64 %rb831
  %p32st.63 = getelementptr i8, ptr %rb832, i64 0
  store i32 %24, ptr %p32st.63, align 16, !dbg !738
  br label %25

25:                                               ; preds = %19, %23, %10, %5, %3
  %26 = phi i32 [ 0, %3 ], [ 0, %5 ], [ 0, %10 ], [ 1, %23 ], [ 1, %19 ], !dbg !739
  ret i32 %26, !dbg !740
}

; Function Attrs: nounwind uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetPrevPos(ptr noundef readonly captures(address_is_null) %0, ptr noundef %1) local_unnamed_addr #0 !dbg !741 {
  %3 = icmp eq ptr %0, null, !dbg !742
  br i1 %3, label %19, label %4, !dbg !742

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !743
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !743
  %rb833 = ptrtoint ptr addrspace(271) %6 to i32
  %rb834 = zext i32 %rb833 to i64
  %rb835 = getelementptr i8, ptr @_mh_execute_header, i64 %rb834
  %7 = load ptr addrspace(271), ptr %rb835, align 4, !dbg !744
  %8 = icmp eq ptr addrspace(271) %7, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !745
  br i1 %8, label %9, label %19, !dbg !745

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !746
  %11 = load ptr addrspace(271), ptr %10, align 4, !dbg !746
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1408, !dbg !747
  %rb836 = ptrtoint ptr addrspace(271) %12 to i32
  %rb837 = zext i32 %rb836 to i64
  %rb838 = getelementptr i8, ptr @_mh_execute_header, i64 %rb837
  %13 = load i32, ptr %rb838, align 16, !dbg !747
  %14 = and i32 %13, 1, !dbg !748
  %15 = icmp eq i32 %14, 0, !dbg !748
  br i1 %15, label %19, label %16, !dbg !749

16:                                               ; preds = %9
  %17 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1472, !dbg !750
  %rb839 = ptrtoint ptr addrspace(271) %17 to i32
  %rb840 = zext i32 %rb839 to i64
  %rb841 = getelementptr i8, ptr @_mh_execute_header, i64 %rb840
  %rb842 = icmp eq i32 %rb839, 0
  %rb843 = select i1 %rb842, ptr null, ptr %rb841
  %18 = getelementptr i8, ptr %rb843, i64 0, !dbg !751
  tail call void @Vec4_Copy(ptr noundef %18, ptr noundef %1) #7, !dbg !752
  br label %19, !dbg !753

19:                                               ; preds = %9, %4, %2, %16
  %20 = phi i32 [ 1, %16 ], [ 0, %2 ], [ 0, %4 ], [ 0, %9 ], !dbg !754
  ret i32 %20, !dbg !755
}

; Function Attrs: nounwind uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetDir(ptr noundef readonly captures(address_is_null) %0, ptr noundef %1) local_unnamed_addr #0 !dbg !756 {
  %3 = icmp eq ptr %0, null, !dbg !757
  br i1 %3, label %19, label %4, !dbg !757

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !758
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !758
  %rb844 = ptrtoint ptr addrspace(271) %6 to i32
  %rb845 = zext i32 %rb844 to i64
  %rb846 = getelementptr i8, ptr @_mh_execute_header, i64 %rb845
  %7 = load ptr addrspace(271), ptr %rb846, align 4, !dbg !759
  %8 = icmp eq ptr addrspace(271) %7, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !760
  br i1 %8, label %9, label %19, !dbg !760

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !761
  %11 = load ptr addrspace(271), ptr %10, align 4, !dbg !761
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1408, !dbg !762
  %rb847 = ptrtoint ptr addrspace(271) %12 to i32
  %rb848 = zext i32 %rb847 to i64
  %rb849 = getelementptr i8, ptr @_mh_execute_header, i64 %rb848
  %13 = load i32, ptr %rb849, align 16, !dbg !762
  %14 = and i32 %13, 1, !dbg !763
  %15 = icmp eq i32 %14, 0, !dbg !763
  br i1 %15, label %19, label %16, !dbg !764

16:                                               ; preds = %9
  %17 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1376, !dbg !765
  %rb850 = ptrtoint ptr addrspace(271) %17 to i32
  %rb851 = zext i32 %rb850 to i64
  %rb852 = getelementptr i8, ptr @_mh_execute_header, i64 %rb851
  %rb853 = icmp eq i32 %rb850, 0
  %rb854 = select i1 %rb853, ptr null, ptr %rb852
  %18 = getelementptr i8, ptr %rb854, i64 0, !dbg !766
  tail call void @Vec4_Copy(ptr noundef %18, ptr noundef %1) #7, !dbg !767
  br label %19, !dbg !768

19:                                               ; preds = %9, %4, %2, %16
  %20 = phi i32 [ 1, %16 ], [ 0, %2 ], [ 0, %4 ], [ 0, %9 ], !dbg !769
  ret i32 %20, !dbg !770
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetFrozen(ptr noundef readonly captures(address_is_null) %0, i32 noundef %1) local_unnamed_addr #5 !dbg !771 {
  %3 = icmp eq ptr %0, null, !dbg !772
  br i1 %3, label %21, label %4, !dbg !772

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !773
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !773
  %rb855 = ptrtoint ptr addrspace(271) %6 to i32
  %rb856 = zext i32 %rb855 to i64
  %rb857 = getelementptr i8, ptr @_mh_execute_header, i64 %rb856
  %7 = load ptr addrspace(271), ptr %rb857, align 4, !dbg !774
  %8 = icmp eq ptr addrspace(271) %7, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !775
  br i1 %8, label %9, label %21, !dbg !775

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !776
  %11 = load ptr addrspace(271), ptr %10, align 4, !dbg !776
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1408, !dbg !777
  %rb858 = ptrtoint ptr addrspace(271) %12 to i32
  %rb859 = zext i32 %rb858 to i64
  %rb860 = getelementptr i8, ptr @_mh_execute_header, i64 %rb859
  %13 = load i32, ptr %rb860, align 16, !dbg !777
  %14 = and i32 %13, 1, !dbg !778
  %15 = icmp eq i32 %14, 0, !dbg !778
  br i1 %15, label %21, label %16, !dbg !779

16:                                               ; preds = %9
  %17 = icmp eq i32 %1, 0, !dbg !780
  %18 = and i32 %13, -65, !dbg !780
  %19 = select i1 %17, i32 0, i32 64, !dbg !780
  %20 = or disjoint i32 %18, %19, !dbg !780
  %rb861 = ptrtoint ptr addrspace(271) %12 to i32
  %rb862 = zext i32 %rb861 to i64
  %rb863 = getelementptr i8, ptr @_mh_execute_header, i64 %rb862
  %p32st.64 = getelementptr i8, ptr %rb863, i64 0
  store i32 %20, ptr %p32st.64, align 16, !dbg !781
  br label %21, !dbg !782

21:                                               ; preds = %9, %4, %2, %16
  %22 = phi i32 [ 1, %16 ], [ 0, %2 ], [ 0, %4 ], [ 0, %9 ], !dbg !781
  ret i32 %22, !dbg !783
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetNoHit(ptr noundef readonly captures(address_is_null) %0, i32 noundef %1) local_unnamed_addr #5 !dbg !784 {
  %3 = icmp eq ptr %0, null, !dbg !785
  br i1 %3, label %21, label %4, !dbg !785

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !786
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !786
  %rb864 = ptrtoint ptr addrspace(271) %6 to i32
  %rb865 = zext i32 %rb864 to i64
  %rb866 = getelementptr i8, ptr @_mh_execute_header, i64 %rb865
  %7 = load ptr addrspace(271), ptr %rb866, align 4, !dbg !787
  %8 = icmp eq ptr addrspace(271) %7, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !788
  br i1 %8, label %9, label %21, !dbg !788

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !789
  %11 = load ptr addrspace(271), ptr %10, align 4, !dbg !789
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1408, !dbg !790
  %rb867 = ptrtoint ptr addrspace(271) %12 to i32
  %rb868 = zext i32 %rb867 to i64
  %rb869 = getelementptr i8, ptr @_mh_execute_header, i64 %rb868
  %13 = load i32, ptr %rb869, align 16, !dbg !790
  %14 = and i32 %13, 1, !dbg !791
  %15 = icmp eq i32 %14, 0, !dbg !791
  br i1 %15, label %21, label %16, !dbg !792

16:                                               ; preds = %9
  %17 = icmp eq i32 %1, 0, !dbg !793
  %18 = and i32 %13, -129, !dbg !793
  %19 = select i1 %17, i32 0, i32 128, !dbg !793
  %20 = or disjoint i32 %18, %19, !dbg !793
  %rb870 = ptrtoint ptr addrspace(271) %12 to i32
  %rb871 = zext i32 %rb870 to i64
  %rb872 = getelementptr i8, ptr @_mh_execute_header, i64 %rb871
  %p32st.65 = getelementptr i8, ptr %rb872, i64 0
  store i32 %20, ptr %p32st.65, align 16, !dbg !794
  br label %21, !dbg !795

21:                                               ; preds = %9, %4, %2, %16
  %22 = phi i32 [ 1, %16 ], [ 0, %2 ], [ 0, %4 ], [ 0, %9 ], !dbg !794
  ret i32 %22, !dbg !796
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetHeld(ptr noundef readonly captures(address_is_null) %0, i32 noundef %1) local_unnamed_addr #5 !dbg !797 {
  %3 = icmp eq ptr %0, null, !dbg !798
  br i1 %3, label %21, label %4, !dbg !798

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !799
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !799
  %rb873 = ptrtoint ptr addrspace(271) %6 to i32
  %rb874 = zext i32 %rb873 to i64
  %rb875 = getelementptr i8, ptr @_mh_execute_header, i64 %rb874
  %7 = load ptr addrspace(271), ptr %rb875, align 4, !dbg !800
  %8 = icmp eq ptr addrspace(271) %7, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !801
  br i1 %8, label %9, label %21, !dbg !801

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !802
  %11 = load ptr addrspace(271), ptr %10, align 4, !dbg !802
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1408, !dbg !803
  %rb876 = ptrtoint ptr addrspace(271) %12 to i32
  %rb877 = zext i32 %rb876 to i64
  %rb878 = getelementptr i8, ptr @_mh_execute_header, i64 %rb877
  %13 = load i32, ptr %rb878, align 16, !dbg !803
  %14 = and i32 %13, 1, !dbg !804
  %15 = icmp eq i32 %14, 0, !dbg !804
  br i1 %15, label %21, label %16, !dbg !805

16:                                               ; preds = %9
  %17 = icmp eq i32 %1, 0, !dbg !806
  %18 = and i32 %13, -257, !dbg !806
  %19 = select i1 %17, i32 0, i32 256, !dbg !806
  %20 = or disjoint i32 %18, %19, !dbg !806
  %rb879 = ptrtoint ptr addrspace(271) %12 to i32
  %rb880 = zext i32 %rb879 to i64
  %rb881 = getelementptr i8, ptr @_mh_execute_header, i64 %rb880
  %p32st.66 = getelementptr i8, ptr %rb881, i64 0
  store i32 %20, ptr %p32st.66, align 16, !dbg !807
  br label %21, !dbg !808

21:                                               ; preds = %9, %4, %2, %16
  %22 = phi i32 [ 1, %16 ], [ 0, %2 ], [ 0, %4 ], [ 0, %9 ], !dbg !807
  ret i32 %22, !dbg !809
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetModelAnim(ptr noundef readonly captures(address_is_null) %0, i32 noundef %1) local_unnamed_addr #5 !dbg !810 {
  %3 = icmp eq ptr %0, null, !dbg !811
  br i1 %3, label %21, label %4, !dbg !811

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !812
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !812
  %rb882 = ptrtoint ptr addrspace(271) %6 to i32
  %rb883 = zext i32 %rb882 to i64
  %rb884 = getelementptr i8, ptr @_mh_execute_header, i64 %rb883
  %7 = load ptr addrspace(271), ptr %rb884, align 4, !dbg !813
  %8 = icmp eq ptr addrspace(271) %7, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !814
  br i1 %8, label %9, label %21, !dbg !814

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !815
  %11 = load ptr addrspace(271), ptr %10, align 4, !dbg !815
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1408, !dbg !816
  %rb885 = ptrtoint ptr addrspace(271) %12 to i32
  %rb886 = zext i32 %rb885 to i64
  %rb887 = getelementptr i8, ptr @_mh_execute_header, i64 %rb886
  %13 = load i32, ptr %rb887, align 16, !dbg !816
  %14 = and i32 %13, 1, !dbg !817
  %15 = icmp eq i32 %14, 0, !dbg !817
  br i1 %15, label %21, label %16, !dbg !818

16:                                               ; preds = %9
  %17 = icmp eq i32 %1, 0, !dbg !819
  %18 = and i32 %13, -8193, !dbg !819
  %19 = select i1 %17, i32 0, i32 8192, !dbg !819
  %20 = or disjoint i32 %18, %19, !dbg !819
  %rb888 = ptrtoint ptr addrspace(271) %12 to i32
  %rb889 = zext i32 %rb888 to i64
  %rb890 = getelementptr i8, ptr @_mh_execute_header, i64 %rb889
  %p32st.67 = getelementptr i8, ptr %rb890, i64 0
  store i32 %20, ptr %p32st.67, align 16, !dbg !820
  br label %21, !dbg !821

21:                                               ; preds = %9, %4, %2, %16
  %22 = phi i32 [ 1, %16 ], [ 0, %2 ], [ 0, %4 ], [ 0, %9 ], !dbg !820
  ret i32 %22, !dbg !822
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_MarkLast(ptr noundef readonly captures(address_is_null) %0) local_unnamed_addr #5 !dbg !823 {
  %2 = icmp eq ptr %0, null, !dbg !824
  br i1 %2, label %17, label %3, !dbg !824

3:                                                ; preds = %1
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !825
  %5 = load ptr addrspace(271), ptr %4, align 4, !dbg !825
  %rb891 = ptrtoint ptr addrspace(271) %5 to i32
  %rb892 = zext i32 %rb891 to i64
  %rb893 = getelementptr i8, ptr @_mh_execute_header, i64 %rb892
  %6 = load ptr addrspace(271), ptr %rb893, align 4, !dbg !826
  %7 = icmp eq ptr addrspace(271) %6, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !827
  br i1 %7, label %8, label %17, !dbg !827

8:                                                ; preds = %3
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !828
  %10 = load ptr addrspace(271), ptr %9, align 4, !dbg !828
  %11 = getelementptr inbounds nuw i8, ptr addrspace(271) %10, i32 1408, !dbg !829
  %rb894 = ptrtoint ptr addrspace(271) %11 to i32
  %rb895 = zext i32 %rb894 to i64
  %rb896 = getelementptr i8, ptr @_mh_execute_header, i64 %rb895
  %12 = load i32, ptr %rb896, align 16, !dbg !829
  %13 = and i32 %12, 1, !dbg !830
  %14 = icmp eq i32 %13, 0, !dbg !830
  br i1 %14, label %17, label %15, !dbg !831

15:                                               ; preds = %8
  %16 = or i32 %12, 2048, !dbg !832
  %rb897 = ptrtoint ptr addrspace(271) %11 to i32
  %rb898 = zext i32 %rb897 to i64
  %rb899 = getelementptr i8, ptr @_mh_execute_header, i64 %rb898
  %p32st.68 = getelementptr i8, ptr %rb899, i64 0
  store i32 %16, ptr %p32st.68, align 16, !dbg !832
  br label %17, !dbg !833

17:                                               ; preds = %8, %3, %1, %15
  %18 = phi i32 [ 1, %15 ], [ 0, %1 ], [ 0, %3 ], [ 0, %8 ], !dbg !834
  ret i32 %18, !dbg !835
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync)
define range(i32 0, 2) i32 @EftBlastObj_SetDelay(ptr noundef readonly captures(address_is_null) %0, float noundef %1) local_unnamed_addr #5 !dbg !836 {
  %3 = icmp eq ptr %0, null, !dbg !837
  br i1 %3, label %18, label %4, !dbg !837

4:                                                ; preds = %2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 40, !dbg !838
  %6 = load ptr addrspace(271), ptr %5, align 4, !dbg !838
  %rb900 = ptrtoint ptr addrspace(271) %6 to i32
  %rb901 = zext i32 %rb900 to i64
  %rb902 = getelementptr i8, ptr @_mh_execute_header, i64 %rb901
  %7 = load ptr addrspace(271), ptr %rb902, align 4, !dbg !839
  %8 = icmp eq ptr addrspace(271) %7, inttoptr (i32 trunc (i64 sub (i64 ptrtoint (ptr @EftBlastObj_Update to i64), i64 ptrtoint (ptr @_mh_execute_header to i64)) to i32) to ptr addrspace(271)), !dbg !840
  br i1 %8, label %9, label %18, !dbg !840

9:                                                ; preds = %4
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 56, !dbg !841
  %11 = load ptr addrspace(271), ptr %10, align 4, !dbg !841
  %12 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1408, !dbg !842
  %rb903 = ptrtoint ptr addrspace(271) %12 to i32
  %rb904 = zext i32 %rb903 to i64
  %rb905 = getelementptr i8, ptr @_mh_execute_header, i64 %rb904
  %13 = load i32, ptr %rb905, align 16, !dbg !842
  %14 = and i32 %13, 1, !dbg !843
  %15 = icmp eq i32 %14, 0, !dbg !843
  br i1 %15, label %18, label %16, !dbg !844

16:                                               ; preds = %9
  %17 = getelementptr inbounds nuw i8, ptr addrspace(271) %11, i32 1424, !dbg !845
  %rb906 = ptrtoint ptr addrspace(271) %17 to i32
  %rb907 = zext i32 %rb906 to i64
  %rb908 = getelementptr i8, ptr @_mh_execute_header, i64 %rb907
  %p32st.69 = getelementptr i8, ptr %rb908, i64 0
  store float %1, ptr %p32st.69, align 16, !dbg !846
  br label %18, !dbg !847

18:                                               ; preds = %9, %4, %2, %16
  %19 = phi i32 [ 1, %16 ], [ 0, %2 ], [ 0, %4 ], [ 0, %9 ], !dbg !848
  ret i32 %19, !dbg !849
}

attributes #0 = { nounwind uwtable(sync) "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable(sync) "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, inaccessiblemem: none) uwtable(sync) "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #6 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, inaccessiblemem: none) uwtable(sync) "frame-pointer"="non-leaf" "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-a7" "target-features"="+perfmon,+v8a,-aes,-fp-armv8,-neon,-sha2" }
attributes #7 = { nobuiltin nounwind "no-builtins" }
attributes #8 = { nounwind }
attributes #9 = { nobuiltin "no-builtins" }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !5, !6}
!llvm.dbg.cu = !{!7}
!llvm.ident = !{!9}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 17, i32 5]}
!1 = !{i32 7, !"Dwarf Version", i32 4}
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 4}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 1}
!6 = !{i32 7, !"frame-pointer", i32 1}
!7 = distinct !DICompileUnit(language: DW_LANG_C89, file: !8, producer: "Homebrew clang version 21.1.8", isOptimized: true, runtimeVersion: 0, emissionKind: LineTablesOnly, splitDebugInlining: false, nameTableKind: Apple, sysroot: "/")
!8 = !DIFile(filename: "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid/src/battle/eft_o_b.c", directory: "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid")
!9 = !{!"Homebrew clang version 21.1.8"}
!10 = distinct !DISubprogram(name: "EftBlastObj_AddHit", scope: !11, file: !11, line: 145, type: !12, scopeLine: 145, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!11 = !DIFile(filename: "src/battle/eft_o_b.c", directory: "/Users/runner/work/Tenkaichi3DecompAndroid/Tenkaichi3DecompAndroid")
!12 = !DISubroutineType(types: !13)
!13 = !{}
!14 = !DILocation(line: 146, column: 44, scope: !10)
!15 = !DILocation(line: 147, column: 39, scope: !10)
!16 = !DILocation(line: 148, column: 39, scope: !10)
!17 = !DILocation(line: 151, column: 12, scope: !10)
!18 = !DILocation(line: 151, column: 45, scope: !10)
!19 = !DILocation(line: 151, column: 42, scope: !10)
!20 = !DILocation(line: 151, column: 20, scope: !10)
!21 = !DILocation(line: 151, column: 18, scope: !10)
!22 = !DILocation(line: 152, column: 10, scope: !10)
!23 = !DILocation(line: 152, column: 20, scope: !10)
!24 = !DILocation(line: 153, column: 17, scope: !10)
!25 = !DILocation(line: 153, column: 10, scope: !10)
!26 = !DILocation(line: 153, column: 15, scope: !10)
!27 = !DILocation(line: 154, column: 10, scope: !10)
!28 = !DILocation(line: 154, column: 14, scope: !10)
!29 = !DILocation(line: 155, column: 12, scope: !10)
!30 = !DILocation(line: 155, column: 18, scope: !10)
!31 = !DILocation(line: 156, column: 14, scope: !10)
!32 = !DILocation(line: 156, column: 20, scope: !10)
!33 = !DILocation(line: 158, column: 12, scope: !10)
!34 = !DILocation(line: 157, column: 5, scope: !10)
!35 = !DILocation(line: 158, column: 18, scope: !10)
!36 = !DILocation(line: 159, column: 14, scope: !10)
!37 = !DILocation(line: 159, column: 20, scope: !10)
!38 = !DILocation(line: 160, column: 5, scope: !10)
!39 = !DILocation(line: 161, column: 18, scope: !10)
!40 = !DILocation(line: 161, column: 23, scope: !10)
!41 = !DILocation(line: 161, column: 5, scope: !10)
!42 = !DILocation(line: 163, column: 35, scope: !10)
!43 = !DILocation(line: 164, column: 35, scope: !10)
!44 = !DILocation(line: 166, column: 27, scope: !10)
!45 = !DILocation(line: 166, column: 52, scope: !10)
!46 = !DILocation(line: 166, column: 43, scope: !10)
!47 = !DILocation(line: 166, column: 9, scope: !10)
!48 = !DILocation(line: 167, column: 52, scope: !10)
!49 = !DILocation(line: 167, column: 43, scope: !10)
!50 = !DILocation(line: 167, column: 9, scope: !10)
!51 = !DILocation(line: 168, column: 9, scope: !10)
!52 = !DILocation(line: 172, column: 35, scope: !10)
!53 = !DILocation(line: 173, column: 35, scope: !10)
!54 = !DILocation(line: 175, column: 35, scope: !10)
!55 = !DILocation(line: 175, column: 26, scope: !10)
!56 = !DILocation(line: 175, column: 9, scope: !10)
!57 = !DILocation(line: 176, column: 35, scope: !10)
!58 = !DILocation(line: 176, column: 26, scope: !10)
!59 = !DILocation(line: 176, column: 9, scope: !10)
!60 = !DILocation(line: 177, column: 9, scope: !10)
!61 = !DILocation(line: 183, column: 5, scope: !10)
!62 = !DILocation(line: 184, column: 1, scope: !10)
!63 = !DISubprogram(name: "EftHit_GetNew", scope: !11, file: !11, line: 111, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!64 = !DISubprogram(name: "EftEmit_GetTrailWidth", scope: !11, file: !11, line: 132, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!65 = !DISubprogram(name: "EftHitArena_AllocBox", scope: !11, file: !11, line: 114, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!66 = !DISubprogram(name: "ColCapsule_Set", scope: !11, file: !11, line: 117, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!67 = !DISubprogram(name: "EftHit_SetShapeBoxes", scope: !11, file: !11, line: 116, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!68 = !DISubprogram(name: "EftHitArena_AllocSphere", scope: !11, file: !11, line: 113, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!69 = !DISubprogram(name: "ColSphere_Set", scope: !11, file: !11, line: 118, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!70 = !DISubprogram(name: "EftHit_SetShapeSpheres", scope: !11, file: !11, line: 115, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!71 = !DISubprogram(name: "EftHit_Add", scope: !11, file: !11, line: 112, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!72 = distinct !DISubprogram(name: "EftBlastObj_InitModel", scope: !11, file: !11, line: 187, type: !12, scopeLine: 187, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!73 = !DILocation(line: 188, column: 82, scope: !72)
!74 = !DILocation(line: 188, column: 89, scope: !72)
!75 = !DILocation(line: 190, column: 31, scope: !72)
!76 = !DILocation(line: 190, column: 28, scope: !72)
!77 = !DILocation(line: 190, column: 39, scope: !72)
!78 = !DILocation(line: 190, column: 36, scope: !72)
!79 = !DILocation(line: 190, column: 14, scope: !72)
!80 = !DILocation(line: 190, column: 8, scope: !72)
!81 = !DILocation(line: 190, column: 12, scope: !72)
!82 = !DILocation(line: 191, column: 8, scope: !72)
!83 = !DILocation(line: 191, column: 13, scope: !72)
!84 = !DILocation(line: 192, column: 23, scope: !72)
!85 = !DILocation(line: 192, column: 5, scope: !72)
!86 = !DILocation(line: 193, column: 19, scope: !72)
!87 = !DILocation(line: 193, column: 16, scope: !72)
!88 = !DILocation(line: 193, column: 5, scope: !72)
!89 = !DILocation(line: 194, column: 1, scope: !72)
!90 = !DISubprogram(name: "EftObj_Create", scope: !11, file: !11, line: 134, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!91 = !DISubprogram(name: "EftObj_SetVisible", scope: !11, file: !11, line: 139, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!92 = !DISubprogram(name: "EftObj_Nop", scope: !11, file: !11, line: 140, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!93 = distinct !DISubprogram(name: "EftBlastObj_UpdateModel", scope: !11, file: !11, line: 200, type: !12, scopeLine: 200, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!94 = !DILocation(line: 201, column: 5, scope: !93)
!95 = !DILocation(line: 202, column: 5, scope: !93)
!96 = !DILocation(line: 203, column: 5, scope: !93)
!97 = !DILocation(line: 206, column: 44, scope: !93)
!98 = !DILocation(line: 211, column: 5, scope: !93)
!99 = !DILocation(line: 212, column: 41, scope: !93)
!100 = !DILocation(line: 212, column: 5, scope: !93)
!101 = !DILocation(line: 214, column: 12, scope: !93)
!102 = !DILocation(line: 214, column: 18, scope: !93)
!103 = !DILocation(line: 215, column: 16, scope: !93)
!104 = !DILocation(line: 215, column: 21, scope: !93)
!105 = !DILocation(line: 216, column: 20, scope: !93)
!106 = !DILocation(line: 216, column: 25, scope: !93)
!107 = !DILocation(line: 218, column: 24, scope: !93)
!108 = !DILocation(line: 219, column: 13, scope: !93)
!109 = !DILocation(line: 220, column: 28, scope: !93)
!110 = !DILocation(line: 221, column: 42, scope: !93)
!111 = !DILocation(line: 221, column: 39, scope: !93)
!112 = !DILocation(line: 221, column: 18, scope: !93)
!113 = !DILocation(line: 221, column: 17, scope: !93)
!114 = !DILocation(line: 223, column: 20, scope: !93)
!115 = !DILocation(line: 223, column: 25, scope: !93)
!116 = !DILocation(line: 225, column: 24, scope: !93)
!117 = !DILocation(line: 226, column: 13, scope: !93)
!118 = !DILocation(line: 228, column: 26, scope: !93)
!119 = !DILocation(line: 229, column: 20, scope: !93)
!120 = !DILocation(line: 229, column: 25, scope: !93)
!121 = !DILocation(line: 230, column: 24, scope: !93)
!122 = !DILocation(line: 232, column: 26, scope: !93)
!123 = !DILocation(line: 233, column: 13, scope: !93)
!124 = !DILocation(line: 235, column: 42, scope: !93)
!125 = !DILocation(line: 235, column: 39, scope: !93)
!126 = !DILocation(line: 235, column: 18, scope: !93)
!127 = !DILocation(line: 235, column: 17, scope: !93)
!128 = !DILocation(line: 236, column: 24, scope: !93)
!129 = !DILocation(line: 237, column: 20, scope: !93)
!130 = !DILocation(line: 237, column: 25, scope: !93)
!131 = !DILocation(line: 239, column: 26, scope: !93)
!132 = !DILocation(line: 240, column: 13, scope: !93)
!133 = !DILocation(line: 241, column: 28, scope: !93)
!134 = !DILocation(line: 242, column: 42, scope: !93)
!135 = !DILocation(line: 242, column: 39, scope: !93)
!136 = !DILocation(line: 242, column: 18, scope: !93)
!137 = !DILocation(line: 242, column: 17, scope: !93)
!138 = !DILocation(line: 244, column: 20, scope: !93)
!139 = !DILocation(line: 244, column: 25, scope: !93)
!140 = !DILocation(line: 246, column: 24, scope: !93)
!141 = !DILocation(line: 247, column: 13, scope: !93)
!142 = !DILocation(line: 250, column: 40, scope: !93)
!143 = !DILocation(line: 0, scope: !93)
!144 = !DILocation(line: 250, column: 32, scope: !93)
!145 = !DILocation(line: 250, column: 29, scope: !93)
!146 = !DILocation(line: 250, column: 37, scope: !93)
!147 = !DILocation(line: 250, column: 13, scope: !93)
!148 = !DILocation(line: 251, column: 9, scope: !93)
!149 = !DILocation(line: 252, column: 30, scope: !93)
!150 = !DILocation(line: 252, column: 26, scope: !93)
!151 = !DILocation(line: 252, column: 9, scope: !93)
!152 = !DILocation(line: 253, column: 18, scope: !93)
!153 = !DILocation(line: 253, column: 24, scope: !93)
!154 = !DILocation(line: 253, column: 13, scope: !93)
!155 = !DILocation(line: 254, column: 71, scope: !93)
!156 = !DILocation(line: 254, column: 56, scope: !93)
!157 = !DILocation(line: 254, column: 38, scope: !93)
!158 = !DILocation(line: 254, column: 135, scope: !93)
!159 = !DILocation(line: 255, column: 9, scope: !93)
!160 = !DILocation(line: 256, column: 68, scope: !93)
!161 = !DILocation(line: 256, column: 75, scope: !93)
!162 = !DILocation(line: 256, column: 52, scope: !93)
!163 = !DILocation(line: 256, column: 78, scope: !93)
!164 = !DILocation(line: 256, column: 34, scope: !93)
!165 = !DILocation(line: 256, column: 155, scope: !93)
!166 = !DILocation(line: 257, column: 34, scope: !93)
!167 = !DILocation(line: 257, column: 25, scope: !93)
!168 = !DILocation(line: 257, column: 9, scope: !93)
!169 = !DILocation(line: 258, column: 18, scope: !93)
!170 = !DILocation(line: 258, column: 24, scope: !93)
!171 = !DILocation(line: 258, column: 13, scope: !93)
!172 = !DILocation(line: 259, column: 13, scope: !93)
!173 = !DILocation(line: 259, column: 21, scope: !93)
!174 = !DILocation(line: 261, column: 20, scope: !93)
!175 = !DILocation(line: 261, column: 25, scope: !93)
!176 = !DILocation(line: 261, column: 30, scope: !93)
!177 = !DILocation(line: 261, column: 33, scope: !93)
!178 = !DILocation(line: 265, column: 13, scope: !93)
!179 = !DILocation(line: 266, column: 13, scope: !93)
!180 = !DILocation(line: 267, column: 13, scope: !93)
!181 = !DILocation(line: 268, column: 9, scope: !93)
!182 = !DILocation(line: 271, column: 30, scope: !93)
!183 = !DILocation(line: 271, column: 26, scope: !93)
!184 = !DILocation(line: 271, column: 9, scope: !93)
!185 = !DILocation(line: 272, column: 32, scope: !93)
!186 = !DILocation(line: 272, column: 17, scope: !93)
!187 = !DILocation(line: 273, column: 31, scope: !93)
!188 = !DILocation(line: 273, column: 38, scope: !93)
!189 = !DILocation(line: 273, column: 15, scope: !93)
!190 = !DILocation(line: 273, column: 41, scope: !93)
!191 = !DILocation(line: 274, column: 17, scope: !93)
!192 = !DILocation(line: 275, column: 34, scope: !93)
!193 = !DILocation(line: 275, column: 117, scope: !93)
!194 = !DILocation(line: 276, column: 9, scope: !93)
!195 = !DILocation(line: 277, column: 44, scope: !93)
!196 = !DILocation(line: 277, column: 35, scope: !93)
!197 = !DILocation(line: 279, column: 22, scope: !93)
!198 = !DILocation(line: 279, column: 19, scope: !93)
!199 = !DILocation(line: 279, column: 5, scope: !93)
!200 = !DILocation(line: 280, column: 26, scope: !93)
!201 = !DILocation(line: 280, column: 23, scope: !93)
!202 = !DILocation(line: 280, column: 5, scope: !93)
!203 = !DILocation(line: 281, column: 8, scope: !93)
!204 = !DILocation(line: 281, column: 13, scope: !93)
!205 = !DILocation(line: 282, column: 1, scope: !93)
!206 = !DISubprogram(name: "Mtx_StoreIdentity", scope: !11, file: !11, line: 89, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!207 = !DISubprogram(name: "Mtx_ScaleDiagUniform", scope: !11, file: !11, line: 94, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!208 = !DISubprogram(name: "EftObj_IsAnimPlaying", scope: !11, file: !11, line: 137, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!209 = !DISubprogram(name: "EftObj_PlayAnim", scope: !11, file: !11, line: 136, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!210 = !DISubprogram(name: "Vec3_Clamp", scope: !11, file: !11, line: 96, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!211 = !DISubprogram(name: "EftMath_WrapAngle", scope: !11, file: !11, line: 97, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!212 = !DISubprogram(name: "Mathf_Asin", scope: !11, file: !11, line: 84, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!213 = !DISubprogram(name: "Mtx_RotateX", scope: !11, file: !11, line: 92, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!214 = !DISubprogram(name: "Port_atan2f", scope: !11, file: !11, line: 83, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!215 = !DISubprogram(name: "Mtx_RotateY", scope: !11, file: !11, line: 93, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!216 = !DISubprogram(name: "Vec4_Copy", scope: !11, file: !11, line: 86, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!217 = !DISubprogram(name: "Mtx_MulVec4", scope: !11, file: !11, line: 90, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!218 = !DISubprogram(name: "Vec3_Add", scope: !11, file: !11, line: 87, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!219 = !DISubprogram(name: "Mtx_Translate", scope: !11, file: !11, line: 91, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!220 = !DISubprogram(name: "EftObj_SetMtx", scope: !11, file: !11, line: 138, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!221 = distinct !DISubprogram(name: "EftBlastObj_TermModel", scope: !11, file: !11, line: 285, type: !12, scopeLine: 285, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!222 = !DILocation(line: 286, column: 58, scope: !221)
!223 = !DILocation(line: 286, column: 71, scope: !221)
!224 = !DILocation(line: 286, column: 20, scope: !221)
!225 = !DILocation(line: 286, column: 5, scope: !221)
!226 = !DILocation(line: 287, column: 1, scope: !221)
!227 = !DISubprogram(name: "EftObj_Destroy", scope: !11, file: !11, line: 135, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!228 = distinct !DISubprogram(name: "EftBlastObj_UpdateParts", scope: !11, file: !11, line: 294, type: !12, scopeLine: 294, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!229 = !DILocation(line: 295, column: 44, scope: !228)
!230 = !DILocation(line: 299, column: 5, scope: !228)
!231 = !DILocation(line: 300, column: 19, scope: !228)
!232 = !DILocation(line: 300, column: 13, scope: !228)
!233 = !DILocation(line: 300, column: 29, scope: !228)
!234 = !DILocation(line: 300, column: 24, scope: !228)
!235 = !DILocation(line: 301, column: 48, scope: !228)
!236 = !DILocation(line: 301, column: 60, scope: !228)
!237 = !DILocation(line: 303, column: 33, scope: !228)
!238 = !DILocation(line: 303, column: 27, scope: !228)
!239 = !DILocation(line: 303, column: 13, scope: !228)
!240 = !DILocation(line: 309, column: 31, scope: !228)
!241 = !DILocation(line: 309, column: 17, scope: !228)
!242 = !DILocation(line: 304, column: 39, scope: !228)
!243 = !DILocation(line: 304, column: 27, scope: !228)
!244 = !DILocation(line: 310, column: 49, scope: !228)
!245 = !DILocation(line: 310, column: 59, scope: !228)
!246 = !DILocation(line: 310, column: 46, scope: !228)
!247 = !DILocation(line: 313, column: 41, scope: !228)
!248 = !DILocation(line: 313, column: 25, scope: !228)
!249 = !DILocation(line: 313, column: 59, scope: !228)
!250 = !DILocation(line: 313, column: 46, scope: !228)
!251 = !DILocation(line: 309, column: 47, scope: !228)
!252 = distinct !{!252, !241, !253}
!253 = !DILocation(line: 321, column: 17, scope: !228)
!254 = !DILocation(line: 325, column: 27, scope: !228)
!255 = !DILocation(line: 326, column: 80, scope: !228)
!256 = !DILocation(line: 326, column: 86, scope: !228)
!257 = !DILocation(line: 327, column: 58, scope: !228)
!258 = !DILocation(line: 326, column: 25, scope: !228)
!259 = !DILocation(line: 328, column: 17, scope: !228)
!260 = !DILocation(line: 329, column: 25, scope: !228)
!261 = !DILocation(line: 0, scope: !228)
!262 = !DILocation(line: 331, column: 23, scope: !228)
!263 = !DILocation(line: 332, column: 99, scope: !228)
!264 = !DILocation(line: 332, column: 21, scope: !228)
!265 = !DILocation(line: 333, column: 17, scope: !228)
!266 = !DILocation(line: 303, column: 41, scope: !228)
!267 = !DILocation(line: 303, column: 29, scope: !228)
!268 = distinct !{!268, !239, !269}
!269 = !DILocation(line: 334, column: 13, scope: !228)
!270 = !DILocation(line: 299, column: 26, scope: !228)
!271 = !DILocation(line: 299, column: 19, scope: !228)
!272 = distinct !{!272, !230, !273}
!273 = !DILocation(line: 336, column: 5, scope: !228)
!274 = !DILocation(line: 337, column: 1, scope: !228)
!275 = !DISubprogram(name: "EftEmit_GetFlagsFromReq", scope: !11, file: !11, line: 124, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!276 = !DISubprogram(name: "EftEmit_GetResetFlags", scope: !11, file: !11, line: 125, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!277 = !DISubprogram(name: "EftEmit_SpawnOwn", scope: !11, file: !11, line: 126, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!278 = distinct !DISubprogram(name: "EftBlastObj_Init", scope: !11, file: !11, line: 354, type: !12, scopeLine: 354, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!279 = !DILocation(line: 355, column: 44, scope: !278)
!280 = !DILocation(line: 368, column: 13, scope: !278)
!281 = !DILocation(line: 368, column: 15, scope: !278)
!282 = !DILocation(line: 369, column: 14, scope: !278)
!283 = !DILocation(line: 370, column: 21, scope: !278)
!284 = !DILocation(line: 371, column: 22, scope: !278)
!285 = !DILocation(line: 371, column: 127, scope: !278)
!286 = !DILocation(line: 371, column: 184, scope: !278)
!287 = !DILocation(line: 371, column: 138, scope: !278)
!288 = !DILocation(line: 371, column: 203, scope: !278)
!289 = !DILocation(line: 370, column: 13, scope: !278)
!290 = !DILocation(line: 372, column: 9, scope: !278)
!291 = !DILocation(line: 375, column: 12, scope: !278)
!292 = !DILocation(line: 375, column: 5, scope: !278)
!293 = !DILocation(line: 376, column: 19, scope: !278)
!294 = !DILocation(line: 376, column: 8, scope: !278)
!295 = !DILocation(line: 376, column: 12, scope: !278)
!296 = !DILocation(line: 377, column: 25, scope: !278)
!297 = !DILocation(line: 377, column: 12, scope: !278)
!298 = !DILocation(line: 378, column: 22, scope: !278)
!299 = !DILocation(line: 378, column: 8, scope: !278)
!300 = !DILocation(line: 378, column: 15, scope: !278)
!301 = !DILocation(line: 379, column: 22, scope: !278)
!302 = !DILocation(line: 379, column: 8, scope: !278)
!303 = !DILocation(line: 379, column: 15, scope: !278)
!304 = !DILocation(line: 380, column: 21, scope: !278)
!305 = !DILocation(line: 380, column: 8, scope: !278)
!306 = !DILocation(line: 380, column: 14, scope: !278)
!307 = !DILocation(line: 381, column: 21, scope: !278)
!308 = !DILocation(line: 381, column: 8, scope: !278)
!309 = !DILocation(line: 381, column: 14, scope: !278)
!310 = !DILocation(line: 382, column: 20, scope: !278)
!311 = !DILocation(line: 382, column: 8, scope: !278)
!312 = !DILocation(line: 382, column: 13, scope: !278)
!313 = !DILocation(line: 383, column: 24, scope: !278)
!314 = !DILocation(line: 383, column: 8, scope: !278)
!315 = !DILocation(line: 383, column: 17, scope: !278)
!316 = !DILocation(line: 384, column: 21, scope: !278)
!317 = !DILocation(line: 384, column: 8, scope: !278)
!318 = !DILocation(line: 384, column: 14, scope: !278)
!319 = !DILocation(line: 385, column: 27, scope: !278)
!320 = !DILocation(line: 385, column: 8, scope: !278)
!321 = !DILocation(line: 385, column: 20, scope: !278)
!322 = !DILocation(line: 386, column: 27, scope: !278)
!323 = !DILocation(line: 386, column: 15, scope: !278)
!324 = !DILocation(line: 386, column: 20, scope: !278)
!325 = !DILocation(line: 387, column: 8, scope: !278)
!326 = !DILocation(line: 387, column: 17, scope: !278)
!327 = !DILocation(line: 392, column: 16, scope: !278)
!328 = !DILocation(line: 393, column: 12, scope: !278)
!329 = !DILocation(line: 393, column: 26, scope: !278)
!330 = !DILocation(line: 393, column: 20, scope: !278)
!331 = !DILocation(line: 394, column: 18, scope: !278)
!332 = !DILocation(line: 395, column: 49, scope: !278)
!333 = !DILocation(line: 395, column: 56, scope: !278)
!334 = !DILocation(line: 395, column: 24, scope: !278)
!335 = !DILocation(line: 397, column: 22, scope: !278)
!336 = !DILocation(line: 397, column: 13, scope: !278)
!337 = !DILocation(line: 397, column: 36, scope: !278)
!338 = !DILocation(line: 398, column: 40, scope: !278)
!339 = !DILocation(line: 398, column: 74, scope: !278)
!340 = !DILocation(line: 398, column: 53, scope: !278)
!341 = !DILocation(line: 398, column: 13, scope: !278)
!342 = !DILocation(line: 402, column: 12, scope: !278)
!343 = !DILocation(line: 399, column: 9, scope: !278)
!344 = !DILocation(line: 401, column: 8, scope: !278)
!345 = !DILocation(line: 401, column: 14, scope: !278)
!346 = !DILocation(line: 402, column: 17, scope: !278)
!347 = !DILocation(line: 403, column: 18, scope: !278)
!348 = !DILocation(line: 404, column: 31, scope: !278)
!349 = !DILocation(line: 404, column: 12, scope: !278)
!350 = !DILocation(line: 404, column: 21, scope: !278)
!351 = !DILocation(line: 405, column: 5, scope: !278)
!352 = !DILocation(line: 406, column: 19, scope: !278)
!353 = !DILocation(line: 406, column: 8, scope: !278)
!354 = !DILocation(line: 406, column: 14, scope: !278)
!355 = !DILocation(line: 407, column: 19, scope: !278)
!356 = !DILocation(line: 407, column: 15, scope: !278)
!357 = !DILocation(line: 407, column: 34, scope: !278)
!358 = !DILocation(line: 407, column: 31, scope: !278)
!359 = !DILocation(line: 407, column: 5, scope: !278)
!360 = !DILocation(line: 408, column: 24, scope: !278)
!361 = !DILocation(line: 408, column: 15, scope: !278)
!362 = !DILocation(line: 408, column: 5, scope: !278)
!363 = !DILocation(line: 409, column: 19, scope: !278)
!364 = !DILocation(line: 409, column: 15, scope: !278)
!365 = !DILocation(line: 409, column: 27, scope: !278)
!366 = !DILocation(line: 409, column: 24, scope: !278)
!367 = !DILocation(line: 409, column: 5, scope: !278)
!368 = !DILocation(line: 410, column: 32, scope: !278)
!369 = !DILocation(line: 410, column: 54, scope: !278)
!370 = !DILocation(line: 410, column: 45, scope: !278)
!371 = !DILocation(line: 410, column: 5, scope: !278)
!372 = !DILocation(line: 411, column: 25, scope: !278)
!373 = !DILocation(line: 411, column: 16, scope: !278)
!374 = !DILocation(line: 411, column: 42, scope: !278)
!375 = !DILocation(line: 411, column: 5, scope: !278)
!376 = !DILocation(line: 412, column: 8, scope: !278)
!377 = !DILocation(line: 412, column: 14, scope: !278)
!378 = !DILocation(line: 413, column: 26, scope: !278)
!379 = !DILocation(line: 413, column: 23, scope: !278)
!380 = !DILocation(line: 413, column: 34, scope: !278)
!381 = !DILocation(line: 413, column: 31, scope: !278)
!382 = !DILocation(line: 413, column: 5, scope: !278)
!383 = !DILocation(line: 414, column: 14, scope: !278)
!384 = !DILocation(line: 414, column: 20, scope: !278)
!385 = !DILocation(line: 415, column: 18, scope: !278)
!386 = !DILocation(line: 416, column: 30, scope: !278)
!387 = !DILocation(line: 416, column: 12, scope: !278)
!388 = !DILocation(line: 416, column: 23, scope: !278)
!389 = !DILocation(line: 188, column: 82, scope: !72, inlinedAt: !390)
!390 = distinct !DILocation(line: 417, column: 9, scope: !278)
!391 = !DILocation(line: 188, column: 89, scope: !72, inlinedAt: !390)
!392 = !DILocation(line: 190, column: 31, scope: !72, inlinedAt: !390)
!393 = !DILocation(line: 190, column: 28, scope: !72, inlinedAt: !390)
!394 = !DILocation(line: 190, column: 39, scope: !72, inlinedAt: !390)
!395 = !DILocation(line: 190, column: 36, scope: !72, inlinedAt: !390)
!396 = !DILocation(line: 190, column: 14, scope: !72, inlinedAt: !390)
!397 = !DILocation(line: 190, column: 8, scope: !72, inlinedAt: !390)
!398 = !DILocation(line: 190, column: 12, scope: !72, inlinedAt: !390)
!399 = !DILocation(line: 191, column: 8, scope: !72, inlinedAt: !390)
!400 = !DILocation(line: 191, column: 13, scope: !72, inlinedAt: !390)
!401 = !DILocation(line: 192, column: 23, scope: !72, inlinedAt: !390)
!402 = !DILocation(line: 192, column: 5, scope: !72, inlinedAt: !390)
!403 = !DILocation(line: 193, column: 19, scope: !72, inlinedAt: !390)
!404 = !DILocation(line: 193, column: 16, scope: !72, inlinedAt: !390)
!405 = !DILocation(line: 193, column: 5, scope: !72, inlinedAt: !390)
!406 = !DILocation(line: 418, column: 5, scope: !278)
!407 = !DILocation(line: 419, column: 36, scope: !278)
!408 = !DILocation(line: 419, column: 42, scope: !278)
!409 = !DILocation(line: 419, column: 31, scope: !278)
!410 = !DILocation(line: 419, column: 5, scope: !278)
!411 = !DILocation(line: 420, column: 1, scope: !278)
!412 = !DISubprogram(name: "fprintf", scope: !413, file: !413, line: 147, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!413 = !DIFile(filename: "/Applications/Xcode_15.4.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS17.5.sdk/usr/include/stdio.h", directory: "")
!414 = !DISubprogram(name: "memset", scope: !11, file: !11, line: 82, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!415 = !DISubprogram(name: "EftShot_GetAttrKind", scope: !11, file: !11, line: 121, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!416 = !DISubprogram(name: "BtlCharApi_GetNodePos", scope: !11, file: !11, line: 109, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!417 = !DISubprogram(name: "Vec3_Scale", scope: !11, file: !11, line: 88, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!418 = !DISubprogram(name: "EftEmit_InitState", scope: !11, file: !11, line: 122, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!419 = !DISubprogram(name: "BtlTask_SetOwnerTag", scope: !11, file: !11, line: 107, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!420 = distinct !DISubprogram(name: "EftBlastObj_Term", scope: !11, file: !11, line: 423, type: !12, scopeLine: 423, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!421 = !DILocation(line: 424, column: 44, scope: !420)
!422 = !DILocation(line: 426, column: 12, scope: !420)
!423 = !DILocation(line: 426, column: 18, scope: !420)
!424 = !DILocation(line: 286, column: 71, scope: !221, inlinedAt: !425)
!425 = distinct !DILocation(line: 427, column: 9, scope: !420)
!426 = !DILocation(line: 286, column: 20, scope: !221, inlinedAt: !425)
!427 = !DILocation(line: 286, column: 5, scope: !221, inlinedAt: !425)
!428 = !DILocation(line: 428, column: 5, scope: !420)
!429 = !DILocation(line: 429, column: 26, scope: !420)
!430 = !DILocation(line: 429, column: 23, scope: !420)
!431 = !DILocation(line: 429, column: 34, scope: !420)
!432 = !DILocation(line: 429, column: 31, scope: !420)
!433 = !DILocation(line: 429, column: 5, scope: !420)
!434 = !DILocation(line: 430, column: 14, scope: !420)
!435 = !DILocation(line: 431, column: 1, scope: !420)
!436 = !DISubprogram(name: "EftEmit_TermState", scope: !11, file: !11, line: 123, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!437 = distinct !DISubprogram(name: "EftBlastObj_Update", scope: !11, file: !11, line: 434, type: !12, scopeLine: 434, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!438 = !DILocation(line: 435, column: 44, scope: !437)
!439 = !DILocation(line: 436, column: 39, scope: !437)
!440 = !DILocation(line: 438, column: 37, scope: !437)
!441 = !DILocation(line: 438, column: 9, scope: !437)
!442 = !DILocation(line: 441, column: 13, scope: !437)
!443 = !DILocation(line: 441, column: 19, scope: !437)
!444 = !DILocation(line: 441, column: 29, scope: !437)
!445 = !DILocation(line: 441, column: 54, scope: !437)
!446 = !DILocation(line: 441, column: 32, scope: !437)
!447 = !DILocation(line: 442, column: 18, scope: !437)
!448 = !DILocation(line: 443, column: 5, scope: !437)
!449 = !DILocation(line: 444, column: 28, scope: !437)
!450 = !DILocation(line: 444, column: 37, scope: !437)
!451 = !DILocation(line: 444, column: 33, scope: !437)
!452 = !DILocation(line: 444, column: 5, scope: !437)
!453 = !DILocation(line: 445, column: 12, scope: !437)
!454 = !DILocation(line: 445, column: 18, scope: !437)
!455 = !DILocation(line: 445, column: 28, scope: !437)
!456 = !DILocation(line: 445, column: 38, scope: !437)
!457 = !DILocation(line: 445, column: 43, scope: !437)
!458 = !DILocation(line: 445, column: 49, scope: !437)
!459 = !DILocation(line: 446, column: 18, scope: !437)
!460 = !DILocation(line: 446, column: 13, scope: !437)
!461 = !DILocation(line: 448, column: 36, scope: !437)
!462 = !DILocation(line: 448, column: 27, scope: !437)
!463 = !DILocation(line: 448, column: 51, scope: !437)
!464 = !DILocation(line: 448, column: 42, scope: !437)
!465 = !DILocation(line: 448, column: 17, scope: !437)
!466 = !DILocation(line: 449, column: 24, scope: !437)
!467 = !DILocation(line: 449, column: 30, scope: !437)
!468 = !DILocation(line: 450, column: 49, scope: !437)
!469 = !DILocation(line: 450, column: 45, scope: !437)
!470 = !DILocation(line: 450, column: 21, scope: !437)
!471 = !DILocation(line: 451, column: 17, scope: !437)
!472 = !DILocation(line: 452, column: 39, scope: !437)
!473 = !DILocation(line: 452, column: 44, scope: !437)
!474 = !DILocation(line: 452, column: 32, scope: !437)
!475 = !DILocation(line: 453, column: 41, scope: !437)
!476 = !DILocation(line: 453, column: 37, scope: !437)
!477 = !DILocation(line: 453, column: 74, scope: !437)
!478 = !DILocation(line: 453, column: 84, scope: !437)
!479 = !DILocation(line: 453, column: 25, scope: !437)
!480 = !DILocation(line: 454, column: 45, scope: !437)
!481 = !DILocation(line: 454, column: 36, scope: !437)
!482 = !DILocation(line: 454, column: 62, scope: !437)
!483 = !DILocation(line: 454, column: 25, scope: !437)
!484 = !DILocation(line: 455, column: 21, scope: !437)
!485 = !DILocation(line: 456, column: 67, scope: !437)
!486 = !DILocation(line: 456, column: 58, scope: !437)
!487 = !DILocation(line: 456, column: 21, scope: !437)
!488 = !DILocation(line: 461, column: 21, scope: !437)
!489 = !DILocation(line: 461, column: 16, scope: !437)
!490 = !DILocation(line: 462, column: 18, scope: !437)
!491 = !DILocation(line: 463, column: 5, scope: !437)
!492 = !DILocation(line: 464, column: 12, scope: !437)
!493 = !DILocation(line: 464, column: 18, scope: !437)
!494 = !DILocation(line: 465, column: 12, scope: !437)
!495 = !DILocation(line: 465, column: 21, scope: !437)
!496 = !DILocation(line: 466, column: 25, scope: !437)
!497 = !DILocation(line: 467, column: 22, scope: !437)
!498 = !DILocation(line: 468, column: 9, scope: !437)
!499 = !DILocation(line: 470, column: 31, scope: !437)
!500 = !DILocation(line: 470, column: 9, scope: !437)
!501 = !DILocation(line: 473, column: 12, scope: !437)
!502 = !DILocation(line: 471, column: 18, scope: !437)
!503 = !DILocation(line: 472, column: 5, scope: !437)
!504 = !DILocation(line: 473, column: 18, scope: !437)
!505 = !DILocation(line: 474, column: 9, scope: !437)
!506 = !DILocation(line: 475, column: 5, scope: !437)
!507 = !DILocation(line: 476, column: 34, scope: !437)
!508 = !DILocation(line: 476, column: 50, scope: !437)
!509 = !DILocation(line: 476, column: 47, scope: !437)
!510 = !DILocation(line: 476, column: 5, scope: !437)
!511 = !DILocation(line: 477, column: 12, scope: !437)
!512 = !DILocation(line: 477, column: 18, scope: !437)
!513 = !DILocation(line: 478, column: 9, scope: !437)
!514 = !DILocation(line: 479, column: 5, scope: !437)
!515 = !DILocation(line: 479, column: 25, scope: !437)
!516 = !DILocation(line: 480, column: 18, scope: !437)
!517 = !DILocation(line: 481, column: 5, scope: !437)
!518 = !DILocation(line: 481, column: 27, scope: !437)
!519 = !DILocation(line: 481, column: 16, scope: !437)
!520 = !DILocation(line: 482, column: 37, scope: !437)
!521 = !DILocation(line: 482, column: 34, scope: !437)
!522 = !DILocation(line: 482, column: 45, scope: !437)
!523 = !DILocation(line: 482, column: 42, scope: !437)
!524 = !DILocation(line: 482, column: 9, scope: !437)
!525 = !DILocation(line: 483, column: 9, scope: !437)
!526 = !DILocation(line: 484, column: 5, scope: !437)
!527 = !DILocation(line: 485, column: 1, scope: !437)
!528 = !DISubprogram(name: "BtlScene_IsCharStopped", scope: !11, file: !11, line: 103, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!529 = !DISubprogram(name: "EftShot_TestBits", scope: !11, file: !11, line: 120, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!530 = !DISubprogram(name: "EftEmit_UpdateNodesReq", scope: !11, file: !11, line: 130, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!531 = !DISubprogram(name: "EftAim_Home", scope: !11, file: !11, line: 98, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!532 = !DISubprogram(name: "BtlTask_SetDead", scope: !11, file: !11, line: 106, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!533 = !DISubprogram(name: "EftEmit_UpdateTrailWidth", scope: !11, file: !11, line: 131, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!534 = distinct !DISubprogram(name: "EftBlastObj_PostUpdate", scope: !11, file: !11, line: 488, type: !12, scopeLine: 488, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!535 = !DILocation(line: 489, column: 44, scope: !534)
!536 = !DILocation(line: 491, column: 35, scope: !534)
!537 = !DILocation(line: 491, column: 40, scope: !534)
!538 = !DILocation(line: 491, column: 9, scope: !534)
!539 = !DILocation(line: 494, column: 28, scope: !534)
!540 = !DILocation(line: 494, column: 25, scope: !534)
!541 = !DILocation(line: 494, column: 36, scope: !534)
!542 = !DILocation(line: 494, column: 33, scope: !534)
!543 = !DILocation(line: 494, column: 5, scope: !534)
!544 = !DILocation(line: 495, column: 21, scope: !534)
!545 = !DILocation(line: 495, column: 28, scope: !534)
!546 = !DILocation(line: 495, column: 9, scope: !534)
!547 = !DILocation(line: 496, column: 28, scope: !534)
!548 = !DILocation(line: 496, column: 19, scope: !534)
!549 = !DILocation(line: 496, column: 40, scope: !534)
!550 = !DILocation(line: 496, column: 9, scope: !534)
!551 = !DILocation(line: 497, column: 18, scope: !534)
!552 = !DILocation(line: 497, column: 24, scope: !534)
!553 = !DILocation(line: 497, column: 13, scope: !534)
!554 = !DILocation(line: 498, column: 22, scope: !534)
!555 = !DILocation(line: 499, column: 9, scope: !534)
!556 = !DILocation(line: 501, column: 15, scope: !534)
!557 = !DILocation(line: 501, column: 22, scope: !534)
!558 = !DILocation(line: 502, column: 12, scope: !534)
!559 = !DILocation(line: 502, column: 18, scope: !534)
!560 = !DILocation(line: 503, column: 5, scope: !534)
!561 = !DILocation(line: 504, column: 1, scope: !534)
!562 = !DISubprogram(name: "EftEmit_UpdateAlive", scope: !11, file: !11, line: 129, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!563 = !DISubprogram(name: "Vec3_Copy", scope: !11, file: !11, line: 95, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!564 = distinct !DISubprogram(name: "EftBlastObj_Reset", scope: !11, file: !11, line: 507, type: !12, scopeLine: 507, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!565 = !DILocation(line: 508, column: 44, scope: !564)
!566 = !DILocation(line: 510, column: 14, scope: !564)
!567 = !DILocation(line: 510, column: 20, scope: !564)
!568 = !DILocation(line: 510, column: 9, scope: !564)
!569 = !DILocation(line: 511, column: 18, scope: !564)
!570 = !DILocation(line: 512, column: 28, scope: !564)
!571 = !DILocation(line: 512, column: 25, scope: !564)
!572 = !DILocation(line: 512, column: 36, scope: !564)
!573 = !DILocation(line: 512, column: 33, scope: !564)
!574 = !DILocation(line: 512, column: 9, scope: !564)
!575 = !DILocation(line: 513, column: 5, scope: !564)
!576 = !DILocation(line: 514, column: 5, scope: !564)
!577 = !DILocation(line: 515, column: 1, scope: !564)
!578 = !DISubprogram(name: "EftEmit_KillAll", scope: !11, file: !11, line: 128, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!579 = distinct !DISubprogram(name: "EftBlastObj_Draw", scope: !11, file: !11, line: 518, type: !12, scopeLine: 518, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!580 = !DILocation(line: 519, column: 1, scope: !579)
!581 = distinct !DISubprogram(name: "EftBlastObjMgr_Init", scope: !11, file: !11, line: 522, type: !12, scopeLine: 522, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!582 = !DILocation(line: 523, column: 58, scope: !581)
!583 = !DILocation(line: 523, column: 81, scope: !581)
!584 = !DILocation(line: 523, column: 32, scope: !581)
!585 = !DILocation(line: 525, column: 21, scope: !581)
!586 = !DILocation(line: 526, column: 10, scope: !581)
!587 = !DILocation(line: 527, column: 24, scope: !581)
!588 = !DILocation(line: 527, column: 22, scope: !581)
!589 = !DILocation(line: 528, column: 1, scope: !581)
!590 = !DISubprogram(name: "BtlPool_GetCurrent", scope: !11, file: !11, line: 100, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!591 = !DISubprogram(name: "BtlPool_Alloc", scope: !11, file: !11, line: 101, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!592 = !DISubprogram(name: "BtlTask_CreateChildList", scope: !11, file: !11, line: 104, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!593 = distinct !DISubprogram(name: "EftBlastObjMgr_Term", scope: !11, file: !11, line: 531, type: !12, scopeLine: 531, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!594 = !DILocation(line: 532, column: 31, scope: !593)
!595 = !DILocation(line: 532, column: 72, scope: !593)
!596 = !DILocation(line: 532, column: 117, scope: !593)
!597 = !DILocation(line: 532, column: 95, scope: !593)
!598 = !DILocation(line: 533, column: 21, scope: !593)
!599 = !DILocation(line: 534, column: 1, scope: !593)
!600 = !DISubprogram(name: "BtlPool_Free", scope: !11, file: !11, line: 102, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!601 = distinct !DISubprogram(name: "EftBlastObjMgr_Update", scope: !11, file: !11, line: 537, type: !12, scopeLine: 537, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!602 = !DILocation(line: 538, column: 1, scope: !601)
!603 = distinct !DISubprogram(name: "EftBlastObjMgr_Reset", scope: !11, file: !11, line: 541, type: !12, scopeLine: 541, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!604 = !DILocation(line: 542, column: 1, scope: !603)
!605 = distinct !DISubprogram(name: "EftBlastObj_Create", scope: !11, file: !11, line: 545, type: !12, scopeLine: 545, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!606 = !DILocation(line: 551, column: 9, scope: !605)
!607 = !DILocation(line: 556, column: 13, scope: !605)
!608 = !DILocation(line: 561, column: 13, scope: !605)
!609 = !DILocation(line: 561, column: 15, scope: !605)
!610 = !DILocation(line: 562, column: 14, scope: !605)
!611 = !DILocation(line: 563, column: 21, scope: !605)
!612 = !DILocation(line: 564, column: 80, scope: !605)
!613 = !DILocation(line: 564, column: 201, scope: !605)
!614 = !DILocation(line: 564, column: 158, scope: !605)
!615 = !DILocation(line: 565, column: 31, scope: !605)
!616 = !DILocation(line: 565, column: 89, scope: !605)
!617 = !DILocation(line: 565, column: 46, scope: !605)
!618 = !DILocation(line: 565, column: 140, scope: !605)
!619 = !DILocation(line: 565, column: 97, scope: !605)
!620 = !DILocation(line: 563, column: 13, scope: !605)
!621 = !DILocation(line: 566, column: 9, scope: !605)
!622 = !DILocation(line: 569, column: 32, scope: !605)
!623 = !DILocation(line: 569, column: 12, scope: !605)
!624 = !DILocation(line: 569, column: 5, scope: !605)
!625 = !DISubprogram(name: "BtlTaskList_AddTail", scope: !11, file: !11, line: 105, type: !12, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!626 = distinct !DISubprogram(name: "EftBlastObj_CreateWithModel", scope: !11, file: !11, line: 573, type: !12, scopeLine: 573, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!627 = !DILocation(line: 579, column: 9, scope: !626)
!628 = !DILocation(line: 584, column: 15, scope: !626)
!629 = !DILocation(line: 584, column: 13, scope: !626)
!630 = !DILocation(line: 585, column: 32, scope: !626)
!631 = !DILocation(line: 585, column: 12, scope: !626)
!632 = !DILocation(line: 585, column: 5, scope: !626)
!633 = distinct !DISubprogram(name: "EftBlastObj_Stop", scope: !11, file: !11, line: 589, type: !12, scopeLine: 589, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!634 = !DILocation(line: 592, column: 14, scope: !633)
!635 = !DILocation(line: 595, column: 15, scope: !633)
!636 = !DILocation(line: 595, column: 9, scope: !633)
!637 = !DILocation(line: 595, column: 22, scope: !633)
!638 = !DILocation(line: 598, column: 15, scope: !633)
!639 = !DILocation(line: 599, column: 14, scope: !633)
!640 = !DILocation(line: 599, column: 20, scope: !633)
!641 = !DILocation(line: 599, column: 9, scope: !633)
!642 = !DILocation(line: 602, column: 14, scope: !633)
!643 = !DILocation(line: 603, column: 5, scope: !633)
!644 = !DILocation(line: 0, scope: !633)
!645 = !DILocation(line: 604, column: 1, scope: !633)
!646 = distinct !DISubprogram(name: "EftBlastObj_Kill", scope: !11, file: !11, line: 607, type: !12, scopeLine: 607, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!647 = !DILocation(line: 610, column: 14, scope: !646)
!648 = !DILocation(line: 613, column: 15, scope: !646)
!649 = !DILocation(line: 613, column: 9, scope: !646)
!650 = !DILocation(line: 613, column: 22, scope: !646)
!651 = !DILocation(line: 616, column: 15, scope: !646)
!652 = !DILocation(line: 617, column: 14, scope: !646)
!653 = !DILocation(line: 617, column: 20, scope: !646)
!654 = !DILocation(line: 617, column: 9, scope: !646)
!655 = !DILocation(line: 620, column: 14, scope: !646)
!656 = !DILocation(line: 621, column: 20, scope: !646)
!657 = !DILocation(line: 621, column: 9, scope: !646)
!658 = !DILocation(line: 622, column: 18, scope: !646)
!659 = !DILocation(line: 623, column: 28, scope: !646)
!660 = !DILocation(line: 623, column: 25, scope: !646)
!661 = !DILocation(line: 623, column: 36, scope: !646)
!662 = !DILocation(line: 623, column: 33, scope: !646)
!663 = !DILocation(line: 623, column: 9, scope: !646)
!664 = !DILocation(line: 624, column: 5, scope: !646)
!665 = !DILocation(line: 0, scope: !646)
!666 = !DILocation(line: 626, column: 1, scope: !646)
!667 = distinct !DISubprogram(name: "EftBlastObj_IsAlive", scope: !11, file: !11, line: 629, type: !12, scopeLine: 629, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!668 = !DILocation(line: 630, column: 14, scope: !667)
!669 = !DILocation(line: 633, column: 15, scope: !667)
!670 = !DILocation(line: 633, column: 9, scope: !667)
!671 = !DILocation(line: 633, column: 22, scope: !667)
!672 = !DILocation(line: 636, column: 47, scope: !667)
!673 = !DILocation(line: 636, column: 54, scope: !667)
!674 = !DILocation(line: 636, column: 60, scope: !667)
!675 = !DILocation(line: 0, scope: !667)
!676 = !DILocation(line: 640, column: 1, scope: !667)
!677 = distinct !DISubprogram(name: "EftBlastObj_IsDying", scope: !11, file: !11, line: 643, type: !12, scopeLine: 643, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!678 = !DILocation(line: 646, column: 14, scope: !677)
!679 = !DILocation(line: 649, column: 15, scope: !677)
!680 = !DILocation(line: 649, column: 9, scope: !677)
!681 = !DILocation(line: 649, column: 22, scope: !677)
!682 = !DILocation(line: 652, column: 15, scope: !677)
!683 = !DILocation(line: 653, column: 14, scope: !677)
!684 = !DILocation(line: 653, column: 20, scope: !677)
!685 = !DILocation(line: 653, column: 9, scope: !677)
!686 = !DILocation(line: 0, scope: !677)
!687 = !DILocation(line: 660, column: 1, scope: !677)
!688 = distinct !DISubprogram(name: "EftBlastObj_SetSel", scope: !11, file: !11, line: 663, type: !12, scopeLine: 663, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!689 = !DILocation(line: 666, column: 14, scope: !688)
!690 = !DILocation(line: 669, column: 15, scope: !688)
!691 = !DILocation(line: 669, column: 9, scope: !688)
!692 = !DILocation(line: 669, column: 22, scope: !688)
!693 = !DILocation(line: 672, column: 15, scope: !688)
!694 = !DILocation(line: 673, column: 14, scope: !688)
!695 = !DILocation(line: 673, column: 20, scope: !688)
!696 = !DILocation(line: 673, column: 9, scope: !688)
!697 = !DILocation(line: 676, column: 8, scope: !688)
!698 = !DILocation(line: 676, column: 5, scope: !688)
!699 = !DILocation(line: 676, column: 20, scope: !688)
!700 = !DILocation(line: 677, column: 15, scope: !688)
!701 = !DILocation(line: 677, column: 20, scope: !688)
!702 = !DILocation(line: 678, column: 18, scope: !688)
!703 = !DILocation(line: 678, column: 13, scope: !688)
!704 = !DILocation(line: 678, column: 9, scope: !688)
!705 = !DILocation(line: 679, column: 20, scope: !688)
!706 = !DILocation(line: 680, column: 5, scope: !688)
!707 = !DILocation(line: 0, scope: !688)
!708 = !DILocation(line: 682, column: 1, scope: !688)
!709 = distinct !DISubprogram(name: "EftBlastObj_GetPose", scope: !11, file: !11, line: 685, type: !12, scopeLine: 685, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!710 = !DILocation(line: 688, column: 14, scope: !709)
!711 = !DILocation(line: 691, column: 15, scope: !709)
!712 = !DILocation(line: 691, column: 9, scope: !709)
!713 = !DILocation(line: 691, column: 22, scope: !709)
!714 = !DILocation(line: 694, column: 15, scope: !709)
!715 = !DILocation(line: 695, column: 14, scope: !709)
!716 = !DILocation(line: 695, column: 20, scope: !709)
!717 = !DILocation(line: 695, column: 9, scope: !709)
!718 = !DILocation(line: 698, column: 16, scope: !709)
!719 = !DILocation(line: 698, column: 12, scope: !709)
!720 = !DILocation(line: 698, column: 5, scope: !709)
!721 = !DILocation(line: 0, scope: !709)
!722 = !DILocation(line: 699, column: 1, scope: !709)
!723 = distinct !DISubprogram(name: "EftBlastObj_SetTarget", scope: !11, file: !11, line: 703, type: !12, scopeLine: 703, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!724 = !DILocation(line: 706, column: 14, scope: !723)
!725 = !DILocation(line: 709, column: 15, scope: !723)
!726 = !DILocation(line: 709, column: 9, scope: !723)
!727 = !DILocation(line: 709, column: 22, scope: !723)
!728 = !DILocation(line: 712, column: 15, scope: !723)
!729 = !DILocation(line: 713, column: 14, scope: !723)
!730 = !DILocation(line: 713, column: 20, scope: !723)
!731 = !DILocation(line: 713, column: 9, scope: !723)
!732 = !DILocation(line: 716, column: 9, scope: !723)
!733 = !DILocation(line: 717, column: 18, scope: !723)
!734 = !DILocation(line: 718, column: 23, scope: !723)
!735 = !DILocation(line: 718, column: 19, scope: !723)
!736 = !DILocation(line: 718, column: 9, scope: !723)
!737 = !DILocation(line: 719, column: 5, scope: !723)
!738 = !DILocation(line: 720, column: 18, scope: !723)
!739 = !DILocation(line: 0, scope: !723)
!740 = !DILocation(line: 723, column: 1, scope: !723)
!741 = distinct !DISubprogram(name: "EftBlastObj_SetPrevPos", scope: !11, file: !11, line: 726, type: !12, scopeLine: 726, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!742 = !DILocation(line: 729, column: 14, scope: !741)
!743 = !DILocation(line: 732, column: 15, scope: !741)
!744 = !DILocation(line: 732, column: 9, scope: !741)
!745 = !DILocation(line: 732, column: 22, scope: !741)
!746 = !DILocation(line: 735, column: 15, scope: !741)
!747 = !DILocation(line: 736, column: 14, scope: !741)
!748 = !DILocation(line: 736, column: 20, scope: !741)
!749 = !DILocation(line: 736, column: 9, scope: !741)
!750 = !DILocation(line: 739, column: 24, scope: !741)
!751 = !DILocation(line: 739, column: 15, scope: !741)
!752 = !DILocation(line: 739, column: 5, scope: !741)
!753 = !DILocation(line: 740, column: 5, scope: !741)
!754 = !DILocation(line: 0, scope: !741)
!755 = !DILocation(line: 741, column: 1, scope: !741)
!756 = distinct !DISubprogram(name: "EftBlastObj_SetDir", scope: !11, file: !11, line: 744, type: !12, scopeLine: 744, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!757 = !DILocation(line: 747, column: 14, scope: !756)
!758 = !DILocation(line: 750, column: 15, scope: !756)
!759 = !DILocation(line: 750, column: 9, scope: !756)
!760 = !DILocation(line: 750, column: 22, scope: !756)
!761 = !DILocation(line: 753, column: 15, scope: !756)
!762 = !DILocation(line: 754, column: 14, scope: !756)
!763 = !DILocation(line: 754, column: 20, scope: !756)
!764 = !DILocation(line: 754, column: 9, scope: !756)
!765 = !DILocation(line: 757, column: 19, scope: !756)
!766 = !DILocation(line: 757, column: 15, scope: !756)
!767 = !DILocation(line: 757, column: 5, scope: !756)
!768 = !DILocation(line: 758, column: 5, scope: !756)
!769 = !DILocation(line: 0, scope: !756)
!770 = !DILocation(line: 759, column: 1, scope: !756)
!771 = distinct !DISubprogram(name: "EftBlastObj_SetFrozen", scope: !11, file: !11, line: 762, type: !12, scopeLine: 762, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!772 = !DILocation(line: 765, column: 14, scope: !771)
!773 = !DILocation(line: 768, column: 15, scope: !771)
!774 = !DILocation(line: 768, column: 9, scope: !771)
!775 = !DILocation(line: 768, column: 22, scope: !771)
!776 = !DILocation(line: 771, column: 15, scope: !771)
!777 = !DILocation(line: 772, column: 14, scope: !771)
!778 = !DILocation(line: 772, column: 20, scope: !771)
!779 = !DILocation(line: 772, column: 9, scope: !771)
!780 = !DILocation(line: 775, column: 9, scope: !771)
!781 = !DILocation(line: 0, scope: !771)
!782 = !DILocation(line: 780, column: 5, scope: !771)
!783 = !DILocation(line: 781, column: 1, scope: !771)
!784 = distinct !DISubprogram(name: "EftBlastObj_SetNoHit", scope: !11, file: !11, line: 784, type: !12, scopeLine: 784, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!785 = !DILocation(line: 787, column: 14, scope: !784)
!786 = !DILocation(line: 790, column: 15, scope: !784)
!787 = !DILocation(line: 790, column: 9, scope: !784)
!788 = !DILocation(line: 790, column: 22, scope: !784)
!789 = !DILocation(line: 793, column: 15, scope: !784)
!790 = !DILocation(line: 794, column: 14, scope: !784)
!791 = !DILocation(line: 794, column: 20, scope: !784)
!792 = !DILocation(line: 794, column: 9, scope: !784)
!793 = !DILocation(line: 797, column: 9, scope: !784)
!794 = !DILocation(line: 0, scope: !784)
!795 = !DILocation(line: 802, column: 5, scope: !784)
!796 = !DILocation(line: 803, column: 1, scope: !784)
!797 = distinct !DISubprogram(name: "EftBlastObj_SetHeld", scope: !11, file: !11, line: 806, type: !12, scopeLine: 806, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!798 = !DILocation(line: 809, column: 14, scope: !797)
!799 = !DILocation(line: 812, column: 15, scope: !797)
!800 = !DILocation(line: 812, column: 9, scope: !797)
!801 = !DILocation(line: 812, column: 22, scope: !797)
!802 = !DILocation(line: 815, column: 15, scope: !797)
!803 = !DILocation(line: 816, column: 14, scope: !797)
!804 = !DILocation(line: 816, column: 20, scope: !797)
!805 = !DILocation(line: 816, column: 9, scope: !797)
!806 = !DILocation(line: 819, column: 9, scope: !797)
!807 = !DILocation(line: 0, scope: !797)
!808 = !DILocation(line: 824, column: 5, scope: !797)
!809 = !DILocation(line: 825, column: 1, scope: !797)
!810 = distinct !DISubprogram(name: "EftBlastObj_SetModelAnim", scope: !11, file: !11, line: 828, type: !12, scopeLine: 828, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!811 = !DILocation(line: 831, column: 14, scope: !810)
!812 = !DILocation(line: 834, column: 15, scope: !810)
!813 = !DILocation(line: 834, column: 9, scope: !810)
!814 = !DILocation(line: 834, column: 22, scope: !810)
!815 = !DILocation(line: 837, column: 15, scope: !810)
!816 = !DILocation(line: 838, column: 14, scope: !810)
!817 = !DILocation(line: 838, column: 20, scope: !810)
!818 = !DILocation(line: 838, column: 9, scope: !810)
!819 = !DILocation(line: 841, column: 9, scope: !810)
!820 = !DILocation(line: 0, scope: !810)
!821 = !DILocation(line: 846, column: 5, scope: !810)
!822 = !DILocation(line: 847, column: 1, scope: !810)
!823 = distinct !DISubprogram(name: "EftBlastObj_MarkLast", scope: !11, file: !11, line: 850, type: !12, scopeLine: 850, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!824 = !DILocation(line: 853, column: 14, scope: !823)
!825 = !DILocation(line: 856, column: 15, scope: !823)
!826 = !DILocation(line: 856, column: 9, scope: !823)
!827 = !DILocation(line: 856, column: 22, scope: !823)
!828 = !DILocation(line: 859, column: 15, scope: !823)
!829 = !DILocation(line: 860, column: 14, scope: !823)
!830 = !DILocation(line: 860, column: 20, scope: !823)
!831 = !DILocation(line: 860, column: 9, scope: !823)
!832 = !DILocation(line: 863, column: 14, scope: !823)
!833 = !DILocation(line: 864, column: 5, scope: !823)
!834 = !DILocation(line: 0, scope: !823)
!835 = !DILocation(line: 865, column: 1, scope: !823)
!836 = distinct !DISubprogram(name: "EftBlastObj_SetDelay", scope: !11, file: !11, line: 868, type: !12, scopeLine: 868, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7)
!837 = !DILocation(line: 871, column: 14, scope: !836)
!838 = !DILocation(line: 874, column: 15, scope: !836)
!839 = !DILocation(line: 874, column: 9, scope: !836)
!840 = !DILocation(line: 874, column: 22, scope: !836)
!841 = !DILocation(line: 877, column: 15, scope: !836)
!842 = !DILocation(line: 878, column: 14, scope: !836)
!843 = !DILocation(line: 878, column: 20, scope: !836)
!844 = !DILocation(line: 878, column: 9, scope: !836)
!845 = !DILocation(line: 881, column: 8, scope: !836)
!846 = !DILocation(line: 881, column: 14, scope: !836)
!847 = !DILocation(line: 882, column: 5, scope: !836)
!848 = !DILocation(line: 0, scope: !836)
!849 = !DILocation(line: 883, column: 1, scope: !836)

@_mh_execute_header = external hidden global i8, align 4
